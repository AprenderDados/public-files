from __future__ import annotations

from pyspark import pipelines as dp


def apply_quality_rules(table_spec):
    def decorator(fn):
        wrapped_fn = fn
        for rule in reversed(table_spec.quality_rules):
            if rule.action == "warn":
                wrapped_fn = dp.expect(rule.name, rule.expression)(wrapped_fn)
            elif rule.action == "drop":
                wrapped_fn = dp.expect_or_drop(rule.name, rule.expression)(wrapped_fn)
            elif rule.action == "fail":
                wrapped_fn = dp.expect_or_fail(rule.name, rule.expression)(wrapped_fn)
            else:  # pragma: no cover
                raise ValueError(f"Unsupported quality action: {rule.action}")
        return wrapped_fn

    return decorator
