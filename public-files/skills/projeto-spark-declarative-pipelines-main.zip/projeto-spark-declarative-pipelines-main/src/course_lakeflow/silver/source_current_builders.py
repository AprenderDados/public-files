from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from course_lakeflow.common.models import TableSpec
from course_lakeflow.silver.silver_support import (
    DimensionDeduplicationService,
    LatestFullLoadSelector,
    SilverTableSupport,
)


class BaseCurrentDimensionBuilder:
    def __init__(self):
        self.selector = LatestFullLoadSelector()
        self.deduplicator = DimensionDeduplicationService()
        self.support = SilverTableSupport()

    def build(self, bronze_df: DataFrame, silver_spec: TableSpec) -> DataFrame:
        current_batch_df = self.selector.current_batch(bronze_df)
        cleaned_df = self.support.filter_rescued_data(current_batch_df)
        normalized_df = self.normalize(cleaned_df)
        deduplicated_df = self.deduplicator.deduplicate(
            normalized_df,
            silver_spec.deduplication_keys or silver_spec.business_keys,
        )
        return self.support.project_output_columns(deduplicated_df, silver_spec)

    def normalize(self, df: DataFrame) -> DataFrame:
        return df

    @staticmethod
    def _trim(df: DataFrame, *columns: str) -> DataFrame:
        for column_name in columns:
            if column_name in df.columns:
                df = df.withColumn(column_name, F.trim(F.col(column_name)))
        return df

    @staticmethod
    def _upper(df: DataFrame, *columns: str) -> DataFrame:
        for column_name in columns:
            if column_name in df.columns:
                df = df.withColumn(column_name, F.upper(F.trim(F.col(column_name))))
        return df


class ProductCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "product_name", "product_number")


class ProductSubcategoryCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "product_subcategory_name")


class ProductCategoryCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "product_category_name")


class ProductModelCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "product_model_name")


class ProductDescriptionCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "product_description")


class ProductModelDescriptionCultureCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._upper(df, "culture_id")


class SalesCustomerCurrentBuilder(BaseCurrentDimensionBuilder):
    pass


class SalesStoreCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "store_name")


class SalesTerritoryCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        df = self._trim(df, "territory_name", "territory_group")
        return self._upper(df, "country_region_code")


class PersonCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        df = self._trim(
            df,
            "person_type",
            "title",
            "first_name",
            "middle_name",
            "last_name",
            "suffix",
        )
        return self._upper(df, "person_type")


class BusinessEntityAddressCurrentBuilder(BaseCurrentDimensionBuilder):
    pass


class AddressCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        return self._trim(df, "address_line_1", "address_line_2", "city", "postal_code")


class StateProvinceCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        df = self._trim(df, "state_province_name")
        return self._upper(df, "state_province_code", "country_region_code")


class CountryRegionCurrentBuilder(BaseCurrentDimensionBuilder):
    def normalize(self, df: DataFrame) -> DataFrame:
        df = self._trim(df, "country_region_name")
        return self._upper(df, "country_region_code")
