from __future__ import annotations

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F

from course_lakeflow.common.models import TableSpec


class SilverTableSupport:
    @staticmethod
    def filter_rescued_data(df: DataFrame) -> DataFrame:
        if "_rescued_data" not in df.columns:
            return df
        return df.filter(
            F.col("_rescued_data").isNull() | (F.trim(F.col("_rescued_data")) == F.lit(""))
        )

    @staticmethod
    def project_output_columns(df: DataFrame, table_spec: TableSpec) -> DataFrame:
        output_columns = [field.name for field in table_spec.schema]
        missing_columns = sorted(set(output_columns) - set(df.columns))
        if missing_columns:
            raise ValueError(
                f"Missing output columns for {table_spec.logical_name}: {', '.join(missing_columns)}"
            )
        return df.select(*output_columns)


class LatestFullLoadSelector:
    @staticmethod
    def latest_batch(bronze_df: DataFrame) -> DataFrame:
        return (
            bronze_df.select("extract_batch_id", "extract_ts")
            .distinct()
            .orderBy(F.col("extract_ts").desc(), F.col("extract_batch_id").desc())
            .limit(1)
        )

    def current_batch(self, bronze_df: DataFrame) -> DataFrame:
        latest_batch_df = self.latest_batch(bronze_df)
        return bronze_df.join(
            F.broadcast(latest_batch_df),
            on=["extract_batch_id", "extract_ts"],
            how="inner",
        )


class DimensionDeduplicationService:
    @staticmethod
    def deduplicate(df: DataFrame, keys: list[str]) -> DataFrame:
        if not keys:
            return df

        order_columns = [
            F.col("extract_ts").desc(),
            F.col("source_file_modification_time").desc_nulls_last(),
            F.col("ingestion_ts").desc_nulls_last(),
            F.col("source_file_path").desc_nulls_last(),
        ]
        row_number_window = Window.partitionBy(*keys).orderBy(*order_columns)
        return (
            df.withColumn("_row_number", F.row_number().over(row_number_window))
            .filter(F.col("_row_number") == 1)
            .drop("_row_number")
        )


class FactDeduplicationService:
    @staticmethod
    def deduplicate(df: DataFrame, keys: list[str]) -> DataFrame:
        if not keys:
            return df
        return df.dropDuplicates(keys)
