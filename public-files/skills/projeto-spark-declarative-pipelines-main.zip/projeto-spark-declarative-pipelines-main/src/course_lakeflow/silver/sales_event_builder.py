from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from course_lakeflow.common.models import TableSpec
from course_lakeflow.silver.silver_support import FactDeduplicationService, SilverTableSupport


class SalesEventSilverBuilder:
    def __init__(self):
        self.deduplicator = FactDeduplicationService()
        self.support = SilverTableSupport()

    def build(self, bronze_df: DataFrame, silver_spec: TableSpec) -> DataFrame:
        cleaned_df = self.support.filter_rescued_data(bronze_df)
        normalized_df = (
            cleaned_df.withColumn("event_type", F.upper(F.trim(F.col("event_type"))))
            .withColumn("currency_code", F.upper(F.trim(F.col("currency_code"))))
            .withColumn("amount_delta", F.round(F.col("amount_delta"), 2).cast("decimal(18,2)"))
        )
        deduplicated_df = self.deduplicator.deduplicate(normalized_df, silver_spec.deduplication_keys)
        return self.support.project_output_columns(deduplicated_df, silver_spec)
