"""Silver layer services."""

