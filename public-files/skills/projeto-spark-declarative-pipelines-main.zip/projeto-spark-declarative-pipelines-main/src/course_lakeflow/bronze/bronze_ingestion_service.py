
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, current_timestamp, regexp_extract

from course_lakeflow.common.models import TableSpec
from course_lakeflow.common.spark_schema import SparkSchemaBuilder

class BronzeIngestionService:
    """
    Service responsible for explicit bronze ingestion contracts.

    The bronze layer is intentionally simple:
    - explicit schema declared in YAML
    - typed read through Auto Loader
    - rescued data preserved
    - minimal operational metadata added
    """

    def __init__(self, spark_session):
        self.spark = spark_session

    def read_autoloader_source(self, table_spec: TableSpec, input_path: str) -> DataFrame:
        if not table_spec.file_format:
            raise ValueError(f"Missing file_format for table spec {table_spec.logical_name}")
        if not table_spec.schema:
            raise ValueError(f"Missing source schema for table spec {table_spec.logical_name}")

        source_schema = SparkSchemaBuilder.build(table_spec.schema)

        reader = (
            self.spark.readStream.format("cloudFiles")
            .option("cloudFiles.format", table_spec.file_format)
            .option("rescuedDataColumn", "_rescued_data")
            .schema(source_schema)
        )

        for option_name, option_value in table_spec.reader_options.items():
            reader = reader.option(option_name, option_value)

        df = reader.load(input_path)

        return (
            df.withColumn("ingestion_ts", current_timestamp())
            .withColumn("source_file_path", col("_metadata.file_path"))
            .withColumn(
                "source_file_modification_time",
                col("_metadata.file_modification_time"),
            )
            .withColumn(
                "source_file_name",
                regexp_extract(col("_metadata.file_path"), r"([^/]+)$", 1),
            )
            .withColumn(
                "source_batch_id",
                regexp_extract(col("_metadata.file_path"), r"/([^/]+)/[^/]+$", 1),
            )
        )
