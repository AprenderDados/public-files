from __future__ import annotations

from pyspark import pipelines as dp
from pyspark.sql import SparkSession

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.pipeline_runtime import resolve_pipeline_project_root
from course_lakeflow.common.runtime_context import ProjectContextResolver
from course_lakeflow.gold.aggregation_service import GoldAggregationService
from course_lakeflow.gold.conformed_dimension_service import ConformedDimensionService


spark = SparkSession.builder.getOrCreate()
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)

config_loader = ConfigLoader(project_root)
context_resolver = ProjectContextResolver(spark, project_root)
runtime_context = context_resolver.resolve(environment)
aggregation_service = GoldAggregationService()
conformed_dimension_service = ConformedDimensionService()

silver_fact_spec = config_loader.load_table_spec("silver", "fact_sales_events_clean.yml")
silver_product_spec = config_loader.load_table_spec("silver", "production_product_current.yml")
silver_productsubcategory_spec = config_loader.load_table_spec("silver", "production_productsubcategory_current.yml")
silver_productcategory_spec = config_loader.load_table_spec("silver", "production_productcategory_current.yml")
silver_productmodel_spec = config_loader.load_table_spec("silver", "production_productmodel_current.yml")
silver_productdescription_spec = config_loader.load_table_spec("silver", "production_productdescription_current.yml")
silver_productmodeldescriptionculture_spec = config_loader.load_table_spec(
    "silver",
    "production_productmodelproductdescriptionculture_current.yml",
)
silver_customer_spec = config_loader.load_table_spec("silver", "sales_customer_current.yml")
silver_store_spec = config_loader.load_table_spec("silver", "sales_store_current.yml")
silver_person_spec = config_loader.load_table_spec("silver", "person_person_current.yml")
silver_businessentityaddress_spec = config_loader.load_table_spec("silver", "person_businessentityaddress_current.yml")
silver_address_spec = config_loader.load_table_spec("silver", "person_address_current.yml")
silver_stateprovince_spec = config_loader.load_table_spec("silver", "person_stateprovince_current.yml")
silver_countryregion_spec = config_loader.load_table_spec("silver", "person_countryregion_current.yml")
silver_territory_spec = config_loader.load_table_spec("silver", "sales_salesterritory_current.yml")
gold_dim_product_spec = config_loader.load_table_spec("gold", "dim_product.yml")
gold_dim_customer_spec = config_loader.load_table_spec("gold", "dim_customer.yml")
gold_sales_analytics_obt_spec = config_loader.load_table_spec("gold", "sales_analytics_obt.yml")
gold_daily_sales_spec = config_loader.load_table_spec("gold", "daily_sales.yml")
gold_daily_sales_by_product_spec = config_loader.load_table_spec("gold", "daily_sales_by_product.yml")
gold_arrival_vs_business_spec = config_loader.load_table_spec("gold", "arrival_vs_business_date.yml")
gold_correction_impact_spec = config_loader.load_table_spec("gold", "correction_impact.yml")


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_dim_product_spec),
    comment=gold_dim_product_spec.comment,
)
def gold_dim_product():
    return conformed_dimension_service.build_dim_product(
        dp.read(runtime_context.table_fqn(silver_product_spec)),
        dp.read(runtime_context.table_fqn(silver_productsubcategory_spec)),
        dp.read(runtime_context.table_fqn(silver_productcategory_spec)),
        dp.read(runtime_context.table_fqn(silver_productmodel_spec)),
        dp.read(runtime_context.table_fqn(silver_productmodeldescriptionculture_spec)),
        dp.read(runtime_context.table_fqn(silver_productdescription_spec)),
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_dim_customer_spec),
    comment=gold_dim_customer_spec.comment,
)
def gold_dim_customer():
    return conformed_dimension_service.build_dim_customer(
        dp.read(runtime_context.table_fqn(silver_customer_spec)),
        dp.read(runtime_context.table_fqn(silver_store_spec)),
        dp.read(runtime_context.table_fqn(silver_person_spec)),
        dp.read(runtime_context.table_fqn(silver_businessentityaddress_spec)),
        dp.read(runtime_context.table_fqn(silver_address_spec)),
        dp.read(runtime_context.table_fqn(silver_stateprovince_spec)),
        dp.read(runtime_context.table_fqn(silver_countryregion_spec)),
        dp.read(runtime_context.table_fqn(silver_territory_spec)),
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_sales_analytics_obt_spec),
    comment=gold_sales_analytics_obt_spec.comment,
)
def gold_sales_analytics_obt():
    return aggregation_service.build_sales_analytics_obt(
        dp.read(runtime_context.table_fqn(silver_fact_spec)),
        dp.read(runtime_context.table_fqn(gold_dim_product_spec)),
        dp.read(runtime_context.table_fqn(gold_dim_customer_spec)),
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_daily_sales_spec),
    comment=gold_daily_sales_spec.comment,
)
def gold_daily_sales():
    return aggregation_service.build_daily_sales(
        dp.read(runtime_context.table_fqn(gold_sales_analytics_obt_spec))
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_daily_sales_by_product_spec),
    comment=gold_daily_sales_by_product_spec.comment,
)
def gold_daily_sales_by_product():
    return aggregation_service.build_daily_sales_by_product(
        dp.read(runtime_context.table_fqn(gold_sales_analytics_obt_spec)),
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_arrival_vs_business_spec),
    comment=gold_arrival_vs_business_spec.comment,
)
def gold_arrival_vs_business_date():
    return aggregation_service.build_arrival_vs_business_date(
        dp.read(runtime_context.table_fqn(gold_sales_analytics_obt_spec))
    )


@dp.materialized_view(
    name=runtime_context.table_fqn(gold_correction_impact_spec),
    comment=gold_correction_impact_spec.comment,
)
def gold_correction_impact():
    return aggregation_service.build_correction_impact(
        dp.read(runtime_context.table_fqn(gold_sales_analytics_obt_spec))
    )
