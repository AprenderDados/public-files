from __future__ import annotations

from pyspark import pipelines as dp
from pyspark.sql import SparkSession

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.pipeline_runtime import resolve_pipeline_project_root
from course_lakeflow.common.runtime_context import ProjectContextResolver
from course_lakeflow.silver.quality_decorator import apply_quality_rules
from course_lakeflow.silver.sales_event_builder import SalesEventSilverBuilder


spark = SparkSession.builder.getOrCreate()
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)

config_loader = ConfigLoader(project_root)
context_resolver = ProjectContextResolver(spark, project_root)
runtime_context = context_resolver.resolve(environment)
event_builder = SalesEventSilverBuilder()

bronze_fact_spec = config_loader.load_table_spec("bronze", "fact_sales_events_raw.yml")
silver_fact_spec = config_loader.load_table_spec("silver", "fact_sales_events_clean.yml")


@dp.table(
    name=runtime_context.table_fqn(silver_fact_spec),
    comment=silver_fact_spec.comment,
)
@apply_quality_rules(silver_fact_spec)
def silver_fact_sales_events_clean():
    return event_builder.build(
        dp.read_stream(runtime_context.table_fqn(bronze_fact_spec)),
        silver_fact_spec,
    )
