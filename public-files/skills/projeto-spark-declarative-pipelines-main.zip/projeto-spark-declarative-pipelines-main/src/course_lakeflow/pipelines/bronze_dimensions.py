from __future__ import annotations

from pyspark import pipelines as dp
from pyspark.sql import SparkSession

from course_lakeflow.bronze.bronze_ingestion_service import BronzeIngestionService
from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.pipeline_runtime import resolve_pipeline_project_root
from course_lakeflow.common.runtime_context import ProjectContextResolver


spark = SparkSession.builder.getOrCreate()
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)

config_loader = ConfigLoader(project_root)
context_resolver = ProjectContextResolver(spark, project_root)
runtime_context = context_resolver.resolve(environment)
bronze_service = BronzeIngestionService(spark)

def _register_dimension_bronze(spec_file: str):
    table_spec = config_loader.load_table_spec("bronze", spec_file)

    @dp.table(
        name=runtime_context.table_fqn(table_spec),
        comment=table_spec.comment,
    )
    def _asset(table_spec=table_spec):
        return bronze_service.read_autoloader_source(
            table_spec,
            runtime_context.data_path(table_spec.path_ref),
        )

    return _asset


bronze_production_product_full_raw = _register_dimension_bronze("production_product_full_raw.yml")
bronze_production_productsubcategory_full_raw = _register_dimension_bronze("production_productsubcategory_full_raw.yml")
bronze_production_productcategory_full_raw = _register_dimension_bronze("production_productcategory_full_raw.yml")
bronze_production_productmodel_full_raw = _register_dimension_bronze("production_productmodel_full_raw.yml")
bronze_production_productdescription_full_raw = _register_dimension_bronze("production_productdescription_full_raw.yml")
bronze_production_productmodelproductdescriptionculture_full_raw = _register_dimension_bronze(
    "production_productmodelproductdescriptionculture_full_raw.yml"
)
bronze_sales_customer_full_raw = _register_dimension_bronze("sales_customer_full_raw.yml")
bronze_sales_store_full_raw = _register_dimension_bronze("sales_store_full_raw.yml")
bronze_sales_salesterritory_full_raw = _register_dimension_bronze("sales_salesterritory_full_raw.yml")
bronze_person_person_full_raw = _register_dimension_bronze("person_person_full_raw.yml")
bronze_person_businessentityaddress_full_raw = _register_dimension_bronze("person_businessentityaddress_full_raw.yml")
bronze_person_address_full_raw = _register_dimension_bronze("person_address_full_raw.yml")
bronze_person_stateprovince_full_raw = _register_dimension_bronze("person_stateprovince_full_raw.yml")
bronze_person_countryregion_full_raw = _register_dimension_bronze("person_countryregion_full_raw.yml")
