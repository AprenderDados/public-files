from __future__ import annotations

from pyspark import pipelines as dp
from pyspark.sql import SparkSession

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.pipeline_runtime import resolve_pipeline_project_root
from course_lakeflow.common.runtime_context import ProjectContextResolver
from course_lakeflow.silver.quality_decorator import apply_quality_rules
from course_lakeflow.silver.source_current_builders import (
    AddressCurrentBuilder,
    BusinessEntityAddressCurrentBuilder,
    CountryRegionCurrentBuilder,
    PersonCurrentBuilder,
    ProductCategoryCurrentBuilder,
    ProductCurrentBuilder,
    ProductDescriptionCurrentBuilder,
    ProductModelCurrentBuilder,
    ProductModelDescriptionCultureCurrentBuilder,
    ProductSubcategoryCurrentBuilder,
    SalesCustomerCurrentBuilder,
    SalesStoreCurrentBuilder,
    SalesTerritoryCurrentBuilder,
    StateProvinceCurrentBuilder,
)


spark = SparkSession.builder.getOrCreate()
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)

config_loader = ConfigLoader(project_root)
context_resolver = ProjectContextResolver(spark, project_root)
runtime_context = context_resolver.resolve(environment)

def _register_silver_dimension(bronze_file: str, silver_file: str, builder):
    bronze_spec = config_loader.load_table_spec("bronze", bronze_file)
    silver_spec = config_loader.load_table_spec("silver", silver_file)

    @dp.materialized_view(
        name=runtime_context.table_fqn(silver_spec),
        comment=silver_spec.comment,
    )
    @apply_quality_rules(silver_spec)
    def _asset(bronze_spec=bronze_spec, silver_spec=silver_spec, builder=builder):
        return builder.build(
            dp.read(runtime_context.table_fqn(bronze_spec)),
            silver_spec,
        )

    return _asset


silver_production_product_current = _register_silver_dimension(
    "production_product_full_raw.yml",
    "production_product_current.yml",
    ProductCurrentBuilder(),
)
silver_production_productsubcategory_current = _register_silver_dimension(
    "production_productsubcategory_full_raw.yml",
    "production_productsubcategory_current.yml",
    ProductSubcategoryCurrentBuilder(),
)
silver_production_productcategory_current = _register_silver_dimension(
    "production_productcategory_full_raw.yml",
    "production_productcategory_current.yml",
    ProductCategoryCurrentBuilder(),
)
silver_production_productmodel_current = _register_silver_dimension(
    "production_productmodel_full_raw.yml",
    "production_productmodel_current.yml",
    ProductModelCurrentBuilder(),
)
silver_production_productdescription_current = _register_silver_dimension(
    "production_productdescription_full_raw.yml",
    "production_productdescription_current.yml",
    ProductDescriptionCurrentBuilder(),
)
silver_production_productmodelproductdescriptionculture_current = _register_silver_dimension(
    "production_productmodelproductdescriptionculture_full_raw.yml",
    "production_productmodelproductdescriptionculture_current.yml",
    ProductModelDescriptionCultureCurrentBuilder(),
)
silver_sales_customer_current = _register_silver_dimension(
    "sales_customer_full_raw.yml",
    "sales_customer_current.yml",
    SalesCustomerCurrentBuilder(),
)
silver_sales_store_current = _register_silver_dimension(
    "sales_store_full_raw.yml",
    "sales_store_current.yml",
    SalesStoreCurrentBuilder(),
)
silver_sales_salesterritory_current = _register_silver_dimension(
    "sales_salesterritory_full_raw.yml",
    "sales_salesterritory_current.yml",
    SalesTerritoryCurrentBuilder(),
)
silver_person_person_current = _register_silver_dimension(
    "person_person_full_raw.yml",
    "person_person_current.yml",
    PersonCurrentBuilder(),
)
silver_person_businessentityaddress_current = _register_silver_dimension(
    "person_businessentityaddress_full_raw.yml",
    "person_businessentityaddress_current.yml",
    BusinessEntityAddressCurrentBuilder(),
)
silver_person_address_current = _register_silver_dimension(
    "person_address_full_raw.yml",
    "person_address_current.yml",
    AddressCurrentBuilder(),
)
silver_person_stateprovince_current = _register_silver_dimension(
    "person_stateprovince_full_raw.yml",
    "person_stateprovince_current.yml",
    StateProvinceCurrentBuilder(),
)
silver_person_countryregion_current = _register_silver_dimension(
    "person_countryregion_full_raw.yml",
    "person_countryregion_current.yml",
    CountryRegionCurrentBuilder(),
)
