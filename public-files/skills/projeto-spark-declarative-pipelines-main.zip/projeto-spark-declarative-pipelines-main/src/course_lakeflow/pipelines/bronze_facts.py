from __future__ import annotations

from pyspark import pipelines as dp
from pyspark.sql import SparkSession

from course_lakeflow.bronze.bronze_ingestion_service import BronzeIngestionService
from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.pipeline_runtime import resolve_pipeline_project_root
from course_lakeflow.common.runtime_context import ProjectContextResolver


spark = SparkSession.builder.getOrCreate()
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)

config_loader = ConfigLoader(project_root)
context_resolver = ProjectContextResolver(spark, project_root)
runtime_context = context_resolver.resolve(environment)

fact_spec = config_loader.load_table_spec("bronze", "fact_sales_events_raw.yml")
fact_input_path = runtime_context.data_path("fact_sales_events")
fact_table_name = runtime_context.table_fqn(fact_spec)

bronze_service = BronzeIngestionService(spark)


@dp.table(
    name=fact_table_name,
    comment=fact_spec.comment,
)
def bronze_fact_sales_events_raw():
    return bronze_service.read_autoloader_source(fact_spec, fact_input_path)
