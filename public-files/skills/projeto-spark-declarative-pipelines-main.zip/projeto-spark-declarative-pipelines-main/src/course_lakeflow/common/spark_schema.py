from __future__ import annotations

import re

from pyspark.sql.types import (
    DateType,
    DecimalType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from .models import TableFieldSpec


class SparkSchemaBuilder:
    """Builds a Spark StructType from declarative YAML field definitions."""

    @staticmethod
    def build(fields: list[TableFieldSpec]) -> StructType:
        return StructType(
            [StructField(field.name, SparkSchemaBuilder._parse_type(field.type), field.nullable) for field in fields]
        )

    @staticmethod
    def _parse_type(type_name: str):
        normalized = type_name.lower()
        if normalized == "string":
            return StringType()
        if normalized == "long":
            return LongType()
        if normalized == "int":
            return IntegerType()
        if normalized == "date":
            return DateType()
        if normalized == "timestamp":
            return TimestampType()
        decimal_match = re.fullmatch(r"decimal\((\d+),(\d+)\)", normalized)
        if decimal_match:
            precision, scale = decimal_match.groups()
            return DecimalType(int(precision), int(scale))
        raise ValueError(f"Unsupported Spark type in config: {type_name}")

