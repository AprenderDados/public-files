from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import EnvironmentConfig, TableSpec


class ConfigLoader:
    """Loads YAML configuration and applies small, explicit merge rules."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.config_root = project_root / "config"

    def load_environment(self, environment: str) -> EnvironmentConfig:
        base = self._read_yaml(self.config_root / "environments" / "base.yml")
        override = self._read_yaml(self.config_root / "environments" / f"{environment}.yml")
        merged = self._deep_merge(base, override)
        return EnvironmentConfig.model_validate(merged)

    def load_table_spec(self, layer: str, file_name: str) -> TableSpec:
        payload = self._read_yaml(self.config_root / "tables" / layer / file_name)
        return TableSpec.model_validate(payload)

    def load_table_specs(self, layer: str) -> list[TableSpec]:
        table_dir = self.config_root / "tables" / layer
        return [
            TableSpec.model_validate(self._read_yaml(path))
            for path in sorted(table_dir.glob("*.yml"))
        ]

    def load_resource_map(self, resource_name: str) -> dict[str, Any]:
        return self._read_yaml(self.config_root / "resources" / f"{resource_name}.yml")

    def _read_yaml(self, path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle) or {}

    def _deep_merge(self, base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        merged = dict(base)
        for key, value in override.items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = self._deep_merge(merged[key], value)
            else:
                merged[key] = value
        return merged

