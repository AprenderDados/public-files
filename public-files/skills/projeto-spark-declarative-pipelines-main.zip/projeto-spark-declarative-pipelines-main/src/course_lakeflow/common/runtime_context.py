from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config_loader import ConfigLoader
from .models import TableSpec


@dataclass(frozen=True)
class ResolvedProjectContext:
    environment: str
    user_prefix: str
    free_friendly: bool
    lakeflow_catalog: str
    generator_ops_catalog: str
    schemas: dict[str, str]
    volumes: dict[str, str]
    paths: dict[str, str]

    def schema_name(self, logical_schema: str) -> str:
        return self.schemas[logical_schema]

    def volume_path(self, volume_ref: str) -> str:
        return self.volumes[volume_ref]

    def data_path(self, path_ref: str) -> str:
        return self.paths[path_ref]

    def table_fqn(self, table_spec: TableSpec) -> str:
        schema_name = self._schema_for_layer(table_spec.layer)
        return f"{self.lakeflow_catalog}.{schema_name}.{table_spec.physical_name}"

    def ops_table_fqn(self, table_name: str) -> str:
        return f"{self.generator_ops_catalog}.{self.schemas['ops']}.{table_name}"

    def _schema_for_layer(self, layer: str) -> str:
        if layer == "bronze":
            return self.schemas["bronze"]
        if layer == "silver":
            return self.schemas["silver"]
        if layer == "gold":
            return self.schemas["gold"]
        raise ValueError(f"Unsupported layer for schema resolution: {layer}")


class ProjectContextResolver:
    """
    Resolves runtime names for catalogs, schemas, volumes and logical paths.

    Free-friendly mode keeps everything inside the current catalog and isolates
    this project by stable environment-specific schema names.
    """

    def __init__(self, spark_session, project_root: Path):
        self.spark = spark_session
        self.loader = ConfigLoader(project_root)

    def resolve(self, environment: str) -> ResolvedProjectContext:
        env_config = self.loader.load_environment(environment)
        catalogs_map = self.loader.load_resource_map("catalogs").get("catalogs", {})
        schemas_map = self.loader.load_resource_map("schemas").get("schemas", {})
        volumes_map = self.loader.load_resource_map("volumes").get("volumes", {})
        paths_map = self.loader.load_resource_map("paths").get("paths", {})

        current_catalog = self.spark.sql("SELECT current_catalog()").first()[0]
        user_prefix = environment

        free_friendly = bool(env_config.workspace_mode.get("free_friendly", False))
        schema_prefix = env_config.workspace_mode.get("user_schema_prefix", "sdp")

        if free_friendly:
            lakeflow_catalog = self._catalog_name(env_config, catalogs_map, "lakeflow", current_catalog)
            generator_ops_catalog = self._catalog_name(env_config, catalogs_map, "generator_ops", lakeflow_catalog)
            root_prefix = f"{schema_prefix}_{environment}"
            resolved_schemas = {
                logical_name: f"{root_prefix}_{logical_name}"
                for logical_name in schemas_map
            }
        else:
            lakeflow_catalog = self._catalog_name(env_config, catalogs_map, "lakeflow", current_catalog)
            generator_ops_catalog = self._catalog_name(env_config, catalogs_map, "generator_ops", current_catalog)
            resolved_schemas = {logical_name: logical_name for logical_name in schemas_map}

        resolved_volumes: dict[str, str] = {}
        for logical_name, payload in volumes_map.items():
            schema_ref = payload["schema_ref"]
            volume_name = payload["name"]
            resolved_volumes[logical_name] = (
                f"/Volumes/{lakeflow_catalog}/{resolved_schemas[schema_ref]}/{volume_name}"
            )

        resolved_paths: dict[str, str] = {}
        for logical_name, payload in paths_map.items():
            volume_path = resolved_volumes[payload["volume_ref"]]
            relative_path = payload["relative_path"].strip("/")
            resolved_paths[logical_name] = f"{volume_path}/{relative_path}"

        return ResolvedProjectContext(
            environment=environment,
            user_prefix=user_prefix,
            free_friendly=free_friendly,
            lakeflow_catalog=lakeflow_catalog,
            generator_ops_catalog=generator_ops_catalog,
            schemas=resolved_schemas,
            volumes=resolved_volumes,
            paths=resolved_paths,
        )

    @staticmethod
    def _catalog_name(
        env_config: Any,
        catalogs_map: dict[str, dict[str, str]],
        catalog_ref: str,
        current_catalog: str,
    ) -> str:
        override = env_config.catalog_overrides.get(catalog_ref)
        if override:
            return override
        template = catalogs_map.get(catalog_ref, {}).get("name_template")
        if template:
            return template.format(env=env_config.environment)
        return current_catalog
