from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class TableFieldSpec(BaseModel):
    name: str
    type: str
    nullable: bool = True


class QualityRuleSpec(BaseModel):
    name: str
    expression: str
    action: Literal["warn", "drop", "fail"]


class TableSpec(BaseModel):
    logical_name: str
    physical_name: str
    layer: Literal["bronze", "silver", "gold"]
    asset_type: Literal["streaming_table", "materialized_view"]
    dataset_type: str
    comment: str
    source_assets: list[str] = Field(default_factory=list)
    business_keys: list[str] = Field(default_factory=list)
    schema: list[TableFieldSpec] = Field(default_factory=list)
    quality_rules: list[QualityRuleSpec] = Field(default_factory=list)
    deduplication_keys: list[str] = Field(default_factory=list)
    path_ref: str | None = None
    file_format: str | None = None
    reader_options: dict[str, Any] = Field(default_factory=dict)


class EnvironmentConfig(BaseModel):
    environment: str
    workspace_mode: dict[str, Any] = Field(default_factory=dict)
    generator: dict[str, Any] = Field(default_factory=dict)
    catalog_overrides: dict[str, str] = Field(default_factory=dict)
