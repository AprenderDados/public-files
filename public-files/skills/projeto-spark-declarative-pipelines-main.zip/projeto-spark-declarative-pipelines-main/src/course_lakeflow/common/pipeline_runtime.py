from __future__ import annotations

from pathlib import Path


def resolve_pipeline_project_root(spark_session) -> Path:
    project_root = spark_session.conf.get("course_sdp.project_root", "").strip()
    if not project_root:
        raise ValueError(
            "Missing required pipeline configuration: course_sdp.project_root"
        )
    return Path(project_root)
