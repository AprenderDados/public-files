"""Shared configuration and utility components."""

