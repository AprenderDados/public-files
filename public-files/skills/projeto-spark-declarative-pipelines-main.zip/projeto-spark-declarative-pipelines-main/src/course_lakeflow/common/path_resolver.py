from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PathContext:
    environment: str
    catalog: str
    schema: str
    volume: str


class PathResolver:
    """Small helper responsible for turning logical refs into UC volume paths."""

    @staticmethod
    def volume_path(context: PathContext, relative_path: str) -> str:
        return f"/Volumes/{context.catalog}/{context.schema}/{context.volume}/{relative_path}".rstrip("/")

