"""Gold aggregation services."""

