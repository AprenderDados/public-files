from __future__ import annotations

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F


class ConformedDimensionService:
    @staticmethod
    def build_dim_product(
        product_df: DataFrame,
        subcategory_df: DataFrame,
        category_df: DataFrame,
        model_df: DataFrame,
        model_description_culture_df: DataFrame,
        description_df: DataFrame,
    ) -> DataFrame:
        product_descriptions = (
            model_description_culture_df.filter(F.upper(F.col("culture_id")) == F.lit("EN"))
            .withColumn(
                "_rn",
                F.row_number().over(
                    Window.partitionBy("product_model_id").orderBy(F.col("product_description_id").asc())
                ),
            )
            .filter(F.col("_rn") == 1)
            .drop("_rn")
            .join(description_df, on="product_description_id", how="left")
            .select("product_model_id", "product_description")
        )

        return (
            product_df.alias("p")
            .join(subcategory_df.alias("psc"), on="product_subcategory_id", how="left")
            .join(category_df.alias("pc"), on="product_category_id", how="left")
            .join(model_df.alias("pm"), on="product_model_id", how="left")
            .join(product_descriptions.alias("pd"), on="product_model_id", how="left")
            .select(
                "product_id",
                "product_name",
                "product_number",
                "product_model_id",
                F.col("product_model_name"),
                F.col("product_description"),
                "product_subcategory_id",
                "product_subcategory_name",
                "product_category_id",
                "product_category_name",
                "standard_cost",
                "list_price",
                "sell_start_date",
                "sell_end_date",
            )
        )

    @staticmethod
    def build_dim_customer(
        customer_df: DataFrame,
        store_df: DataFrame,
        person_df: DataFrame,
        business_entity_address_df: DataFrame,
        address_df: DataFrame,
        state_province_df: DataFrame,
        country_region_df: DataFrame,
        territory_df: DataFrame,
    ) -> DataFrame:
        address_bridge = (
            business_entity_address_df.alias("bea")
            .join(address_df.alias("a"), on="address_id", how="left")
            .join(state_province_df.alias("sp"), on="state_province_id", how="left")
            .join(
                country_region_df.alias("cr"),
                on=F.col("sp.country_region_code") == F.col("cr.country_region_code"),
                how="left",
            )
            .select(
                F.col("bea.business_entity_id"),
                F.col("bea.address_type_id"),
                F.col("bea.address_id"),
                F.col("a.address_line_1"),
                F.col("a.address_line_2"),
                F.col("a.city"),
                F.col("a.postal_code"),
                F.col("sp.state_province_name"),
                F.col("sp.country_region_code").alias("customer_country_region_code"),
                F.col("cr.country_region_name").alias("customer_country_region_name"),
            )
            .withColumn(
                "_rn",
                F.row_number().over(
                    Window.partitionBy("business_entity_id").orderBy(
                        F.col("address_type_id").asc_nulls_last(),
                        F.col("address_id").asc_nulls_last(),
                    )
                ),
            )
            .filter(F.col("_rn") == 1)
            .drop("_rn")
        )

        territory_enriched = (
            territory_df.alias("t")
            .join(
                country_region_df.alias("tcr"),
                on=F.col("t.country_region_code") == F.col("tcr.country_region_code"),
                how="left",
            )
            .select(
                F.col("t.territory_id"),
                F.col("t.territory_name"),
                F.col("t.territory_group"),
                F.col("t.country_region_code"),
                F.col("tcr.country_region_name"),
            )
        )

        business_entity_id = F.coalesce(F.col("c.person_id"), F.col("c.store_id"))
        person_name = F.trim(
            F.regexp_replace(
                F.concat_ws(" ", F.col("p.first_name"), F.col("p.middle_name"), F.col("p.last_name")),
                r"\s+",
                " ",
            )
        )

        return (
            customer_df.alias("c")
            .join(person_df.alias("p"), F.col("c.person_id") == F.col("p.business_entity_id"), "left")
            .join(store_df.alias("s"), F.col("c.store_id") == F.col("s.business_entity_id"), "left")
            .join(address_bridge.alias("ab"), business_entity_id == F.col("ab.business_entity_id"), "left")
            .join(territory_enriched.alias("t"), F.col("c.territory_id") == F.col("t.territory_id"), "left")
            .select(
                F.col("c.customer_id"),
                business_entity_id.alias("customer_business_entity_id"),
                F.when(F.col("c.store_id").isNotNull(), F.col("s.store_name"))
                .when(F.col("c.person_id").isNotNull(), person_name)
                .otherwise(F.concat(F.lit("Customer "), F.col("c.customer_id").cast("string")))
                .alias("customer_name"),
                F.when(F.col("c.store_id").isNotNull(), F.lit("STORE"))
                .when(F.col("c.person_id").isNotNull(), F.lit("PERSON"))
                .otherwise(F.lit("UNKNOWN"))
                .alias("customer_type"),
                F.when(F.col("c.store_id").isNotNull(), F.lit("STORE"))
                .when(F.col("c.person_id").isNotNull(), F.lit("INDIVIDUAL"))
                .otherwise(F.lit("UNKNOWN"))
                .alias("customer_segment"),
                F.col("c.territory_id"),
                F.col("t.territory_name"),
                F.col("t.territory_group"),
                F.col("t.country_region_code"),
                F.col("t.country_region_name"),
                F.col("p.title").alias("person_title"),
                F.col("p.first_name"),
                F.col("p.middle_name"),
                F.col("p.last_name"),
                F.col("p.suffix"),
                F.col("s.store_name"),
                F.col("ab.city").alias("customer_city"),
                F.col("ab.state_province_name").alias("customer_state_province_name"),
                F.col("ab.customer_country_region_name"),
                F.col("ab.postal_code").alias("customer_postal_code"),
            )
        )
