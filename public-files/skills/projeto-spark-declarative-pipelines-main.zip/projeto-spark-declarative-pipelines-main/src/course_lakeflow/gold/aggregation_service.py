from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F


class GoldAggregationService:
    """
    Exposes reusable gold detail and aggregation builders over the clean event ledger.
    """

    @staticmethod
    def build_sales_analytics_obt(
        events_df: DataFrame,
        product_dim_df: DataFrame,
        customer_dim_df: DataFrame,
    ) -> DataFrame:
        enriched_df = (
            events_df.alias("f")
            .join(
                product_dim_df.alias("p").select(
                    "product_id",
                    "product_name",
                    "product_number",
                    "product_model_name",
                    "product_category_name",
                    "product_subcategory_name",
                    "standard_cost",
                    "list_price",
                ),
                on="product_id",
                how="left",
            )
            .join(
                customer_dim_df.alias("c").select(
                    "customer_id",
                    "customer_business_entity_id",
                    "customer_name",
                    "customer_type",
                    "customer_segment",
                    "customer_city",
                    "customer_state_province_name",
                    "customer_country_region_name",
                    F.col("territory_id").alias("customer_territory_id"),
                    F.col("territory_name").alias("customer_territory_name"),
                    F.col("territory_group").alias("customer_territory_group"),
                    F.col("country_region_code").alias("territory_country_region_code"),
                    F.col("country_region_name").alias("territory_country_region_name"),
                    "person_title",
                    "first_name",
                    "middle_name",
                    "last_name",
                    "suffix",
                    "store_name",
                    "customer_postal_code",
                ),
                on="customer_id",
                how="left",
            )
        )

        return enriched_df.select(
            "sales_event_id",
            "order_id",
            "order_line_id",
            "event_type",
            "sales_date",
            "arrival_date",
            "product_id",
            "product_name",
            "product_number",
            "product_model_name",
            "product_category_name",
            "product_subcategory_name",
            "standard_cost",
            "list_price",
            "customer_id",
            "customer_business_entity_id",
            "customer_name",
            "customer_type",
            "customer_segment",
            "customer_city",
            "customer_state_province_name",
            "customer_country_region_name",
            F.coalesce(F.col("customer_territory_id"), F.col("f.territory_id")).alias("territory_id"),
            F.col("customer_territory_name").alias("territory_name"),
            F.col("customer_territory_group").alias("territory_group"),
            F.col("territory_country_region_code").alias("country_region_code"),
            F.col("territory_country_region_name").alias("country_region_name"),
            "person_title",
            "first_name",
            "middle_name",
            "last_name",
            "suffix",
            "store_name",
            "customer_postal_code",
            "quantity_delta",
            "amount_delta",
            "currency_code",
            "reference_event_id",
            "source_batch_id",
            "source_file_path",
        )

    @staticmethod
    def build_daily_sales(obt_df: DataFrame) -> DataFrame:
        return (
            obt_df.groupBy("sales_date")
            .agg(
                F.sum(F.col("quantity_delta")).cast("long").alias("net_quantity"),
                F.round(F.sum(F.col("amount_delta")), 2).cast("decimal(18,2)").alias("net_revenue"),
                F.count("*").alias("events_count"),
                F.sum(
                    F.when(F.col("event_type").isin("ADJUSTMENT", "CANCEL"), F.lit(1)).otherwise(F.lit(0))
                ).cast("long").alias("correction_events_count"),
            )
            .select("sales_date", "net_quantity", "net_revenue", "events_count", "correction_events_count")
        )

    @staticmethod
    def build_daily_sales_by_product(obt_df: DataFrame) -> DataFrame:
        return (
            obt_df.groupBy(
                "sales_date",
                "product_id",
                "product_name",
                "product_category_name",
                "product_subcategory_name",
            )
            .agg(
                F.sum(F.col("quantity_delta")).cast("long").alias("net_quantity"),
                F.round(F.sum(F.col("amount_delta")), 2).cast("decimal(18,2)").alias("net_revenue"),
                F.count("*").alias("events_count"),
            )
            .select(
                "sales_date",
                "product_id",
                "product_name",
                "product_category_name",
                "product_subcategory_name",
                "net_quantity",
                "net_revenue",
                "events_count",
            )
        )

    @staticmethod
    def build_arrival_vs_business_date(obt_df: DataFrame) -> DataFrame:
        return (
            obt_df.groupBy("arrival_date", "sales_date")
            .agg(
                F.count("*").alias("events_count"),
                F.sum(F.col("quantity_delta")).cast("long").alias("net_quantity"),
                F.round(F.sum(F.col("amount_delta")), 2).cast("decimal(18,2)").alias("net_revenue"),
                F.sum(
                    F.when(F.col("arrival_date") > F.col("sales_date"), F.lit(1)).otherwise(F.lit(0))
                ).cast("long").alias("late_events_count"),
            )
            .select("arrival_date", "sales_date", "events_count", "net_quantity", "net_revenue", "late_events_count")
        )

    @staticmethod
    def build_correction_impact(obt_df: DataFrame) -> DataFrame:
        return (
            obt_df.filter(F.col("event_type").isin("ADJUSTMENT", "CANCEL"))
            .groupBy("arrival_date", "sales_date", "event_type")
            .agg(
                F.count("*").alias("correction_events_count"),
                F.sum(F.col("quantity_delta")).cast("long").alias("net_quantity_impact"),
                F.round(F.sum(F.col("amount_delta")), 2).cast("decimal(18,2)").alias("net_revenue_impact"),
            )
            .select(
                "arrival_date",
                "sales_date",
                "event_type",
                "correction_events_count",
                "net_quantity_impact",
                "net_revenue_impact",
            )
        )
