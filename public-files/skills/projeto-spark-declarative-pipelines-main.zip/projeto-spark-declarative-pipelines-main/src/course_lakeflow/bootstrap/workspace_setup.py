from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from course_lakeflow.common.runtime_context import ResolvedProjectContext


@dataclass(frozen=True)
class WorkspaceSetupResult:
    user_prefix: str
    target_catalog: str
    target_schema: str
    target_volume: str
    volume_path: str


class WorkspaceBootstrapService:
    """
    Free-friendly setup helper.

    The initial course pattern keeps setup simple:
    - reuses the current catalog when needed
    - creates a user-isolated schema when possible
    - creates a shared volume with user subpaths
    """

    def __init__(self, spark_session):
        self.spark = spark_session

    def ensure_volume(self, volume_name: str, preferred_schema: str) -> WorkspaceSetupResult:
        current_user = self.spark.sql("SELECT current_user()").first()[0]
        current_catalog = self.spark.sql("SELECT current_catalog()").first()[0]
        current_schema = self.spark.sql("SELECT current_schema()").first()[0]

        user_prefix = self._safe_identifier(current_user)
        candidates: list[tuple[str, str, str]] = []
        for catalog in [current_catalog, "workspace", "main"]:
            for schema in [preferred_schema, "aprender_dados", current_schema, "default"]:
                candidate = (catalog, schema, volume_name)
                if candidate not in candidates:
                    candidates.append(candidate)

        errors: list[str] = []
        for catalog, schema, volume in candidates:
            try:
                self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
                self.spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
                return WorkspaceSetupResult(
                    user_prefix=user_prefix,
                    target_catalog=catalog,
                    target_schema=schema,
                    target_volume=volume,
                    volume_path=f"/Volumes/{catalog}/{schema}/{volume}",
                )
            except Exception as exc:  # pragma: no cover - requires Databricks runtime
                errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")

        raise RuntimeError(
            "Could not create or reuse a volume for the course scaffold.\n"
            f"Current catalog: {current_catalog}\n"
            f"Current schema: {current_schema}\n"
            + "\n".join(errors)
        )

    def provision_project_resources(self, context: ResolvedProjectContext) -> dict[str, list[str]]:
        """
        Creates the schemas and volumes resolved for the current environment.
        """

        created_schemas: list[str] = []
        created_volumes: list[str] = []

        for logical_schema, schema_name in context.schemas.items():
            catalog_name = (
                context.generator_ops_catalog
                if logical_schema == "ops"
                else context.lakeflow_catalog
            )
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}")
            created_schemas.append(f"{catalog_name}.{schema_name}")

        for volume_path in self._unique(context.volumes.values()):
            parts = volume_path.strip("/").split("/")
            if len(parts) != 4 or parts[0] != "Volumes":
                raise ValueError(f"Unexpected UC volume path format: {volume_path}")
            _, catalog, schema, volume = parts
            self.spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            created_volumes.append(f"{catalog}.{schema}.{volume}")

        return {
            "schemas": created_schemas,
            "volumes": created_volumes,
        }

    @staticmethod
    def _safe_identifier(value: str, max_length: int = 40) -> str:
        normalized = re.sub(r"[^a-zA-Z0-9_]", "_", value.lower())
        normalized = re.sub(r"_+", "_", normalized).strip("_")
        if not normalized:
            normalized = "student"
        if normalized[0].isdigit():
            normalized = f"u_{normalized}"
        return normalized[:max_length]

    @staticmethod
    def _unique(values: Iterable[str]) -> list[str]:
        seen: list[str] = []
        for value in values:
            if value not in seen:
                seen.append(value)
        return seen
