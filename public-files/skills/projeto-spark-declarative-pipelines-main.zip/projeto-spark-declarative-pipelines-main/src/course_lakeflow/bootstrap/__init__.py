"""Bootstrap services for workspace setup and future profiling steps."""

