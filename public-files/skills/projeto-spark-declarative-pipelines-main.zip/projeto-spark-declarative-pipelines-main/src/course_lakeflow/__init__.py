"""Core package for the didactic Lakeflow project."""

