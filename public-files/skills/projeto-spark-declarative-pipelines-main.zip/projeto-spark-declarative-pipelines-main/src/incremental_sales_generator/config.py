from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class GeneratorRunConfig:
    environment: str
    business_date: str | None = None
    arrival_date: str | None = None
    target_rows: int | None = None
    late_adjustment_rate: float | None = None
    cancel_rate: float | None = None
    random_seed: int | None = None


@dataclass(frozen=True)
class GeneratorDefaults:
    landing_file_format: str
    emit_header: bool
    coalesce_output_files: int
    parquet_output_files: int
    csv_max_rows_per_output_file: int
    max_registry_rows: int | None
    max_rows_for_late_events: int | None
    use_weighted_product_mix: bool
    allow_late_adjustments: bool


@dataclass(frozen=True)
class DimensionExportSpec:
    logical_name: str
    source_sql: str


@dataclass(frozen=True)
class FactGenerationSpec:
    logical_name: str
    source_sql: str


@dataclass(frozen=True)
class GeneratorProjectConfig:
    generator_name: str
    source_baseline_catalog: str
    state_tables: dict[str, str]
    defaults: GeneratorDefaults
    dimensions: dict[str, DimensionExportSpec]
    facts: dict[str, FactGenerationSpec]


class GeneratorConfigLoader:
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.config_root = project_root / "config" / "generator"

    def load(self) -> GeneratorProjectConfig:
        base_payload = self._read_yaml(self.config_root / "sales_generator.yml")
        dimensions_payload = self._read_yaml(self.config_root / "dimensions.yml").get("dimensions", {})
        facts_payload = self._read_yaml(self.config_root / "facts.yml").get("facts", {})

        dimensions = {
            logical_name: DimensionExportSpec(
                logical_name=logical_name,
                source_sql=payload["source_sql"],
            )
            for logical_name, payload in dimensions_payload.items()
        }
        facts = {
            logical_name: FactGenerationSpec(
                logical_name=logical_name,
                source_sql=payload["source_sql"],
            )
            for logical_name, payload in facts_payload.items()
        }

        defaults_payload = base_payload.get("defaults", {})
        defaults = GeneratorDefaults(
            landing_file_format=defaults_payload.get(
                "landing_file_format",
                defaults_payload.get("fact_file_format", "parquet"),
            ),
            emit_header=bool(defaults_payload.get("emit_header", True)),
            coalesce_output_files=int(defaults_payload.get("coalesce_output_files", 1)),
            parquet_output_files=int(
                defaults_payload.get(
                    "parquet_output_files",
                    defaults_payload.get("coalesce_output_files", 32),
                )
            ),
            csv_max_rows_per_output_file=int(
                defaults_payload.get(
                    "csv_max_rows_per_output_file",
                    defaults_payload.get("max_rows_per_output_file", 250_000),
                )
            ),
            max_registry_rows=(
                int(defaults_payload["max_registry_rows"])
                if defaults_payload.get("max_registry_rows") is not None
                else None
            ),
            max_rows_for_late_events=(
                int(defaults_payload["max_rows_for_late_events"])
                if defaults_payload.get("max_rows_for_late_events") is not None
                else None
            ),
            use_weighted_product_mix=bool(defaults_payload.get("use_weighted_product_mix", True)),
            allow_late_adjustments=bool(defaults_payload.get("allow_late_adjustments", True)),
        )

        return GeneratorProjectConfig(
            generator_name=base_payload.get("generator_name", "incremental_sales_generator"),
            source_baseline_catalog=base_payload["source_baseline_catalog"],
            state_tables=dict(base_payload.get("state_tables", {})),
            defaults=defaults,
            dimensions=dimensions,
            facts=facts,
        )

    @staticmethod
    def _read_yaml(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle) or {}
