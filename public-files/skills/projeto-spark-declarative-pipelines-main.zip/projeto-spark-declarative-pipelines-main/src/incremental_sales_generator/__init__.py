"""Auxiliary generator isolated from the Lakeflow pipeline package."""

