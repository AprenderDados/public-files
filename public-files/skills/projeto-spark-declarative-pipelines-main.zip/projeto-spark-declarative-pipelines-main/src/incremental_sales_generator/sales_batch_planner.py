from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from course_lakeflow.common.config_loader import ConfigLoader
from incremental_sales_generator.config import GeneratorRunConfig
from incremental_sales_generator.sales_profile_service import SalesProfileService
from incremental_sales_generator.state_repository import GeneratorState


@dataclass(frozen=True)
class SalesBatchPlan:
    environment: str
    batch_id: str
    business_date: date
    arrival_date: date
    target_sale_rows: int
    target_adjustment_rows: int
    target_cancel_rows: int
    random_seed: int


class SalesBatchPlanner:
    """
    Converts environment defaults plus generator state into a concrete batch plan.
    """

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.config_loader = ConfigLoader(project_root)

    def build_plan(
        self,
        run_config: GeneratorRunConfig,
        state: GeneratorState,
        profile_service: SalesProfileService | None = None,
    ) -> SalesBatchPlan:
        env_config = self.config_loader.load_environment(run_config.environment)
        generator_settings = env_config.generator

        base_target_rows = int(run_config.target_rows or generator_settings.get("target_daily_rows", 200))
        late_adjustment_rate = float(
            run_config.late_adjustment_rate
            if run_config.late_adjustment_rate is not None
            else generator_settings.get("late_adjustment_rate", 0.03)
        )
        cancel_rate = float(
            run_config.cancel_rate
            if run_config.cancel_rate is not None
            else generator_settings.get("cancel_rate", 0.01)
        )
        random_seed = int(run_config.random_seed or generator_settings.get("random_seed", 42))

        business_date = self._resolve_business_date(run_config, state)
        arrival_date = self._resolve_arrival_date(run_config, business_date)
        if arrival_date < business_date:
            raise ValueError(
                f"arrival_date ({arrival_date.isoformat()}) cannot be earlier than business_date ({business_date.isoformat()})"
            )

        weekday_factor = None
        if profile_service is not None and run_config.target_rows is None:
            weekday_factor = profile_service.get_weekday_factor(
                run_config.environment,
                self._spark_day_of_week(business_date),
            )
        target_sale_rows = max(
            int(round(base_target_rows * weekday_factor)),
            1,
        ) if weekday_factor is not None else base_target_rows

        target_adjustment_rows = max(int(target_sale_rows * late_adjustment_rate), 0)
        target_cancel_rows = max(int(target_sale_rows * cancel_rate), 0)

        batch_id = self._build_batch_id(run_config.environment, business_date, arrival_date)
        return SalesBatchPlan(
            environment=run_config.environment,
            batch_id=batch_id,
            business_date=business_date,
            arrival_date=arrival_date,
            target_sale_rows=target_sale_rows,
            target_adjustment_rows=target_adjustment_rows,
            target_cancel_rows=target_cancel_rows,
            random_seed=random_seed,
        )

    @staticmethod
    def _resolve_business_date(run_config: GeneratorRunConfig, state: GeneratorState) -> date:
        if run_config.business_date:
            return date.fromisoformat(run_config.business_date)
        if run_config.arrival_date:
            return date.fromisoformat(run_config.arrival_date)
        if state.last_business_date:
            return state.last_business_date + timedelta(days=1)
        return datetime.now(timezone.utc).date()

    @staticmethod
    def _resolve_arrival_date(run_config: GeneratorRunConfig, business_date: date) -> date:
        if run_config.arrival_date:
            return date.fromisoformat(run_config.arrival_date)
        return business_date

    @staticmethod
    def _build_batch_id(environment: str, business_date: date, arrival_date: date) -> str:
        timestamp_part = datetime.now(timezone.utc).strftime("%H%M%S")
        return (
            f"{environment}_fact_sales_events_"
            f"arrival_{arrival_date.strftime('%Y%m%d')}_"
            f"sales_{business_date.strftime('%Y%m%d')}_"
            f"{timestamp_part}"
        )

    @staticmethod
    def _spark_day_of_week(business_date: date) -> int:
        return ((business_date.weekday() + 1) % 7) + 1
