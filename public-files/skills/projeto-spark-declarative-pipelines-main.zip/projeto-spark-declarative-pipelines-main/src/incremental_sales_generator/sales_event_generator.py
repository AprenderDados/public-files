from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
import math
from pathlib import Path
import random

from pyspark import StorageLevel
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.runtime_context import ProjectContextResolver
from course_lakeflow.common.spark_schema import SparkSchemaBuilder
from incremental_sales_generator.config import GeneratorConfigLoader, GeneratorRunConfig
from incremental_sales_generator.sales_batch_planner import SalesBatchPlan, SalesBatchPlanner
from incremental_sales_generator.sales_profile_service import SalesProfileService
from incremental_sales_generator.state_repository import GenerationStateRepository


@dataclass(frozen=True)
class SalesBatchGenerationResult:
    environment: str
    batch_id: str
    business_date: str
    arrival_date: str
    sale_rows: int
    adjustment_rows: int
    cancel_rows: int
    total_rows: int
    output_path: str


@dataclass(frozen=True)
class ProductSamplingCandidate:
    product_id: int
    candidate_rows: int
    product_share: float


@dataclass(frozen=True)
class ProductSamplingConfig:
    use_weighted_product_mix: bool
    min_distinct_products: int
    max_distinct_products: int
    product_mix_temperature: float
    max_product_share_per_batch: float


class SalesEventGenerator:
    """
    Generates isolated landing batches for fact event ingestion.
    """

    def __init__(self, spark_session, project_root: Path):
        self.spark = spark_session
        self.project_root = project_root
        self.table_loader = ConfigLoader(project_root)
        self.generator_loader = GeneratorConfigLoader(project_root)
        self.context_resolver = ProjectContextResolver(spark_session, project_root)
        self.state_repository = GenerationStateRepository(spark_session, project_root)
        self.planner = SalesBatchPlanner(project_root)
        self.profile_service = SalesProfileService(spark_session, project_root)

    def generate_batch(self, run_config: GeneratorRunConfig) -> SalesBatchGenerationResult:
        project_config = self.generator_loader.load()
        environment_config = self.table_loader.load_environment(run_config.environment)
        runtime_context = self.context_resolver.resolve(run_config.environment)
        fact_spec = self.table_loader.load_table_spec("bronze", "fact_sales_events_raw.yml")
        fact_source_spec = project_config.facts["fact_sales_events_raw"]

        state = self.state_repository.get_or_create_state(run_config.environment)
        plan = self.planner.build_plan(run_config, state, self.profile_service)

        sales_df = None
        adjustment_df = None
        cancel_df = None
        batch_df = None
        persisted_dfs: list[DataFrame] = []
        try:
            sales_df = self._build_sale_events(
                project_config.source_baseline_catalog,
                fact_source_spec.source_sql,
                fact_spec.schema,
                plan,
                state.next_sales_event_id,
                state.next_order_id,
                state.next_order_line_id,
                self._resolve_product_sampling_config(
                    environment_config.generator,
                    project_config.defaults.use_weighted_product_mix,
                ),
            )
            sales_df = self._persist_if_supported(sales_df, persisted_dfs)
            sale_rows = sales_df.count()

            if self._should_generate_late_events(
                sale_rows=sale_rows,
                allow_late_adjustments=project_config.defaults.allow_late_adjustments,
                max_rows_for_late_events=project_config.defaults.max_rows_for_late_events,
            ):
                adjustment_df, cancel_df = self._build_late_events(
                    environment=run_config.environment,
                    fact_schema=fact_spec.schema,
                    plan=plan,
                    starting_sales_event_id=state.next_sales_event_id + sale_rows,
                )
                adjustment_df = self._persist_if_supported(adjustment_df, persisted_dfs)
                cancel_df = self._persist_if_supported(cancel_df, persisted_dfs)
                adjustment_rows = adjustment_df.count()
                cancel_rows = cancel_df.count()
            else:
                adjustment_df = self._empty_fact_df(fact_spec.schema)
                cancel_df = self._empty_fact_df(fact_spec.schema)
                adjustment_rows = 0
                cancel_rows = 0

            batch_df = self._persist_if_supported(
                sales_df.unionByName(adjustment_df).unionByName(cancel_df),
                persisted_dfs,
            )
            total_rows = sale_rows + adjustment_rows + cancel_rows

            output_path = f"{runtime_context.data_path(fact_spec.path_ref)}/{plan.batch_id}"
            self._write_batch_files(
                batch_df=batch_df,
                output_path=output_path,
                total_rows=total_rows,
                coalesce_output_files=project_config.defaults.coalesce_output_files,
                parquet_output_files=project_config.defaults.parquet_output_files,
                csv_max_rows_per_output_file=project_config.defaults.csv_max_rows_per_output_file,
                file_format=project_config.defaults.landing_file_format,
                emit_header=project_config.defaults.emit_header,
            )

            registry_df = (
                sales_df.withColumn("batch_id", F.lit(plan.batch_id))
                .withColumn("created_at", F.current_timestamp())
            )
            if self._should_append_registry(sale_rows, project_config.defaults.max_registry_rows):
                self.state_repository.append_registry(run_config.environment, registry_df)

            manifest_df = self.spark.createDataFrame(
                [
                    (
                        run_config.environment,
                        plan.batch_id,
                        plan.business_date.isoformat(),
                        plan.arrival_date.isoformat(),
                        sale_rows,
                        adjustment_rows,
                        cancel_rows,
                        output_path,
                        plan.random_seed,
                        datetime.utcnow(),
                    )
                ],
                """
                environment STRING,
                batch_id STRING,
                business_date STRING,
                arrival_date STRING,
                sale_rows LONG,
                adjustment_rows LONG,
                cancel_rows LONG,
                output_path STRING,
                random_seed LONG,
                created_at TIMESTAMP
                """,
            ).select(
                "environment",
                "batch_id",
                F.col("business_date").cast("date").alias("business_date"),
                F.col("arrival_date").cast("date").alias("arrival_date"),
                "sale_rows",
                "adjustment_rows",
                "cancel_rows",
                "output_path",
                "random_seed",
                "created_at",
            )
            self.state_repository.append_manifest(run_config.environment, manifest_df)

            updated_last_business_date = max(
                [value for value in [state.last_business_date, plan.business_date] if value is not None]
            )
            self.state_repository.update_state(
                environment=run_config.environment,
                last_business_date=updated_last_business_date,
                next_sales_event_id=state.next_sales_event_id + total_rows,
                next_order_id=state.next_order_id + sale_rows,
                next_order_line_id=state.next_order_line_id + sale_rows,
            )

            return SalesBatchGenerationResult(
                environment=run_config.environment,
                batch_id=plan.batch_id,
                business_date=plan.business_date.isoformat(),
                arrival_date=plan.arrival_date.isoformat(),
                sale_rows=sale_rows,
                adjustment_rows=adjustment_rows,
                cancel_rows=cancel_rows,
                total_rows=total_rows,
                output_path=output_path,
            )
        finally:
            for df in reversed(persisted_dfs):
                df.unpersist(blocking=False)

    @staticmethod
    def as_dict(result: SalesBatchGenerationResult) -> dict[str, str | int]:
        return asdict(result)

    def _build_sale_events(
        self,
        source_catalog: str,
        source_sql: str,
        fact_schema,
        plan: SalesBatchPlan,
        starting_sales_event_id: int,
        starting_order_id: int,
        starting_order_line_id: int,
        sampling_config: ProductSamplingConfig,
    ) -> DataFrame:
        source_df = self.spark.sql(source_sql.format(source_catalog=source_catalog))
        source_df = source_df.filter(
            (F.col("quantity_delta") > 0) & (F.col("amount_delta") > 0)
        )

        weekday_value = self._spark_day_of_week(plan.business_date)
        weekday_df = source_df.filter(F.dayofweek("source_sales_date") == F.lit(weekday_value))
        weekday_capacity = weekday_df.limit(plan.target_sale_rows).count()
        candidate_df = weekday_df if weekday_capacity >= plan.target_sale_rows else source_df

        sampled_df = self._sample_sale_candidates(
            candidate_df=candidate_df,
            environment=plan.environment,
            target_rows=plan.target_sale_rows,
            random_seed=plan.random_seed,
            sampling_config=sampling_config,
        )
        if "_generated_sequence_id" in sampled_df.columns:
            sequenced_df = sampled_df.withColumn(
                "_sequence_id",
                F.col("_generated_sequence_id"),
            ).drop("_generated_sequence_id")
        else:
            sequence_window = Window.orderBy(
                F.rand(plan.random_seed + 1),
                F.monotonically_increasing_id(),
            )
            sequenced_df = sampled_df.withColumn("_sequence_id", F.row_number().over(sequence_window))

        sale_df = (
            sequenced_df.withColumn(
                "sales_event_id",
                F.lit(starting_sales_event_id) + F.col("_sequence_id") - 1,
            )
            .withColumn("order_id", F.lit(starting_order_id) + F.col("_sequence_id") - 1)
            .withColumn("order_line_id", F.lit(starting_order_line_id) + F.col("_sequence_id") - 1)
            .withColumn("event_type", F.lit("SALE"))
            .withColumn("sales_date", F.lit(plan.business_date.isoformat()).cast("date"))
            .withColumn("arrival_date", F.lit(plan.arrival_date.isoformat()).cast("date"))
            .withColumn("reference_event_id", F.lit(None).cast("long"))
        )
        return self._project_fact_schema(sale_df, fact_schema)

    def _build_late_events(
        self,
        environment: str,
        fact_schema,
        plan: SalesBatchPlan,
        starting_sales_event_id: int,
    ) -> tuple[DataFrame, DataFrame]:
        empty_df = self._empty_fact_df(fact_schema)
        total_late_rows = plan.target_adjustment_rows + plan.target_cancel_rows
        if total_late_rows == 0:
            return empty_df, empty_df

        registry_df = (
            self.spark.table(self.state_repository.registry_table(environment))
            .where(F.col("environment") == environment)
            .where(F.col("event_type") == "SALE")
            .where(F.col("sales_date") < F.lit(plan.arrival_date.isoformat()).cast("date"))
        )
        if not self._has_rows(registry_df):
            return empty_df, empty_df

        adjustment_base = registry_df.orderBy(F.rand(plan.random_seed + 10)).limit(plan.target_adjustment_rows)
        cancel_base = registry_df.orderBy(F.rand(plan.random_seed + 20)).limit(plan.target_cancel_rows)

        adjustment_df = self._build_adjustments(
            adjustment_base,
            starting_sales_event_id,
            plan,
            fact_schema,
            seed=plan.random_seed + 11,
        )
        adjustment_rows = adjustment_df.count()

        cancel_df = self._build_cancels(
            cancel_base,
            starting_sales_event_id + adjustment_rows,
            plan,
            fact_schema,
            seed=plan.random_seed + 21,
        )
        return adjustment_df, cancel_df

    def _build_adjustments(self, base_df: DataFrame, start_event_id: int, plan: SalesBatchPlan, fact_schema, seed: int) -> DataFrame:
        if not self._has_rows(base_df):
            return self._empty_fact_df(fact_schema)

        sequence_window = Window.orderBy(F.rand(seed))
        sign_column = F.when((F.col("_sequence_id") % 2) == 0, F.lit(1)).otherwise(F.lit(-1))
        unit_amount = (
            F.abs(F.col("amount_delta")) / F.greatest(F.abs(F.col("quantity_delta")), F.lit(1))
        )

        return (
            base_df.withColumn("_original_sales_event_id", F.col("sales_event_id"))
            .withColumn("_sequence_id", F.row_number().over(sequence_window))
            .withColumn("sales_event_id", F.lit(start_event_id) + F.col("_sequence_id") - 1)
            .withColumn("event_type", F.lit("ADJUSTMENT"))
            .withColumn("arrival_date", F.lit(plan.arrival_date.isoformat()).cast("date"))
            .withColumn("quantity_delta", sign_column.cast("int"))
            .withColumn(
                "amount_delta",
                F.round(unit_amount * sign_column.cast("double"), 2).cast("decimal(18,2)"),
            )
            .withColumn("reference_event_id", F.col("_original_sales_event_id"))
            .transform(lambda df: self._project_fact_schema(df, fact_schema))
        )

    def _build_cancels(self, base_df: DataFrame, start_event_id: int, plan: SalesBatchPlan, fact_schema, seed: int) -> DataFrame:
        if not self._has_rows(base_df):
            return self._empty_fact_df(fact_schema)

        sequence_window = Window.orderBy(F.rand(seed))
        return (
            base_df.withColumn("_original_sales_event_id", F.col("sales_event_id"))
            .withColumn("_sequence_id", F.row_number().over(sequence_window))
            .withColumn("sales_event_id", F.lit(start_event_id) + F.col("_sequence_id") - 1)
            .withColumn("event_type", F.lit("CANCEL"))
            .withColumn("arrival_date", F.lit(plan.arrival_date.isoformat()).cast("date"))
            .withColumn("quantity_delta", (-F.abs(F.col("quantity_delta"))).cast("int"))
            .withColumn("amount_delta", (-F.abs(F.col("amount_delta"))).cast("decimal(18,2)"))
            .withColumn("reference_event_id", F.col("_original_sales_event_id"))
            .transform(lambda df: self._project_fact_schema(df, fact_schema))
        )

    def _empty_fact_df(self, fact_schema) -> DataFrame:
        return self.spark.createDataFrame([], SparkSchemaBuilder.build(fact_schema))

    def _sample_sale_candidates(
        self,
        candidate_df: DataFrame,
        environment: str,
        target_rows: int,
        random_seed: int,
        sampling_config: ProductSamplingConfig,
    ) -> DataFrame:
        if target_rows <= 0:
            return candidate_df.limit(0)

        candidate_capacity = candidate_df.limit(target_rows + 1).count()
        if candidate_capacity <= 0:
            return candidate_df.limit(0)

        if candidate_capacity <= target_rows:
            return self._sample_sale_candidates_with_replacement(
                candidate_df=candidate_df,
                candidate_count=candidate_capacity,
                target_rows=target_rows,
                random_seed=random_seed,
            )

        product_stats_df = candidate_df.groupBy("product_id").agg(
            F.count("*").cast("int").alias("candidate_rows")
        )

        product_mix_df = None
        if sampling_config.use_weighted_product_mix:
            product_mix_df = self.profile_service.get_product_mix(environment)

        if product_mix_df is not None:
            product_stats_df = product_stats_df.join(
                F.broadcast(product_mix_df),
                on="product_id",
                how="left",
            )
        else:
            product_stats_df = product_stats_df.withColumn("product_share", F.lit(None).cast("double"))

        candidates = [
            ProductSamplingCandidate(
                product_id=int(row["product_id"]),
                candidate_rows=int(row["candidate_rows"]),
                product_share=float(row["product_share"] or 0.0),
            )
            for row in product_stats_df.collect()
        ]
        quotas = self._plan_product_quotas(
            candidates=candidates,
            target_rows=target_rows,
            random_seed=random_seed,
            sampling_config=sampling_config,
        )
        if not quotas:
            return candidate_df.orderBy(F.rand(random_seed)).limit(target_rows)

        quota_rows = [(product_id, quota) for product_id, quota in quotas.items() if quota > 0]
        quotas_df = self.spark.createDataFrame(
            quota_rows,
            "product_id LONG, quota INT",
        )
        sample_window = Window.partitionBy("product_id").orderBy(F.rand(random_seed + 2))
        return (
            candidate_df.join(F.broadcast(quotas_df), on="product_id", how="inner")
            .withColumn("_sample_rank", F.row_number().over(sample_window))
            .where(F.col("_sample_rank") <= F.col("quota"))
            .drop("_sample_rank", "quota")
        )

    def _sample_sale_candidates_with_replacement(
        self,
        candidate_df: DataFrame,
        candidate_count: int,
        target_rows: int,
        random_seed: int,
    ) -> DataFrame:
        indexed_df = candidate_df.withColumn(
            "_candidate_index",
            F.row_number().over(
                Window.orderBy(
                    F.rand(random_seed + 31),
                    F.monotonically_increasing_id(),
                )
            ),
        )
        sequence_df = (
            self.spark.range(target_rows)
            .withColumn("_generated_sequence_id", F.col("id") + F.lit(1))
            .withColumn("_candidate_index", (F.col("id") % F.lit(candidate_count)) + F.lit(1))
            .withColumn("_generation_cycle", F.floor(F.col("id") / F.lit(candidate_count)))
            .withColumn("_quantity_factor", ((F.col("id") % F.lit(3)) + F.lit(1)).cast("int"))
        )

        return (
            sequence_df.join(F.broadcast(indexed_df), on="_candidate_index", how="inner")
            .withColumn("quantity_delta", (F.col("quantity_delta") * F.col("_quantity_factor")).cast("int"))
            .withColumn(
                "amount_delta",
                F.round(
                    F.col("amount_delta").cast("double")
                    * F.col("_quantity_factor").cast("double")
                    * (
                        F.lit(1.0)
                        + (F.col("_generation_cycle") % F.lit(17)).cast("double")
                        / F.lit(1000.0)
                    ),
                    2,
                ).cast("decimal(18,2)"),
            )
            .drop("id", "_candidate_index", "_generation_cycle", "_quantity_factor")
        )

    @staticmethod
    def _write_batch_files(
        batch_df: DataFrame,
        output_path: str,
        total_rows: int,
        coalesce_output_files: int,
        parquet_output_files: int,
        csv_max_rows_per_output_file: int,
        file_format: str,
        emit_header: bool,
    ) -> None:
        normalized_format = file_format.strip().lower()
        target_files = SalesEventGenerator._resolve_target_file_count(
            total_rows=total_rows,
            coalesce_output_files=coalesce_output_files,
            parquet_output_files=parquet_output_files,
            csv_max_rows_per_output_file=csv_max_rows_per_output_file,
            file_format=normalized_format,
        )
        if target_files <= coalesce_output_files:
            writer_df = batch_df.coalesce(target_files)
        else:
            writer_df = batch_df.repartition(target_files)
        writer = writer_df.write.mode("overwrite")
        if normalized_format == "parquet":
            writer.parquet(output_path)
            return
        if normalized_format == "csv":
            writer.option("header", emit_header).csv(output_path)
            return
        raise ValueError(
            f"Unsupported landing file format '{file_format}'. "
            "Supported values: parquet, csv."
        )

    @staticmethod
    def _resolve_target_file_count(
        total_rows: int,
        coalesce_output_files: int,
        parquet_output_files: int,
        csv_max_rows_per_output_file: int,
        file_format: str,
    ) -> int:
        normalized_format = file_format.strip().lower()
        if normalized_format == "parquet":
            return max(coalesce_output_files, parquet_output_files, 1)
        if normalized_format == "csv":
            return max(
                coalesce_output_files,
                int(math.ceil(max(total_rows, 1) / max(csv_max_rows_per_output_file, 1))),
            )
        raise ValueError(
            f"Unsupported landing file format '{file_format}'. "
            "Supported values: parquet, csv."
        )

    @staticmethod
    def _persist_if_supported(df: DataFrame, persisted_dfs: list[DataFrame]) -> DataFrame:
        try:
            persisted_df = df.persist(StorageLevel.MEMORY_AND_DISK)
        except Exception as exc:
            if "[NOT_SUPPORTED_WITH_SERVERLESS]" in str(exc):
                return df
            raise

        persisted_dfs.append(persisted_df)
        return persisted_df

    @staticmethod
    def _should_append_registry(total_rows: int, max_registry_rows: int | None) -> bool:
        return max_registry_rows is None or total_rows <= max_registry_rows

    @staticmethod
    def _should_generate_late_events(
        sale_rows: int,
        allow_late_adjustments: bool,
        max_rows_for_late_events: int | None,
    ) -> bool:
        return (
            allow_late_adjustments
            and (max_rows_for_late_events is None or sale_rows <= max_rows_for_late_events)
        )

    @staticmethod
    def _has_rows(df: DataFrame) -> bool:
        return bool(df.take(1))

    @staticmethod
    def _resolve_product_sampling_config(
        generator_settings: dict[str, object],
        use_weighted_product_mix: bool,
    ) -> ProductSamplingConfig:
        min_distinct_products = max(int(generator_settings.get("min_distinct_products", 12)), 1)
        max_distinct_products = max(
            int(generator_settings.get("max_distinct_products", 60)),
            min_distinct_products,
        )
        return ProductSamplingConfig(
            use_weighted_product_mix=use_weighted_product_mix,
            min_distinct_products=min_distinct_products,
            max_distinct_products=max_distinct_products,
            product_mix_temperature=max(float(generator_settings.get("product_mix_temperature", 0.35)), 0.01),
            max_product_share_per_batch=min(
                max(float(generator_settings.get("max_product_share_per_batch", 0.12)), 0.01),
                1.0,
            ),
        )

    @staticmethod
    def _plan_product_quotas(
        candidates: list[ProductSamplingCandidate],
        target_rows: int,
        random_seed: int,
        sampling_config: ProductSamplingConfig,
    ) -> dict[int, int]:
        if not candidates or target_rows <= 0:
            return {}

        total_available_rows = sum(candidate.candidate_rows for candidate in candidates)
        if total_available_rows <= 0:
            return {}

        max_rows_per_product = max(
            1,
            int(math.ceil(target_rows * sampling_config.max_product_share_per_batch)),
        )
        rng = random.Random(random_seed)

        def capacity(candidate: ProductSamplingCandidate) -> int:
            return min(candidate.candidate_rows, max_rows_per_product)

        viable_candidates = [candidate for candidate in candidates if capacity(candidate) > 0]
        if not viable_candidates:
            return {}

        min_distinct_products = min(
            sampling_config.min_distinct_products,
            target_rows,
            len(viable_candidates),
        )
        max_distinct_products = min(
            sampling_config.max_distinct_products,
            target_rows,
            len(viable_candidates),
        )
        desired_distinct_products = min(
            max_distinct_products,
            max(int(round(math.sqrt(target_rows))), min_distinct_products),
        )

        quotas: dict[int, int] = {}
        seeded_products = SalesEventGenerator._weighted_sample_without_replacement(
            candidates=viable_candidates,
            sample_size=desired_distinct_products,
            rng=rng,
            sampling_config=sampling_config,
        )
        for candidate in seeded_products:
            quotas[candidate.product_id] = 1

        remaining_rows = target_rows - sum(quotas.values())
        while remaining_rows > 0:
            allocatable_candidates = [
                candidate
                for candidate in viable_candidates
                if quotas.get(candidate.product_id, 0) < capacity(candidate)
            ]
            if not allocatable_candidates:
                break
            chosen_candidate = SalesEventGenerator._weighted_choice(
                candidates=allocatable_candidates,
                rng=rng,
                sampling_config=sampling_config,
            )
            quotas[chosen_candidate.product_id] = quotas.get(chosen_candidate.product_id, 0) + 1
            remaining_rows -= 1

        return quotas

    @staticmethod
    def _weighted_sample_without_replacement(
        candidates: list[ProductSamplingCandidate],
        sample_size: int,
        rng: random.Random,
        sampling_config: ProductSamplingConfig,
    ) -> list[ProductSamplingCandidate]:
        remaining = list(candidates)
        selected: list[ProductSamplingCandidate] = []
        while remaining and len(selected) < sample_size:
            chosen = SalesEventGenerator._weighted_choice(remaining, rng, sampling_config)
            selected.append(chosen)
            remaining = [candidate for candidate in remaining if candidate.product_id != chosen.product_id]
        return selected

    @staticmethod
    def _weighted_choice(
        candidates: list[ProductSamplingCandidate],
        rng: random.Random,
        sampling_config: ProductSamplingConfig,
    ) -> ProductSamplingCandidate:
        weights = [
            SalesEventGenerator._candidate_weight(candidate, sampling_config)
            for candidate in candidates
        ]
        total_weight = sum(weights)
        if total_weight <= 0:
            return rng.choice(candidates)

        threshold = rng.random() * total_weight
        running_weight = 0.0
        for candidate, weight in zip(candidates, weights):
            running_weight += weight
            if running_weight >= threshold:
                return candidate
        return candidates[-1]

    @staticmethod
    def _candidate_weight(
        candidate: ProductSamplingCandidate,
        sampling_config: ProductSamplingConfig,
    ) -> float:
        if not sampling_config.use_weighted_product_mix:
            return 1.0

        base_share = max(candidate.product_share, 0.000001)
        softened_share = math.pow(base_share, sampling_config.product_mix_temperature)
        availability_factor = math.sqrt(max(candidate.candidate_rows, 1))
        return softened_share * availability_factor

    @staticmethod
    def _project_fact_schema(df: DataFrame, fact_schema) -> DataFrame:
        projected_columns = [
            F.col(field.name).cast(field.type).alias(field.name)
            for field in fact_schema
        ]
        return df.select(*projected_columns)

    @staticmethod
    def _spark_day_of_week(business_date) -> int:
        # Python weekday: Monday=0. Spark dayofweek: Sunday=1.
        return ((business_date.weekday() + 1) % 7) + 1
