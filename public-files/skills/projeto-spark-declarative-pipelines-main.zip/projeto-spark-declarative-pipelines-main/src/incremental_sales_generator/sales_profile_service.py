from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from course_lakeflow.common.runtime_context import ProjectContextResolver
from incremental_sales_generator.config import GeneratorConfigLoader


@dataclass(frozen=True)
class SalesProfileBuildResult:
    environment: str
    weekday_rows: int
    product_rows: int
    territory_rows: int


class SalesProfileService:
    """
    Builds and reads simple statistical profiles for the isolated fact generator.
    """

    def __init__(self, spark_session, project_root: Path):
        self.spark = spark_session
        self.project_root = project_root
        self.context_resolver = ProjectContextResolver(spark_session, project_root)
        self.generator_loader = GeneratorConfigLoader(project_root)

    def build_profiles(self, environment: str) -> SalesProfileBuildResult:
        config = self.generator_loader.load()
        context = self.context_resolver.resolve(environment)
        fact_source_spec = config.facts["fact_sales_events_raw"]

        base_df = self.spark.sql(
            fact_source_spec.source_sql.format(
                source_catalog=config.source_baseline_catalog,
            )
        )

        weekday_table = context.ops_table_fqn(config.state_tables["sales_profile_weekday"])
        product_table = context.ops_table_fqn(config.state_tables["sales_profile_product_mix"])
        territory_table = context.ops_table_fqn(config.state_tables["sales_profile_territory_mix"])

        self._ensure_profile_tables(weekday_table, product_table, territory_table)

        weekday_df = self._build_weekday_profile(environment, base_df)
        product_df = self._build_product_profile(environment, base_df)
        territory_df = self._build_territory_profile(environment, base_df)

        weekday_df.write.mode("overwrite").format("delta").saveAsTable(weekday_table)
        product_df.write.mode("overwrite").format("delta").saveAsTable(product_table)
        territory_df.write.mode("overwrite").format("delta").saveAsTable(territory_table)

        return SalesProfileBuildResult(
            environment=environment,
            weekday_rows=weekday_df.count(),
            product_rows=product_df.count(),
            territory_rows=territory_df.count(),
        )

    def get_weekday_factor(self, environment: str, spark_weekday: int) -> float | None:
        config = self.generator_loader.load()
        context = self.context_resolver.resolve(environment)
        table_name = context.ops_table_fqn(config.state_tables["sales_profile_weekday"])
        if not self._table_exists(table_name):
            return None

        row = (
            self.spark.table(table_name)
            .where(F.col("environment") == environment)
            .where(F.col("weekday_number") == spark_weekday)
            .select("relative_factor")
            .limit(1)
            .collect()
        )
        return float(row[0]["relative_factor"]) if row else None

    def get_product_mix(self, environment: str) -> DataFrame | None:
        config = self.generator_loader.load()
        context = self.context_resolver.resolve(environment)
        table_name = context.ops_table_fqn(config.state_tables["sales_profile_product_mix"])
        if not self._table_exists(table_name):
            return None

        return (
            self.spark.table(table_name)
            .where(F.col("environment") == environment)
            .select("product_id", "product_share")
        )

    def _build_weekday_profile(self, environment: str, base_df: DataFrame) -> DataFrame:
        daily_df = (
            base_df.groupBy("source_sales_date")
            .agg(F.count("*").alias("daily_rows"))
            .withColumn("weekday_number", F.dayofweek("source_sales_date"))
            .withColumn("weekday_name", F.date_format("source_sales_date", "E"))
        )

        weekday_agg_df = (
            daily_df.groupBy("weekday_number", "weekday_name")
            .agg(
                F.round(F.avg("daily_rows"), 4).alias("avg_daily_rows"),
                F.min("daily_rows").cast("long").alias("min_daily_rows"),
                F.max("daily_rows").cast("long").alias("max_daily_rows"),
            )
        )

        overall_avg_df = weekday_agg_df.agg(F.avg("avg_daily_rows").alias("overall_avg_daily_rows"))
        return (
            weekday_agg_df.crossJoin(overall_avg_df)
            .withColumn("environment", F.lit(environment))
            .withColumn(
                "relative_factor",
                F.round(F.col("avg_daily_rows") / F.col("overall_avg_daily_rows"), 6),
            )
            .withColumn("computed_at", F.current_timestamp())
            .select(
                "environment",
                "weekday_number",
                "weekday_name",
                "avg_daily_rows",
                "relative_factor",
                "min_daily_rows",
                "max_daily_rows",
                "computed_at",
            )
        )

    def _build_product_profile(self, environment: str, base_df: DataFrame) -> DataFrame:
        total_lines_df = base_df.agg(F.count("*").alias("total_lines"))
        return (
            base_df.groupBy("product_id")
            .agg(
                F.count("*").cast("long").alias("line_count"),
                F.round(F.avg("quantity_delta"), 4).alias("avg_quantity"),
                F.round(F.avg("amount_delta"), 2).cast("decimal(18,2)").alias("avg_amount"),
            )
            .crossJoin(total_lines_df)
            .withColumn("environment", F.lit(environment))
            .withColumn(
                "product_share",
                F.round(F.col("line_count") / F.col("total_lines"), 8),
            )
            .withColumn("computed_at", F.current_timestamp())
            .select(
                "environment",
                "product_id",
                "line_count",
                "product_share",
                "avg_quantity",
                "avg_amount",
                "computed_at",
            )
        )

    def _build_territory_profile(self, environment: str, base_df: DataFrame) -> DataFrame:
        total_lines_df = base_df.agg(F.count("*").alias("total_lines"))
        return (
            base_df.groupBy("territory_id")
            .agg(F.count("*").cast("long").alias("line_count"))
            .crossJoin(total_lines_df)
            .withColumn("environment", F.lit(environment))
            .withColumn(
                "territory_share",
                F.round(F.col("line_count") / F.col("total_lines"), 8),
            )
            .withColumn("computed_at", F.current_timestamp())
            .select(
                "environment",
                "territory_id",
                "line_count",
                "territory_share",
                "computed_at",
            )
        )

    def _ensure_profile_tables(self, weekday_table: str, product_table: str, territory_table: str) -> None:
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {weekday_table} (
              environment STRING NOT NULL,
              weekday_number INT NOT NULL,
              weekday_name STRING NOT NULL,
              avg_daily_rows DOUBLE NOT NULL,
              relative_factor DOUBLE NOT NULL,
              min_daily_rows BIGINT NOT NULL,
              max_daily_rows BIGINT NOT NULL,
              computed_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {product_table} (
              environment STRING NOT NULL,
              product_id BIGINT NOT NULL,
              line_count BIGINT NOT NULL,
              product_share DOUBLE NOT NULL,
              avg_quantity DOUBLE NOT NULL,
              avg_amount DECIMAL(18,2) NOT NULL,
              computed_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {territory_table} (
              environment STRING NOT NULL,
              territory_id BIGINT,
              line_count BIGINT NOT NULL,
              territory_share DOUBLE NOT NULL,
              computed_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )

    def _table_exists(self, table_name: str) -> bool:
        return bool(self.spark.catalog.tableExists(table_name))
