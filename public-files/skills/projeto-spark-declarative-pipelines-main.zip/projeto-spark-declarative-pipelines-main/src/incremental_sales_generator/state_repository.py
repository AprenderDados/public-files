from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path

from pyspark.sql import functions as F

from course_lakeflow.common.runtime_context import ProjectContextResolver
from incremental_sales_generator.config import GeneratorConfigLoader


@dataclass(frozen=True)
class GeneratorState:
    environment: str
    last_business_date: date | None
    next_sales_event_id: int
    next_order_id: int
    next_order_line_id: int


class GenerationStateRepository:
    """
    Persists generator progress in lightweight Delta tables under the ops schema.
    """

    def __init__(self, spark_session, project_root: Path):
        self.spark = spark_session
        self.project_root = project_root
        self.context_resolver = ProjectContextResolver(spark_session, project_root)
        self.config_loader = GeneratorConfigLoader(project_root)

    def get_or_create_state(self, environment: str) -> GeneratorState:
        self.ensure_tables(environment)
        table_name = self._state_table(environment)
        row = (
            self.spark.table(table_name)
            .where(f"environment = '{environment}'")
            .limit(1)
            .collect()
        )
        if row:
            payload = row[0].asDict()
            return GeneratorState(
                environment=payload["environment"],
                last_business_date=payload["last_business_date"],
                next_sales_event_id=int(payload["next_sales_event_id"]),
                next_order_id=int(payload["next_order_id"]),
                next_order_line_id=int(payload["next_order_line_id"]),
            )

        self.spark.sql(
            f"""
            INSERT INTO {table_name}
            (environment, last_business_date, next_sales_event_id, next_order_id, next_order_line_id, updated_at)
            VALUES ('{environment}', NULL, 1, 1, 1, current_timestamp())
            """
        )
        return GeneratorState(
            environment=environment,
            last_business_date=None,
            next_sales_event_id=1,
            next_order_id=1,
            next_order_line_id=1,
        )

    def update_state(
        self,
        environment: str,
        last_business_date: date,
        next_sales_event_id: int,
        next_order_id: int,
        next_order_line_id: int,
    ) -> None:
        table_name = self._state_table(environment)
        self.spark.sql(
            f"""
            MERGE INTO {table_name} AS target
            USING (
              SELECT
                '{environment}' AS environment,
                DATE('{last_business_date.isoformat()}') AS last_business_date,
                {next_sales_event_id} AS next_sales_event_id,
                {next_order_id} AS next_order_id,
                {next_order_line_id} AS next_order_line_id,
                current_timestamp() AS updated_at
            ) AS source
            ON target.environment = source.environment
            WHEN MATCHED THEN UPDATE SET
              target.last_business_date = source.last_business_date,
              target.next_sales_event_id = source.next_sales_event_id,
              target.next_order_id = source.next_order_id,
              target.next_order_line_id = source.next_order_line_id,
              target.updated_at = source.updated_at
            WHEN NOT MATCHED THEN INSERT *
            """
        )

    def append_registry(self, environment: str, df) -> None:
        table_name = self._registry_table(environment)
        (
            df.withColumn("environment", F.lit(environment))
            .select(
                "environment",
                "batch_id",
                "sales_event_id",
                "order_id",
                "order_line_id",
                "event_type",
                "sales_date",
                "arrival_date",
                "product_id",
                "customer_id",
                "territory_id",
                "quantity_delta",
                "amount_delta",
                "currency_code",
                "reference_event_id",
                "created_at",
            )
            .write.mode("append")
            .format("delta")
            .saveAsTable(table_name)
        )

    def append_manifest(self, environment: str, manifest_df) -> None:
        table_name = self._manifest_table(environment)
        (
            manifest_df.write.mode("append")
            .format("delta")
            .saveAsTable(table_name)
        )

    def registry_table(self, environment: str) -> str:
        self.ensure_tables(environment)
        return self._registry_table(environment)

    def ensure_tables(self, environment: str) -> None:
        config = self.config_loader.load()
        context = self.context_resolver.resolve(environment)

        state_table = context.ops_table_fqn(config.state_tables["generation_state"])
        manifest_table = context.ops_table_fqn(config.state_tables["generation_manifest"])
        registry_table = context.ops_table_fqn(config.state_tables["sales_event_registry"])

        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {state_table} (
              environment STRING NOT NULL,
              last_business_date DATE,
              next_sales_event_id BIGINT NOT NULL,
              next_order_id BIGINT NOT NULL,
              next_order_line_id BIGINT NOT NULL,
              updated_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {manifest_table} (
              environment STRING NOT NULL,
              batch_id STRING NOT NULL,
              business_date DATE NOT NULL,
              arrival_date DATE NOT NULL,
              sale_rows BIGINT NOT NULL,
              adjustment_rows BIGINT NOT NULL,
              cancel_rows BIGINT NOT NULL,
              output_path STRING NOT NULL,
              random_seed BIGINT NOT NULL,
              created_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {registry_table} (
              environment STRING NOT NULL,
              batch_id STRING NOT NULL,
              sales_event_id BIGINT NOT NULL,
              order_id BIGINT NOT NULL,
              order_line_id BIGINT NOT NULL,
              event_type STRING NOT NULL,
              sales_date DATE NOT NULL,
              arrival_date DATE NOT NULL,
              product_id BIGINT NOT NULL,
              customer_id BIGINT NOT NULL,
              territory_id BIGINT,
              quantity_delta INT NOT NULL,
              amount_delta DECIMAL(18,2) NOT NULL,
              currency_code STRING NOT NULL,
              reference_event_id BIGINT,
              created_at TIMESTAMP NOT NULL
            ) USING DELTA
            """
        )

    def _state_table(self, environment: str) -> str:
        config = self.config_loader.load()
        context = self.context_resolver.resolve(environment)
        return context.ops_table_fqn(config.state_tables["generation_state"])

    def _manifest_table(self, environment: str) -> str:
        config = self.config_loader.load()
        context = self.context_resolver.resolve(environment)
        return context.ops_table_fqn(config.state_tables["generation_manifest"])

    def _registry_table(self, environment: str) -> str:
        config = self.config_loader.load()
        context = self.context_resolver.resolve(environment)
        return context.ops_table_fqn(config.state_tables["sales_event_registry"])
