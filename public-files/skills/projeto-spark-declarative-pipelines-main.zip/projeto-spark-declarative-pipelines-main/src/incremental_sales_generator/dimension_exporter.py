from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from pyspark.sql import functions as F

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.runtime_context import ProjectContextResolver
from incremental_sales_generator.config import GeneratorConfigLoader


@dataclass(frozen=True)
class DimensionExportResult:
    logical_name: str
    extract_batch_id: str
    extract_ts: str
    output_path: str
    row_count: int


class DimensionFullExporter:
    """
    Exports one full landing batch per dimension into the landing volume.

    The generator stays outside Lakeflow. Its only contract with the pipeline is
    a file path plus the explicit schema metadata carried in each record.
    """

    def __init__(self, spark_session, project_root: Path):
        self.spark = spark_session
        self.project_root = project_root
        self.table_loader = ConfigLoader(project_root)
        self.generator_loader = GeneratorConfigLoader(project_root)
        self.context_resolver = ProjectContextResolver(spark_session, project_root)

    def export_all(self, environment: str, extract_ts: str | None = None) -> list[DimensionExportResult]:
        generator_config = self.generator_loader.load()
        return [
            self.export_dimension(logical_name, environment, extract_ts, generator_config)
            for logical_name in generator_config.dimensions
        ]

    def export_dimension(
        self,
        logical_name: str,
        environment: str,
        extract_ts: str | None = None,
        generator_config=None,
    ) -> DimensionExportResult:
        generator_config = generator_config or self.generator_loader.load()
        if logical_name not in generator_config.dimensions:
            raise ValueError(f"Unknown dimension export spec: {logical_name}")

        runtime_context = self.context_resolver.resolve(environment)
        dimension_spec = generator_config.dimensions[logical_name]
        bronze_spec = self.table_loader.load_table_spec("bronze", f"{logical_name}.yml")

        extract_timestamp = self._normalize_timestamp(extract_ts)
        extract_batch_id = self._build_batch_id(environment, logical_name, extract_timestamp)
        output_path = f"{runtime_context.data_path(bronze_spec.path_ref)}/{extract_batch_id}"

        source_df = self.spark.sql(
            dimension_spec.source_sql.format(
                source_catalog=generator_config.source_baseline_catalog,
            )
        )

        exported_df = (
            source_df.withColumn("extract_batch_id", F.lit(extract_batch_id))
            .withColumn("extract_ts", F.lit(extract_timestamp).cast("timestamp"))
            .select(*[field.name for field in bronze_spec.schema])
        )

        row_count = exported_df.count()

        writer = exported_df.coalesce(generator_config.defaults.coalesce_output_files).write.mode("overwrite")
        normalized_format = generator_config.defaults.landing_file_format.strip().lower()
        if normalized_format == "parquet":
            writer.parquet(output_path)
        elif normalized_format == "csv":
            writer.option("header", generator_config.defaults.emit_header).csv(output_path)
        else:
            raise ValueError(
                f"Unsupported landing file format '{generator_config.defaults.landing_file_format}'. "
                "Supported values: parquet, csv."
            )

        return DimensionExportResult(
            logical_name=logical_name,
            extract_batch_id=extract_batch_id,
            extract_ts=extract_timestamp.isoformat(),
            output_path=output_path,
            row_count=row_count,
        )

    @staticmethod
    def _normalize_timestamp(extract_ts: str | None) -> datetime:
        if extract_ts:
            normalized = extract_ts.replace("Z", "+00:00")
            return datetime.fromisoformat(normalized).astimezone(timezone.utc).replace(tzinfo=None)
        return datetime.now(timezone.utc).replace(microsecond=0, tzinfo=None)

    @staticmethod
    def _build_batch_id(environment: str, logical_name: str, extract_timestamp: datetime) -> str:
        timestamp_part = extract_timestamp.strftime("%Y%m%dT%H%M%SZ")
        return f"{environment}_{logical_name}_{timestamp_part}"

    @staticmethod
    def as_dict(result: DimensionExportResult) -> dict[str, str | int]:
        return asdict(result)
