CREATE OR REFRESH STREAMING TABLE sql_bronze_sales_store_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(business_entity_id AS LONG)                                  AS business_entity_id,
  TRIM(store_name)                                                  AS store_name,
  CAST(sales_person_id AS LONG)                                     AS sales_person_id,
  demographics_xml                                                  AS demographics_xml,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/sales_store_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, business_entity_id LONG,
                        store_name STRING, sales_person_id LONG, demographics_xml STRING'
));
