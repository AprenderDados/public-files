CREATE OR REFRESH STREAMING TABLE sql_bronze_person_person_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(business_entity_id AS LONG)                                  AS business_entity_id,
  UPPER(TRIM(person_type))                                          AS person_type,
  TRIM(title)                                                       AS title,
  TRIM(first_name)                                                  AS first_name,
  TRIM(middle_name)                                                 AS middle_name,
  TRIM(last_name)                                                   AS last_name,
  TRIM(suffix)                                                      AS suffix,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/person_person_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, business_entity_id LONG,
                        person_type STRING, title STRING, first_name STRING,
                        middle_name STRING, last_name STRING, suffix STRING'
));
