CREATE OR REFRESH STREAMING TABLE sql_bronze_production_productsubcategory_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(product_subcategory_id AS LONG)                              AS product_subcategory_id,
  CAST(product_category_id AS LONG)                                 AS product_category_id,
  TRIM(product_subcategory_name)                                    AS product_subcategory_name,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/production_productsubcategory_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, product_subcategory_id LONG,
                        product_category_id LONG, product_subcategory_name STRING'
));
