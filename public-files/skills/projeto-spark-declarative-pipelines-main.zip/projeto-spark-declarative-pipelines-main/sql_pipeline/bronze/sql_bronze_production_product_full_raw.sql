CREATE OR REFRESH STREAMING TABLE sql_bronze_production_product_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(product_id AS LONG)                                          AS product_id,
  TRIM(product_name)                                                AS product_name,
  TRIM(product_number)                                              AS product_number,
  CAST(product_model_id AS LONG)                                    AS product_model_id,
  CAST(product_subcategory_id AS LONG)                              AS product_subcategory_id,
  CAST(standard_cost AS DECIMAL(18,2))                              AS standard_cost,
  CAST(list_price AS DECIMAL(18,2))                                 AS list_price,
  CAST(sell_start_date AS DATE)                                     AS sell_start_date,
  CAST(sell_end_date AS DATE)                                       AS sell_end_date,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/production_product_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, product_id LONG,
                        product_name STRING, product_number STRING, product_model_id LONG,
                        product_subcategory_id LONG, standard_cost DECIMAL(18,2), list_price DECIMAL(18,2),
                        sell_start_date DATE, sell_end_date DATE'
));
