CREATE OR REFRESH STREAMING TABLE sql_bronze_production_productmodelproductdescriptionculture_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(product_model_id AS LONG)                                    AS product_model_id,
  CAST(product_description_id AS LONG)                              AS product_description_id,
  UPPER(TRIM(culture_id))                                           AS culture_id,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/production_productmodelproductdescriptionculture_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, product_model_id LONG,
                        product_description_id LONG, culture_id STRING'
));
