CREATE OR REFRESH STREAMING TABLE sql_bronze_person_address_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  CAST(address_id AS LONG)                                          AS address_id,
  TRIM(address_line_1)                                              AS address_line_1,
  TRIM(address_line_2)                                              AS address_line_2,
  TRIM(city)                                                        AS city,
  CAST(state_province_id AS LONG)                                   AS state_province_id,
  TRIM(postal_code)                                                 AS postal_code,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/person_address_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, address_id LONG,
                        address_line_1 STRING, address_line_2 STRING, city STRING,
                        state_province_id LONG, postal_code STRING'
));
