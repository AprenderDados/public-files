CREATE OR REFRESH STREAMING TABLE sql_bronze_fact_sales_events_raw
(
  sales_event_id                LONG,
  order_id                      LONG,
  order_line_id                 LONG,
  event_type                    STRING,
  sales_date                    DATE,
  arrival_date                  DATE,
  product_id                    LONG,
  customer_id                   LONG,
  territory_id                  LONG,
  quantity_delta                INT,
  amount_delta                  DECIMAL(18,2),
  currency_code                 STRING,
  reference_event_id            LONG,
  _rescued_data                 STRING,
  ingestion_ts                  TIMESTAMP,
  source_batch_id               STRING,
  source_file_path              STRING,
  source_file_name              STRING,
  source_file_modification_time TIMESTAMP
)
COMMENT 'SQL project bronze fact ledger from generated incremental sales files.'
AS
SELECT
  CAST(sales_event_id AS LONG)                                      AS sales_event_id,
  CAST(order_id AS LONG)                                            AS order_id,
  CAST(order_line_id AS LONG)                                       AS order_line_id,
  UPPER(TRIM(event_type))                                           AS event_type,
  CAST(sales_date AS DATE)                                          AS sales_date,
  CAST(arrival_date AS DATE)                                        AS arrival_date,
  CAST(product_id AS LONG)                                          AS product_id,
  CAST(customer_id AS LONG)                                         AS customer_id,
  CAST(territory_id AS LONG)                                        AS territory_id,
  CAST(quantity_delta AS INT)                                       AS quantity_delta,
  CAST(amount_delta AS DECIMAL(18,2))                               AS amount_delta,
  UPPER(TRIM(currency_code))                                        AS currency_code,
  CAST(reference_event_id AS LONG)                                  AS reference_event_id,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_fact_source_path}',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'sales_event_id LONG, order_id LONG, order_line_id LONG,
                        event_type STRING, sales_date DATE, arrival_date DATE,
                        product_id LONG, customer_id LONG, territory_id LONG,
                        quantity_delta INT, amount_delta DECIMAL(18,2), currency_code STRING,
                        reference_event_id LONG'
));
