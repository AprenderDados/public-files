CREATE OR REFRESH STREAMING TABLE sql_bronze_person_countryregion_full_raw AS
SELECT
  CAST(extract_batch_id AS STRING)                                  AS extract_batch_id,
  CAST(extract_ts AS TIMESTAMP)                                     AS extract_ts,
  UPPER(TRIM(country_region_code))                                  AS country_region_code,
  TRIM(country_region_name)                                         AS country_region_name,
  _rescued_data                                                     AS _rescued_data,
  CURRENT_TIMESTAMP()                                               AS ingestion_ts,
  REGEXP_EXTRACT(_metadata.file_path, '/([^/]+)/[^/]+$', 1)         AS source_batch_id,
  _metadata.file_path                                               AS source_file_path,
  REGEXP_EXTRACT(_metadata.file_path, '([^/]+)$', 1)                AS source_file_name,
  _metadata.file_modification_time                                  AS source_file_modification_time
FROM STREAM(read_files(
  '${course_sdp.sql_dimensions_source_root}/person_countryregion_parquet',
  format            => 'parquet',
  rescuedDataColumn => '_rescued_data',
  schema            => 'extract_batch_id STRING, extract_ts TIMESTAMP, country_region_code STRING,
                        country_region_name STRING'
));
