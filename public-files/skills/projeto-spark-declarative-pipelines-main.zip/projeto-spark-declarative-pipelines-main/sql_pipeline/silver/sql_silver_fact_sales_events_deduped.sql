CREATE OR REFRESH MATERIALIZED VIEW sql_silver_fact_sales_events_deduped AS
SELECT * EXCEPT (rn)
FROM (
  SELECT
    *,
    ROW_NUMBER() OVER (
      PARTITION BY sales_event_id
      ORDER BY
        ingestion_ts DESC NULLS LAST,
        source_file_modification_time DESC NULLS LAST,
        source_file_path DESC NULLS LAST
    ) AS rn
  FROM sql_bronze_fact_sales_events_raw
  WHERE _rescued_data IS NULL OR TRIM(_rescued_data) = ''
)
WHERE rn = 1;
