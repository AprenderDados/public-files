CREATE OR REFRESH MATERIALIZED VIEW sql_silver_sales_customer_current AS
WITH latest_batch AS (
  SELECT extract_batch_id, extract_ts
  FROM (
    SELECT
      extract_batch_id,
      extract_ts,
      ROW_NUMBER() OVER (ORDER BY extract_ts DESC, extract_batch_id DESC) AS rn
    FROM (SELECT DISTINCT extract_batch_id, extract_ts FROM sql_bronze_sales_customer_full_raw)
  ) WHERE rn = 1
)
SELECT * EXCEPT (rn, _rescued_data, ingestion_ts, source_batch_id, source_file_path, source_file_name, source_file_modification_time)
FROM (
  SELECT
    p.*,
    ROW_NUMBER() OVER (
      PARTITION BY customer_id
      ORDER BY p.extract_ts DESC, p.source_file_modification_time DESC NULLS LAST, p.ingestion_ts DESC NULLS LAST, p.source_file_path DESC NULLS LAST
    ) AS rn
  FROM sql_bronze_sales_customer_full_raw p
  INNER JOIN latest_batch lb
    ON p.extract_batch_id = lb.extract_batch_id
   AND p.extract_ts = lb.extract_ts
  WHERE p._rescued_data IS NULL OR TRIM(p._rescued_data) = ''
)
WHERE rn = 1;
