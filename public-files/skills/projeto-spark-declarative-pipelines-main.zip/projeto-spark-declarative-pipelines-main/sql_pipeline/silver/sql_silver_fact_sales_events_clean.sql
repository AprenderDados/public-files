CREATE OR REFRESH MATERIALIZED VIEW sql_silver_fact_sales_events_clean
(
  CONSTRAINT valid_sales_event_id
    EXPECT (sales_event_id IS NOT NULL)
    ON VIOLATION FAIL UPDATE,
  CONSTRAINT valid_event_type
    EXPECT (event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL'))
    ON VIOLATION FAIL UPDATE,
  CONSTRAINT valid_sales_arrival_order
    EXPECT (sales_date <= arrival_date)
    ON VIOLATION DROP ROW,
  CONSTRAINT non_zero_quantity
    EXPECT (quantity_delta <> 0)
    ON VIOLATION DROP ROW,
  CONSTRAINT non_zero_amount
    EXPECT (amount_delta <> 0)
    ON VIOLATION DROP ROW,
  CONSTRAINT valid_currency_code
    EXPECT (currency_code RLIKE '^[A-Z]{3}$')
    ON VIOLATION DROP ROW,
  CONSTRAINT sales_events_are_positive
    EXPECT (event_type <> 'SALE' OR (quantity_delta > 0 AND amount_delta > 0))
    ON VIOLATION DROP ROW,
  CONSTRAINT correction_events_have_reference
    EXPECT (
      (event_type = 'SALE' AND reference_event_id IS NULL)
      OR
      (event_type IN ('ADJUSTMENT', 'CANCEL') AND reference_event_id IS NOT NULL)
    )
    ON VIOLATION DROP ROW
)
AS
SELECT
  sales_event_id,
  order_id,
  order_line_id,
  event_type,
  sales_date,
  arrival_date,
  product_id,
  customer_id,
  territory_id,
  quantity_delta,
  CAST(ROUND(amount_delta, 2) AS DECIMAL(18,2)) AS amount_delta,
  currency_code,
  reference_event_id,
  ingestion_ts,
  source_batch_id,
  source_file_path
FROM sql_silver_fact_sales_events_deduped;
