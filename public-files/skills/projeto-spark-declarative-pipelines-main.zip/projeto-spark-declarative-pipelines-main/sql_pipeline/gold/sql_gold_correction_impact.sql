CREATE OR REFRESH MATERIALIZED VIEW sql_gold_correction_impact
COMMENT 'Impact of adjustments and cancellations for the SQL-only pipeline.'
AS
SELECT
  arrival_date,
  sales_date,
  event_type,
  COUNT(*) AS correction_events_count,
  CAST(SUM(quantity_delta) AS LONG) AS net_quantity_impact,
  CAST(ROUND(SUM(amount_delta), 2) AS DECIMAL(18,2)) AS net_revenue_impact
FROM sql_gold_sales_analytics_obt
WHERE event_type IN ('ADJUSTMENT', 'CANCEL')
GROUP BY arrival_date, sales_date, event_type;
