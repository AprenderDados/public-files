CREATE OR REFRESH MATERIALIZED VIEW sql_gold_arrival_vs_business_date
COMMENT 'Arrival date vs business date analysis for the SQL-only pipeline.'
AS
SELECT
  arrival_date,
  sales_date,
  COUNT(*) AS events_count,
  CAST(SUM(quantity_delta) AS LONG) AS net_quantity,
  CAST(ROUND(SUM(amount_delta), 2) AS DECIMAL(18,2)) AS net_revenue,
  CAST(SUM(CASE WHEN arrival_date > sales_date THEN 1 ELSE 0 END) AS LONG) AS late_events_count
FROM sql_gold_sales_analytics_obt
GROUP BY arrival_date, sales_date;
