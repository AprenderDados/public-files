CREATE OR REFRESH MATERIALIZED VIEW sql_gold_sales_analytics_obt
COMMENT 'Analytics-ready sales OBT at event grain for the SQL-only pipeline.'
AS
SELECT
  f.sales_event_id,
  f.order_id,
  f.order_line_id,
  f.event_type,
  f.sales_date,
  f.arrival_date,
  f.product_id,
  p.product_name,
  p.product_number,
  p.product_model_name,
  p.product_category_name,
  p.product_subcategory_name,
  p.standard_cost,
  p.list_price,
  f.customer_id,
  c.customer_business_entity_id,
  c.customer_name,
  c.customer_type,
  c.customer_segment,
  c.customer_city,
  c.customer_state_province_name,
  c.customer_country_region_name,
  COALESCE(c.territory_id, f.territory_id) AS territory_id,
  c.territory_name,
  c.territory_group,
  c.country_region_code,
  c.country_region_name,
  c.person_title,
  c.first_name,
  c.middle_name,
  c.last_name,
  c.suffix,
  c.store_name,
  c.customer_postal_code,
  f.quantity_delta,
  f.amount_delta,
  f.currency_code,
  f.reference_event_id,
  f.source_batch_id,
  f.source_file_path
FROM sql_silver_fact_sales_events_clean f
LEFT JOIN sql_gold_dim_product p
  ON f.product_id = p.product_id
LEFT JOIN sql_gold_dim_customer c
  ON f.customer_id = c.customer_id;
