CREATE OR REFRESH MATERIALIZED VIEW sql_gold_daily_sales_by_product
COMMENT 'Net sales by business date and product for the SQL-only pipeline.'
AS
SELECT
  sales_date,
  product_id,
  product_name,
  product_category_name,
  product_subcategory_name,
  CAST(SUM(quantity_delta) AS LONG) AS net_quantity,
  CAST(ROUND(SUM(amount_delta), 2) AS DECIMAL(18,2)) AS net_revenue,
  COUNT(*) AS events_count
FROM sql_gold_sales_analytics_obt
GROUP BY
  sales_date,
  product_id,
  product_name,
  product_category_name,
  product_subcategory_name;
