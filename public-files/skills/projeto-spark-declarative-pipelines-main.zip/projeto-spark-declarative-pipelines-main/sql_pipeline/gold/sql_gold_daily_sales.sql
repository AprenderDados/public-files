CREATE OR REFRESH MATERIALIZED VIEW sql_gold_daily_sales
COMMENT 'Net sales by business date for the SQL-only pipeline.'
AS
SELECT
  sales_date,
  CAST(SUM(quantity_delta) AS LONG) AS net_quantity,
  CAST(ROUND(SUM(amount_delta), 2) AS DECIMAL(18,2)) AS net_revenue,
  COUNT(*) AS events_count,
  CAST(SUM(CASE WHEN event_type IN ('ADJUSTMENT', 'CANCEL') THEN 1 ELSE 0 END) AS LONG) AS correction_events_count
FROM sql_gold_sales_analytics_obt
GROUP BY sales_date;
