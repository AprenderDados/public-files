CREATE OR REFRESH MATERIALIZED VIEW sql_gold_dim_product
COMMENT 'Conformed product dimension built inside the SQL-only pipeline.'
AS
WITH product_descriptions AS (
  SELECT
    product_model_id,
    product_description
  FROM (
    SELECT
      m.product_model_id,
      d.product_description,
      ROW_NUMBER() OVER (
        PARTITION BY m.product_model_id
        ORDER BY m.product_description_id ASC
      ) AS rn
    FROM sql_silver_production_productmodelproductdescriptionculture_current m
    LEFT JOIN sql_silver_production_productdescription_current d
      ON m.product_description_id = d.product_description_id
    WHERE UPPER(m.culture_id) = 'EN'
  )
  WHERE rn = 1
)
SELECT
  p.product_id,
  p.product_name,
  p.product_number,
  p.product_model_id,
  pm.product_model_name,
  pd.product_description,
  p.product_subcategory_id,
  psc.product_subcategory_name,
  pc.product_category_id,
  pc.product_category_name,
  p.standard_cost,
  p.list_price,
  p.sell_start_date,
  p.sell_end_date
FROM sql_silver_production_product_current p
LEFT JOIN sql_silver_production_productsubcategory_current psc
  ON p.product_subcategory_id = psc.product_subcategory_id
LEFT JOIN sql_silver_production_productcategory_current pc
  ON psc.product_category_id = pc.product_category_id
LEFT JOIN sql_silver_production_productmodel_current pm
  ON p.product_model_id = pm.product_model_id
LEFT JOIN product_descriptions pd
  ON p.product_model_id = pd.product_model_id;
