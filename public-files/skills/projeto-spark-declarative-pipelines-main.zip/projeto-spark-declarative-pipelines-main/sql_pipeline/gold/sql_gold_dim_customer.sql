CREATE OR REFRESH MATERIALIZED VIEW sql_gold_dim_customer
COMMENT 'Conformed customer dimension built inside the SQL-only pipeline.'
AS
WITH address_bridge AS (
  SELECT
    business_entity_id,
    address_type_id,
    address_id,
    address_line_1,
    address_line_2,
    city,
    postal_code,
    state_province_name,
    customer_country_region_code,
    customer_country_region_name
  FROM (
    SELECT
      bea.business_entity_id,
      bea.address_type_id,
      bea.address_id,
      a.address_line_1,
      a.address_line_2,
      a.city,
      a.postal_code,
      sp.state_province_name,
      sp.country_region_code AS customer_country_region_code,
      cr.country_region_name AS customer_country_region_name,
      ROW_NUMBER() OVER (
        PARTITION BY bea.business_entity_id
        ORDER BY bea.address_type_id ASC NULLS LAST, bea.address_id ASC NULLS LAST
      ) AS rn
    FROM sql_silver_person_businessentityaddress_current bea
    LEFT JOIN sql_silver_person_address_current a
      ON bea.address_id = a.address_id
    LEFT JOIN sql_silver_person_stateprovince_current sp
      ON a.state_province_id = sp.state_province_id
    LEFT JOIN sql_silver_person_countryregion_current cr
      ON sp.country_region_code = cr.country_region_code
  )
  WHERE rn = 1
),
territory_enriched AS (
  SELECT
    t.territory_id,
    t.territory_name,
    t.territory_group,
    t.country_region_code,
    cr.country_region_name
  FROM sql_silver_sales_salesterritory_current t
  LEFT JOIN sql_silver_person_countryregion_current cr
    ON t.country_region_code = cr.country_region_code
),
person_name AS (
  SELECT
    business_entity_id,
    TRIM(REGEXP_REPLACE(CONCAT_WS(' ', first_name, middle_name, last_name), '\\s+', ' ')) AS full_name,
    title,
    first_name,
    middle_name,
    last_name,
    suffix
  FROM sql_silver_person_person_current
)
SELECT
  c.customer_id,
  COALESCE(c.person_id, c.store_id) AS customer_business_entity_id,
  CASE
    WHEN c.store_id IS NOT NULL THEN s.store_name
    WHEN c.person_id IS NOT NULL THEN pn.full_name
    ELSE CONCAT('Customer ', CAST(c.customer_id AS STRING))
  END AS customer_name,
  CASE
    WHEN c.store_id IS NOT NULL THEN 'STORE'
    WHEN c.person_id IS NOT NULL THEN 'PERSON'
    ELSE 'UNKNOWN'
  END AS customer_type,
  CASE
    WHEN c.store_id IS NOT NULL THEN 'STORE'
    WHEN c.person_id IS NOT NULL THEN 'INDIVIDUAL'
    ELSE 'UNKNOWN'
  END AS customer_segment,
  c.territory_id,
  t.territory_name,
  t.territory_group,
  t.country_region_code,
  t.country_region_name,
  pn.title AS person_title,
  pn.first_name,
  pn.middle_name,
  pn.last_name,
  pn.suffix,
  s.store_name,
  ab.city AS customer_city,
  ab.state_province_name AS customer_state_province_name,
  ab.customer_country_region_name,
  ab.postal_code AS customer_postal_code
FROM sql_silver_sales_customer_current c
LEFT JOIN person_name pn
  ON c.person_id = pn.business_entity_id
LEFT JOIN sql_silver_sales_store_current s
  ON c.store_id = s.business_entity_id
LEFT JOIN address_bridge ab
  ON COALESCE(c.person_id, c.store_id) = ab.business_entity_id
LEFT JOIN territory_enriched t
  ON c.territory_id = t.territory_id;
