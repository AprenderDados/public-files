# Questionário — Configuração Declarativa em YAML com Pydantic

## Questão 1 de 5

**O YAML de uma tabela silver tem `action: ignorar_tudo` em uma regra de qualidade. O que acontece quando o projeto tenta carregar essa configuração?**

- ( ) A pipeline ignora a regra desconhecida e continua normalmente
- ( ) O projeto usa `warn` como fallback para ações desconhecidas
- (x) O Pydantic lança um erro de validação imediatamente ao carregar o YAML
- ( ) A regra é aplicada como `warn` automaticamente

**Resposta correta:** O Pydantic lança um erro de validação imediatamente ao carregar o YAML

**Feedback:** O modelo `QualityRuleSpec` tem um validador que só aceita `"warn"`, `"drop"` ou `"fail"` como valores para `action`. Um valor diferente lança `ValueError` no momento do carregamento — antes de qualquer escrita em tabela. Isso é um dos grandes valores do Pydantic: erros de configuração são detectados cedo.

---

## Questão 2 de 5

**O `config/environments/dev.yml` sobrescreve apenas os nomes de schema. O `config/environments/base.yml` tem configurações de gerador (`coalesce`, `file_format`). O que o ambiente dev herda?**

- ( ) Nada — cada ambiente é completamente independente
- ( ) As configurações de gerador, mas não as configurações de schema
- (x) Todas as chaves do base que não foram sobrescritas em dev, incluindo as configurações de gerador
- ( ) Apenas as configurações que estão explicitamente listadas no dev.yml

**Resposta correta:** Todas as chaves do base que não foram sobrescritas em dev, incluindo as configurações de gerador

**Feedback:** O merge é `{**base_config, **dev_config}`. Chaves que existem só no base são herdadas integralmente. Chaves que existem no dev sobrescrevem as do base. Chaves que só existem no dev são adicionadas. Resultado: o ambiente dev tem tudo do base, mais seus overrides específicos.

---

## Questão 3 de 5

**Qual módulo do projeto converte o tipo YAML `"decimal(19,4)"` em `DecimalType(19, 4)` do Spark?**

- ( ) `config_loader.py`
- ( ) `models.py`
- (x) `spark_schema.py`
- ( ) `runtime_context.py`

**Resposta correta:** `spark_schema.py`

**Feedback:** O `spark_schema.py` contém a função `build_spark_schema()` que converte uma lista de `FieldSpec` (com tipos como strings: `"long"`, `"decimal(19,4)"`, `"date"`) em um `StructType` do Spark com os tipos corretos. Tipos inválidos lançam `ValueError`.

---

## Questão 4 de 5

**Por que o projeto tem um arquivo YAML por tabela em vez de um único YAML com todas as tabelas?**

- ( ) Por limitação do `PyYAML` — arquivos muito grandes causam erro de memória
- ( ) Para facilitar a paralelização do carregamento de configuração
- (x) Para que cada tabela tenha um spec versionável e legível de forma independente, facilitando PR review e mudanças isoladas
- ( ) Porque o ConfigLoader não suporta múltiplas tabelas no mesmo arquivo

**Resposta correta:** Para que cada tabela tenha um spec versionável e legível de forma independente, facilitando PR review e mudanças isoladas

**Feedback:** Um YAML por tabela significa que uma mudança no schema de `bronze_fact_sales_events` aparece como um PR pequeno e focado, não como uma mudança em um arquivo gigante com 48 tabelas. É mais fácil de revisar, mais difícil de causar mudanças acidentais em outras tabelas.

---

## Questão 5 de 5

**Um engenheiro muda o tipo de `quantity_delta` de `int` para `long` no YAML de bronze. O que precisa acontecer para a pipeline refletir essa mudança?**

- ( ) A mudança é imediata — o Auto Loader lê o YAML a cada arquivo processado
- ( ) Só é necessário reiniciar o notebook de ingestão
- (x) É necessário re-implantar a pipeline (bundle deploy) para que o novo schema seja carregado
- ( ) O Pydantic propaga a mudança automaticamente para todas as tabelas dependentes

**Resposta correta:** É necessário re-implantar a pipeline (bundle deploy) para que o novo schema seja carregado

**Feedback:** O YAML é carregado no momento de inicialização da pipeline ou importação do módulo. Uma mudança no arquivo YAML não é refletida enquanto a pipeline estiver rodando com a configuração antiga. É necessário re-implantar (ou reiniciar) para que o `ConfigLoader` leia o novo arquivo.
