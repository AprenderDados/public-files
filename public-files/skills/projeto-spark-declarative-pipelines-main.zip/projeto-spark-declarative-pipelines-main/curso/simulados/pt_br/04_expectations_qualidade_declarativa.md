# Questionário — Expectations: Qualidade Declarativa de Dados

## Questão 1 de 5

**Qual decorator de expectation para a pipeline inteira se a regra for violada?**

- ( ) `@dp.expect`
- ( ) `@dp.expect_or_drop`
- (x) `@dp.expect_or_fail`
- ( ) `@dp.assert_or_fail`

**Resposta correta:** `@dp.expect_or_fail`

**Feedback:** `@dp.expect_or_fail` é o modo mais restritivo. Se qualquer linha violar a regra, a pipeline inteira para com falha — nada é commitado. Use para invariantes críticas, como chave primária não-nula.

---

## Questão 2 de 5

**Um campo `event_type` deve conter apenas `SALE`, `ADJUSTMENT` ou `CANCEL`. Valores fora desse conjunto chegam raramente e não devem bloquear o processamento, mas também não devem avançar para a silver. Qual modo de expectation é mais adequado?**

- ( ) `@dp.expect` — para registrar a violação sem bloquear
- (x) `@dp.expect_or_drop` — para descartar silenciosamente sem parar a pipeline
- ( ) `@dp.expect_or_fail` — para parar a pipeline e alertar a equipe
- ( ) Não há expectation adequada — deve ser tratado em código Python antes da pipeline

**Resposta correta:** `@dp.expect_or_drop` — para descartar silenciosamente sem parar a pipeline

**Feedback:** O dado inválido não deve avançar (não faz sentido na silver), mas o processo como um todo não deve parar por causa de um tipo desconhecido ocasional. `expect_or_drop` descarta a linha e registra a violação no event log — exatamente o comportamento correto para esse cenário.

---

## Questão 3 de 5

**No projeto, como as regras de qualidade são configuradas por tabela? O engenheiro escreve o decorator `@dp.expect_or_drop` diretamente no código de pipeline?**

- ( ) Sim, o decorator é escrito diretamente na função de pipeline
- ( ) As regras são configuradas em código Python em um arquivo de constantes
- (x) As regras são declaradas em YAML por tabela e aplicadas dinamicamente pelo `quality_decorator.py`
- ( ) As regras são configuradas via API do Databricks, não no código

**Resposta correta:** As regras são declaradas em YAML por tabela e aplicadas dinamicamente pelo `quality_decorator.py`

**Feedback:** O projeto separa a declaração da regra (YAML) da aplicação do decorator (Python). O `quality_decorator.py` lê as regras do spec e aplica `dp.expect`, `dp.expect_or_drop` ou `dp.expect_or_fail` conforme a propriedade `action` de cada regra. Mudar uma regra de qualidade é uma mudança de YAML, não de Python.

---

## Questão 4 de 5

**Uma expectation do tipo `warn` está configurada na tabela silver. 50 linhas violaram a regra. O que ocorre com essas linhas?**

- ( ) São descartadas da tabela silver
- ( ) A pipeline para com erro
- (x) As 50 linhas entram normalmente na tabela; a violação é registrada no event log
- ( ) As linhas entram na tabela com um campo adicional de flag de violação

**Resposta correta:** As 50 linhas entram normalmente na tabela; a violação é registrada no event log

**Feedback:** `warn` é apenas monitoramento. A linha não é descartada e a pipeline não para. O event log e o pipeline graph registram a contagem de violações por regra — isso permite monitorar a qualidade sem bloquear o fluxo.

---

## Questão 5 de 5

**Quando múltiplos decorators de expectation são empilhados em uma função de pipeline, em qual ordem são aplicados?**

- ( ) Na ordem em que aparecem no código (de cima para baixo)
- (x) Em ordem inversa (o decorator mais próximo da função é aplicado primeiro)
- ( ) A ordem não importa — todas são aplicadas simultaneamente
- ( ) Na ordem alfabética pelo nome da expectation

**Resposta correta:** Em ordem inversa (o decorator mais próximo da função é aplicado primeiro)

**Feedback:** Decorators Python são aplicados de dentro para fora (de baixo para cima quando empilhados). O `quality_decorator.py` do projeto usa `reversed(rules)` para garantir que as regras sejam aplicadas na ordem declarada no YAML (de cima para baixo), compensando o comportamento inverso dos decorators.
