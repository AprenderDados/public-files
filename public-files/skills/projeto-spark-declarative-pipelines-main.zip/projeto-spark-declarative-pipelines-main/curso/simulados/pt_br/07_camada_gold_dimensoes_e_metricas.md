# Questionário — Camada Gold: Dimensões Conformadas e Métricas

## Questão 1 de 5

**O que é uma "dimensão conformada" no contexto do projeto?**

- ( ) Uma dimensão que passou por SCD2 e tem histórico completo de mudanças
- (x) Uma tabela de dimensão plana que consolida múltiplos níveis de hierarquia em um único join
- ( ) Uma dimensão que é compartilhada entre múltiplos catálogos do Unity Catalog
- ( ) Uma dimensão que foi normalizada e está na terceira forma normal

**Resposta correta:** Uma tabela de dimensão plana que consolida múltiplos níveis de hierarquia em um único join

**Feedback:** A `gold_dim_product` junta produto + subcategoria + categoria + modelo + descrição em 12 colunas. Em vez de fazer 5 joins para qualquer análise de produto, você consulta a dimensão conformada. "Conformada" aqui significa consolidada — pronta para consumo analítico sem joins adicionais.

---

## Questão 2 de 5

**Por que todos os joins da camada gold são LEFT JOIN e não INNER JOIN?**

- ( ) LEFT JOIN é mais rápido que INNER JOIN no Databricks
- ( ) INNER JOIN não é suportado em materialized views
- (x) Para preservar eventos de venda mesmo quando a dimensão associada está incompleta ou ausente
- ( ) Por convenção do projeto — qualquer tipo de join funcionaria igual

**Resposta correta:** Para preservar eventos de venda mesmo quando a dimensão associada está incompleta ou ausente

**Feedback:** Com INNER JOIN, um evento de venda referenciando um produto deletado da dimensão desapareceria dos relatórios — como se nunca tivesse acontecido. Com LEFT JOIN, o evento permanece com campos de dimensão nulos. Em análise financeira, perder eventos é muito pior do que ter nulos.

---

## Questão 3 de 5

**O `net_revenue` da tabela `gold_daily_sales` inclui eventos do tipo `ADJUSTMENT` e `CANCEL`?**

- ( ) Não — apenas `SALE` entra no cálculo de receita
- ( ) Sim, mas apenas `ADJUSTMENT` — `CANCEL` é excluído
- (x) Sim, todos os tipos de evento entram — ajustes e cancelamentos têm `amount_delta` negativo
- ( ) Depende do filtro aplicado na consulta do dashboard

**Resposta correta:** Sim, todos os tipos de evento entram — ajustes e cancelamentos têm `amount_delta` negativo

**Feedback:** O `net_revenue` é `SUM(amount_delta)` sem filtro de tipo. Eventos `ADJUSTMENT` e `CANCEL` têm `amount_delta` negativo, o que naturalmente reduz o total. Isso representa a receita líquida real — o resultado final após todas as correções e cancelamentos.

---

## Questão 4 de 5

**O produto com `product_id = 999` apareceu em um evento de venda histórico, mas foi removido do catálogo de produtos. Como ele aparece na `gold_sales_analytics_obt`?**

- ( ) O evento não aparece — LEFT JOIN só funciona para chaves válidas
- ( ) O evento aparece com os dados do produto como eram quando a venda ocorreu (via SCD2)
- (x) O evento aparece com os campos de produto nulos (LEFT JOIN preserva o fato, dimensão ausente = null)
- ( ) O evento aparece com `product_name = "Produto Deletado"` por fallback configurado

**Resposta correta:** O evento aparece com os campos de produto nulos (LEFT JOIN preserva o fato, dimensão ausente = null)

**Feedback:** O LEFT JOIN preserva todos os eventos de venda, independente de a dimensão correspondente existir. O produto 999 está ausente da gold_dim_product → os campos de produto ficam nulos na OBT. O evento de venda continua visível na análise.

---

## Questão 5 de 5

**A tabela `gold_arrival_vs_business_date` serve para analisar qual aspecto do pipeline?**

- ( ) Quanto tempo a pipeline demorou para executar
- ( ) Quais produtos chegaram mais tarde ao armazém
- (x) Latência de dados — eventos que chegaram no sistema dias depois de terem ocorrido no negócio
- ( ) Taxa de cancelamento de pedidos por data de chegada

**Resposta correta:** Latência de dados — eventos que chegaram no sistema dias depois de terem ocorrido no negócio

**Feedback:** O projeto separa `sales_date` (quando a venda ocorreu) e `arrival_date` (quando o dado chegou). A `gold_arrival_vs_business_date` agrega por esse cruzamento. Quando `arrival_date > sales_date`, o evento chegou com atraso — o que é comum em `ADJUSTMENT` e `CANCEL`, mas também pode ocorrer em `SALE` quando há atrasos de processamento.
