# Questionário — Delta Tables: Fundamentos

## Questão 1 de 5

**O que diferencia uma tabela Delta de um diretório Parquet simples?**

- ( ) Delta usa compressão mais avançada que Parquet
- (x) Delta adiciona um transaction log que habilita ACID, time travel e schema enforcement
- ( ) Delta só funciona no Databricks, enquanto Parquet é portável
- ( ) Delta é mais rápido para leitura porque usa índices colunar

**Resposta correta:** Delta adiciona um transaction log que habilita ACID, time travel e schema enforcement

**Feedback:** O Parquet já tem compressão colunar eficiente. O que o Delta acrescenta é o `_delta_log/` — um diretório de metadados que registra cada transação. Esse log é a fundação de ACID, time travel e schema enforcement. Sem o log, é só Parquet.

---

## Questão 2 de 5

**Você quer consultar o estado de uma tabela Delta como ela era antes de uma carga incorreta que aconteceu há 2 dias. Qual recurso você usa?**

- ( ) `RESTORE TABLE` com data de backup
- ( ) Consultar os arquivos Parquet diretamente
- (x) Time travel com `VERSION AS OF` ou `TIMESTAMP AS OF`
- ( ) Delta não suporta consultar versões passadas

**Resposta correta:** Time travel com `VERSION AS OF` ou `TIMESTAMP AS OF`

**Feedback:** O transaction log registra todas as versões. `SELECT * FROM tabela VERSION AS OF 3` retorna o estado na versão 3. `SELECT * FROM tabela TIMESTAMP AS OF '2024-04-01'` retorna o estado no timestamp. O dado só some depois que `VACUUM` for executado e o retention period expirar.

---

## Questão 3 de 5

**O que acontece quando você tenta gravar um DataFrame com uma coluna do tipo `STRING` em uma tabela Delta que define essa coluna como `DATE`?**

- ( ) A escrita passa e o campo fica como STRING
- ( ) A escrita passa e o campo fica nulo
- (x) A escrita é rejeitada com erro de schema enforcement
- ( ) A escrita passa mas o campo vai para `_rescued_data`

**Resposta correta:** A escrita é rejeitada com erro de schema enforcement

**Feedback:** Delta verifica o schema no momento da escrita e rejeita tipos incompatíveis. A coluna `_rescued_data` é uma funcionalidade do Auto Loader, não do Delta em si. Ao escrever diretamente com `saveAsTable` ou `write.delta`, schema incompatível causa erro de validação.

---

## Questão 4 de 5

**No projeto Spark Declarative Pipelines, quem escreve os dados nas tabelas Delta da camada bronze?**

- ( ) O engenheiro chama `df.write.format("delta").save(path)` nos notebooks
- ( ) O script de geração de dados escreve diretamente na bronze
- (x) A pipeline Lakeflow (Spark Declarative Pipelines) escreve automaticamente ao executar
- ( ) O Auto Loader escreve diretamente na tabela bronze quando lê os arquivos

**Resposta correta:** A pipeline Lakeflow (Spark Declarative Pipelines) escreve automaticamente ao executar

**Feedback:** Nos arquivos de pipeline do projeto (`bronze_dimensions.py`, `bronze_facts.py`), o engenheiro declara a função que retorna o DataFrame. A pipeline Lakeflow gerencia o write em Delta, o checkpoint e a execução incremental. O engenheiro não chama `writeStream.start()` nem `write.format("delta")`.

---

## Questão 5 de 5

**Qual comando do Delta mostra o histórico de operações realizadas em uma tabela?**

- ( ) `SHOW HISTORY tabela`
- ( ) `SELECT * FROM tabela HISTORY`
- (x) `DESCRIBE HISTORY tabela`
- ( ) `EXPLAIN tabela`

**Resposta correta:** `DESCRIBE HISTORY tabela`

**Feedback:** `DESCRIBE HISTORY tabela` retorna um DataFrame com cada versão da tabela, incluindo timestamp da operação, o usuário que fez, o tipo de operação (INSERT, UPDATE, MERGE) e o número de arquivos afetados. Essa visão é fundamental para debugging e auditoria.
