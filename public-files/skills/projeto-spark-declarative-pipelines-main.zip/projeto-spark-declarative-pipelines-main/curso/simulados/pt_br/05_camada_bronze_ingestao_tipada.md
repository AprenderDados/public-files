# Questionário — Camada Bronze: Ingestão Tipada e Rastreável

## Questão 1 de 5

**Um arquivo CSV chegou com o campo `amount_delta` preenchido com o texto `"INVALIDO"` em vez de um número. Com schema explícito declarando `amount_delta` como `decimal(19,4)`, o que acontece na camada bronze?**

- ( ) A linha é descartada e não entra na bronze
- ( ) A pipeline para com erro de tipo
- (x) A linha entra na bronze com `amount_delta = null` e o valor original em `_rescued_data`
- ( ) O campo é ingerido como string, ignorando o tipo declarado

**Resposta correta:** A linha entra na bronze com `amount_delta = null` e o valor original em `_rescued_data`

**Feedback:** A bronze não descarta linhas com problema de tipo — ela captura o valor problemático em `_rescued_data` como JSON e coloca `null` no campo tipado. A linha continua presente na bronze. É a silver quem vai descartar linhas com `_rescued_data` não-nulo.

---

## Questão 2 de 5

**Por que a bronze não aplica normalização de texto como `upper(event_type)` ou `trim(name)`?**

- ( ) Porque o Auto Loader não suporta transformações durante a ingestão
- ( ) Porque o schema explícito já garante que os valores estão corretos
- (x) Porque a bronze é responsável por receber e preservar o dado bruto — normalização é responsabilidade da silver
- ( ) Porque normalização de texto é muito custosa computacionalmente na ingestão

**Resposta correta:** Porque a bronze é responsável por receber e preservar o dado bruto — normalização é responsabilidade da silver

**Feedback:** A separação de responsabilidades é intencional: bronze recebe e preserva, silver normaliza e valida. Se a bronze normalizar, perde-se o dado original para debugging. A silver pode sempre ser reconstruída a partir da bronze, mas o dado original (bruto) só existe na bronze.

---

## Questão 3 de 5

**Qual das colunas de rastreabilidade responde à pergunta "quando esse arquivo foi depositado no Volume?"**

- ( ) `ingestion_ts`
- (x) `source_file_modification_time`
- ( ) `source_batch_id`
- ( ) `source_file_name`

**Resposta correta:** `source_file_modification_time`

**Feedback:** `source_file_modification_time` vem de `_metadata.file_modification_time` — é o timestamp do arquivo no storage, que reflete quando ele foi criado ou modificado. `ingestion_ts` é quando o Spark leu o arquivo (pode ser diferente, especialmente se o processamento atrasou). Para saber quando o arquivo chegou no Volume, use `source_file_modification_time`.

---

## Questão 4 de 5

**Por que as tabelas de dimensão na bronze são append-only (nunca sobrescritas)?**

- ( ) Porque o Auto Loader só suporta append em tabelas externas
- ( ) Para economizar espaço de armazenamento
- (x) Para preservar o histórico de todos os batches e permitir que a silver escolha qual publicar
- ( ) Porque o schema de dimensão nunca muda

**Resposta correta:** Para preservar o histórico de todos os batches e permitir que a silver escolha qual publicar

**Feedback:** A bronze acumula todos os full extracts de dimensão. Cada batch tem `extract_batch_id` e `extract_ts`. A silver usa o `extract_batch_id` mais recente para publicar o current-state. Se a bronze sobrescrevesse, o histórico seria perdido e seria impossível reconstruir a silver para um ponto no tempo.

---

## Questão 5 de 5

**No projeto, onde fica definido o schema da tabela `bronze_fact_sales_events_raw`?**

- ( ) No próprio arquivo `bronze_facts.py` como um dicionário Python
- ( ) Em uma tabela Delta no Unity Catalog
- (x) Em um arquivo YAML em `config/tables/bronze/fact_sales_events.yml`
- ( ) O schema é inferido automaticamente pelo Auto Loader na primeira carga

**Resposta correta:** Em um arquivo YAML em `config/tables/bronze/fact_sales_events.yml`

**Feedback:** O projeto usa configuração declarativa: cada tabela tem um spec YAML com os campos, tipos e nulabilidade. O `BronzeIngestionService` usa o `spark_schema.py` para converter esse YAML em `StructType` do Spark. O schema não está no arquivo de pipeline nem é inferido — ele é declarado e validado via Pydantic.
