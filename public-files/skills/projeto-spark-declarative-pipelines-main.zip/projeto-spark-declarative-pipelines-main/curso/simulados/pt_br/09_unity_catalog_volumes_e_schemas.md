# Questionário — Unity Catalog: Volumes e Schemas

## Questão 1 de 5

**Como é estruturado o namespace de três níveis do Unity Catalog?**

- ( ) workspace → database → table
- ( ) database → schema → object
- (x) catalog → schema → object (table / view / volume / function)
- ( ) region → catalog → schema

**Resposta correta:** catalog → schema → object (table / view / volume / function)

**Feedback:** O Unity Catalog usa três níveis: catálogo, schema (equivalente ao "database" tradicional) e objeto. Para referenciar uma tabela: `catalog.schema.tabela`. Para acessar um arquivo em volume: `/Volumes/catalog/schema/volume/caminho/arquivo`. Esse namespace é consistente em SQL, Python e na UI.

---

## Questão 2 de 5

**O projeto usa nomes como `sdp_dev_bronze` e `sdp_dev_silver` para schemas. Por que essa convenção de nomes?**

- ( ) Porque o Databricks exige prefixo de ambiente em todos os schemas
- ( ) Para facilitar a descoberta via `SHOW SCHEMAS`
- (x) Para permitir que múltiplos ambientes (dev, acc, prd) coexistam no mesmo catálogo, essencial para free-tier
- ( ) Para identificar a camada de dados sem precisar abrir as tabelas

**Resposta correta:** Para permitir que múltiplos ambientes (dev, acc, prd) coexistam no mesmo catálogo, essencial para free-tier

**Feedback:** Em workspaces free-tier, não é possível criar catálogos adicionais facilmente. O projeto usa isolamento por schema: cada ambiente tem seus próprios schemas com prefixo de ambiente. Assim, `dev`, `acc` e `prd` podem coexistir no mesmo catálogo sem se interferir.

---

## Questão 3 de 5

**Qual é a diferença entre uma tabela Delta e um Volume no Unity Catalog?**

- ( ) Tabelas Delta são mais seguras; Volumes não têm controle de acesso
- (x) Tabelas Delta armazenam dados estruturados (linhas/colunas); Volumes armazenam arquivos de qualquer formato
- ( ) Volumes são mais rápidos para leitura que tabelas Delta
- ( ) Tabelas Delta são acessadas por SQL; Volumes são acessados apenas por Python

**Resposta correta:** Tabelas Delta armazenam dados estruturados (linhas/colunas); Volumes armazenam arquivos de qualquer formato

**Feedback:** Volumes são "pastas gerenciadas" dentro do namespace do UC para arquivos — CSVs, JSONs, imagens, artefatos de bundle, etc. Tabelas Delta armazenam dados estruturados com ACID e schema enforcement. Ambos têm governança do Unity Catalog (permissões, auditoria), mas com propósitos diferentes.

---

## Questão 4 de 5

**O `ResolvedProjectContext` resolve o caminho de um volume como `/Volumes/main/sdp_dev_ops/raw_data`. Por que o projeto usa essa abstração em vez de hardcodar o caminho?**

- ( ) Porque `/Volumes/` precisa ser calculado dinamicamente em tempo de execução
- ( ) Para economizar caracteres no código
- (x) Para que o mesmo código funcione em dev, acc e prd sem modificação — só a configuração de ambiente muda
- ( ) Porque o Unity Catalog não permite caminhos hardcoded

**Resposta correta:** Para que o mesmo código funcione em dev, acc e prd sem modificação — só a configuração de ambiente muda

**Feedback:** O `ResolvedProjectContext` resolve nomes lógicos (`"raw_data"`) para caminhos físicos baseado na configuração do ambiente. Em dev, `raw_data` mapeia para `/Volumes/main/sdp_dev_ops/raw_data`. Em prd, pode mapear para outro catálogo ou volume. O código de pipeline não muda — só o YAML de ambiente.

---

## Questão 5 de 5

**A estratégia de fallback do projeto tenta criar volumes em `[current_catalog, "workspace", "main"]`. Por que essa ordem?**

- ( ) Por ordem alfabética reversa
- (x) Para tentar primeiro o ambiente atual do usuário, e recuar para catálogos conhecidos do free-tier se necessário
- ( ) Para maximizar a chance de criar o volume com o maior espaço disponível
- ( ) Porque `workspace` e `main` são os únicos catálogos permitidos no Databricks

**Resposta correta:** Para tentar primeiro o ambiente atual do usuário, e recuar para catálogos conhecidos do free-tier se necessário

**Feedback:** A estratégia garante compatibilidade: tenta o catálogo atual (que pode ser enterprise ou configurado pelo admin), depois `workspace` (catálogo padrão do free-tier) e por fim `main` (outro catálogo comum). Cada tentativa inclui schemas alternativos como `aprender_dados` e `default`. Isso permite que os notebooks funcionem em praticamente qualquer workspace Databricks.
