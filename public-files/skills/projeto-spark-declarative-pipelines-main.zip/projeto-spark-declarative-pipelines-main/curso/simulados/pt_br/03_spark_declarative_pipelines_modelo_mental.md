# Questionário — Spark Declarative Pipelines: Modelo Mental

## Questão 1 de 5

**Qual é a diferença principal entre uma streaming table e uma materialized view em Spark Declarative Pipelines?**

- ( ) Streaming table usa SQL; materialized view usa Python
- (x) Streaming table processa dados incrementalmente; materialized view recalcula completamente a cada execução
- ( ) Streaming table é mais rápida; materialized view tem melhor compressão
- ( ) Streaming table aceita apenas Auto Loader; materialized view aceita apenas tabelas Delta

**Resposta correta:** Streaming table processa dados incrementalmente; materialized view recalcula completamente a cada execução

**Feedback:** Essa é a distinção central. A streaming table usa checkpoint e processa apenas dados novos desde a última execução — é ideal para bronze e silver de fatos. A materialized view recalcula a partir do estado atual das fontes — é ideal para gold (dimensões conformadas, OBT, métricas).

---

## Questão 2 de 5

**No projeto, as tabelas da camada gold são definidas como `@dp.table` ou `@dp.materialized_view`?**

- ( ) `@dp.table`, porque a gold acumula dados incrementalmente
- ( ) Qualquer um — não há diferença para tabelas gold
- (x) `@dp.materialized_view`, porque a gold recalcula o estado atual a cada execução
- ( ) A gold não usa pipeline declarativa — ela usa `spark.write` direto

**Resposta correta:** `@dp.materialized_view`, porque a gold recalcula o estado atual a cada execução

**Feedback:** As dimensões conformadas, a OBT e as métricas da gold são derivadas do estado corrente da silver. A cada execução da pipeline, a gold recalcula e substitui o conteúdo anterior. Isso é o comportamento da materialized view — diferente da streaming table que acumula.

---

## Questão 3 de 5

**O que o pipeline graph do Databricks mostra que uma sequência de notebooks orquestrada por Job não mostraria?**

- ( ) Qual usuário executou a pipeline
- ( ) O código-fonte de cada transformação
- (x) As dependências entre ativos e métricas de linhas processadas/descartadas por expectation
- ( ) O custo de compute de cada etapa

**Resposta correta:** As dependências entre ativos e métricas de linhas processadas/descartadas por expectation

**Feedback:** O pipeline graph mostra visualmente quais ativos dependem de quais, quantas linhas foram processadas por cada ativo, e quantas foram descartadas por cada expectation. Em notebooks orquestrados, dependências são implícitas no código e qualidade precisa ser monitorada manualmente.

---

## Questão 4 de 5

**Por que os arquivos de pipeline do projeto (`bronze_dimensions.py`, `silver_facts.py`, etc.) não contêm a lógica de transformação diretamente?**

- ( ) Por limitação do framework — pipeline declarativa não aceita código complexo
- (x) Por separação de responsabilidades: os arquivos declaram ativos, os serviços contêm a lógica
- ( ) Para facilitar a geração automática de código YAML
- ( ) Porque a lógica de transformação vive no YAML de configuração

**Resposta correta:** Por separação de responsabilidades: os arquivos declaram ativos, os serviços contêm a lógica

**Feedback:** Os arquivos de pipeline declaram o que existe (nome da tabela, dependências, expectations) e chamam serviços que fazem o trabalho real. `BronzeIngestionService`, `SalesEventSilverBuilder`, `ConformedDimensionService` — cada um tem uma responsabilidade clara. Isso facilita testes, reutilização e manutenção.

---

## Questão 5 de 5

**O que acontece com linhas que violam uma regra declarada com `@dp.expect_or_drop`?**

- ( ) A pipeline para com erro
- ( ) As linhas passam para a tabela mas são marcadas com uma flag
- (x) As linhas são descartadas silenciosamente; o pipeline graph mostra a contagem de descartadas
- ( ) As linhas são enviadas para uma tabela de quarentena

**Resposta correta:** As linhas são descartadas silenciosamente; o pipeline graph mostra a contagem de descartadas

**Feedback:** `@dp.expect_or_drop` descarta as linhas inválidas sem parar a pipeline. As linhas válidas continuam normalmente. O pipeline graph e o event log registram quantas linhas foram descartadas por cada regra — é assim que você monitora a qualidade sem inspecionar manualmente.
