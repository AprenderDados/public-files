# Questionário — Camada Silver: Qualidade e Estado Corrente

## Questão 1 de 5

**A dimensão de produto foi exportada em três batches (segunda, quarta e sexta). Um produto que existia no batch de segunda e quarta não aparece no batch de sexta. O que a silver publica na sexta?**

- ( ) Publica o produto com uma flag `deleted = true`
- ( ) Publica o produto como estava no batch de quarta
- (x) Não publica o produto — ele está ausente do último batch e portanto ausente do current-state
- ( ) A silver mantém todos os produtos de todos os batches como histórico

**Resposta correta:** Não publica o produto — ele está ausente do último batch e portanto ausente do current-state

**Feedback:** O current-state pattern publica apenas o batch mais recente. Se uma chave não está no último batch, ela não está na silver. Essa ausência representa naturalmente uma deleção — sem precisar de marcadores explícitos ou CDC. A bronze preserva os batches anteriores para auditoria.

---

## Questão 2 de 5

**A silver de fatos aplica três transformações em ordem. Qual é a ordem correta?**

- ( ) Deduplicação → Normalização → Filtro de rescued data
- ( ) Normalização → Filtro de rescued data → Deduplicação
- (x) Filtro de rescued data → Normalização → Deduplicação
- ( ) Filtro de rescued data → Deduplicação → Normalização

**Resposta correta:** Filtro de rescued data → Normalização → Deduplicação

**Feedback:** A ordem faz sentido: primeiro descarta linhas com schema corrompido (`_rescued_data` não-nulo), depois normaliza os valores válidos (upper, trim, round), depois deduplica por chave de negócio. Normalizar antes de filtrar seria desperdiçar trabalho em dados que serão descartados. Deduplicar antes de normalizar pode manter duplicatas com valores não-normalizados.

---

## Questão 3 de 5

**A deduplicação usa `row_number()` com um critério de ordenação. Se dois registros têm o mesmo `sales_event_id`, qual é mantido?**

- ( ) O registro com menor `ingestion_ts` (o mais antigo)
- ( ) O registro escolhido aleatoriamente pelo Spark
- (x) O registro com maior `extract_ts`, `source_file_modification_time` e `ingestion_ts` (o mais recente)
- ( ) O registro que chegou no primeiro arquivo processado

**Resposta correta:** O registro com maior `extract_ts`, `source_file_modification_time` e `ingestion_ts` (o mais recente)

**Feedback:** A janela de deduplicação ordena por `extract_ts DESC, source_file_modification_time DESC, ingestion_ts DESC`. O `row_number() = 1` mantém o mais recente por cada conjunto de business keys. Esse critério é determinístico — sempre produz o mesmo resultado para o mesmo conjunto de dados.

---

## Questão 4 de 5

**Por que o projeto não usa SCD2 para dimensões?**

- ( ) SCD2 não é suportado por Spark Declarative Pipelines
- ( ) SCD2 requer catálogos Enterprise que não estão disponíveis no free-tier
- (x) SCD2 adicionaria complexidade significativa sem benefício direto para o domínio analítico do projeto
- ( ) SCD2 só funciona com dimensões menores que 1 milhão de registros

**Resposta correta:** SCD2 adicionaria complexidade significativa sem benefício direto para o domínio analítico do projeto

**Feedback:** SCD2 preserva o histórico de mudanças de atributos de dimensão (ex: produto mudou de categoria). O projeto decide que o estado corrente é suficiente para análise — os fatos históricos continuam na silver, apenas enriquecidos com o estado atual das dimensões. Essa é uma decisão de design intencional para manter o projeto didaticamente focado.

---

## Questão 5 de 5

**Um arquivo chega com `event_type = "ADJUSTMENT"` mas sem `reference_event_id` (campo nulo). A expectation `"reference_event_id_for_non_sale IS NOT NULL OR event_type = 'SALE'"` tem ação `drop`. O que acontece com essa linha?**

- ( ) A pipeline para com erro
- ( ) A linha entra na silver com um aviso no log
- (x) A linha é descartada silenciosamente e a contagem de drop aparece no pipeline graph
- ( ) A linha entra na silver com `reference_event_id = -1` como fallback

**Resposta correta:** A linha é descartada silenciosamente e a contagem de drop aparece no pipeline graph

**Feedback:** `action: drop` descarta a linha sem parar a pipeline. O pipeline graph e o event log registram a contagem de linhas descartadas por essa regra. A linha não entra na silver e não pode ser recuperada a menos que o arquivo seja reprocessado (após corrigir o dado na origem).
