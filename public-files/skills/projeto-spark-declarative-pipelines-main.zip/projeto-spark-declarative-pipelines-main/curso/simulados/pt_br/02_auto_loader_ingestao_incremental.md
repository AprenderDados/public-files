# Questionário — Auto Loader: Ingestão Incremental de Arquivos

## Questão 1 de 5

**Um novo arquivo CSV foi depositado em um Volume. A pipeline com Auto Loader já processou os arquivos anteriores. O que acontece na próxima execução da pipeline?**

- ( ) Todos os arquivos (anteriores e novos) são reprocessados
- (x) Apenas o arquivo novo é processado; os anteriores são ignorados pelo checkpoint
- ( ) A pipeline falha porque já existe dado na tabela bronze
- ( ) O Auto Loader precisa ser reiniciado manualmente para detectar o novo arquivo

**Resposta correta:** Apenas o arquivo novo é processado; os anteriores são ignorados pelo checkpoint

**Feedback:** O Auto Loader usa um checkpoint para rastrear quais arquivos já foram processados. Na próxima execução, ele compara o estado atual do diretório com o checkpoint e processa apenas os novos. Esse é o mecanismo central de ingestão incremental.

---

## Questão 2 de 5

**Um campo `sales_date` é declarado como `DateType` no schema explícito do Auto Loader. O arquivo CSV tem `invalid_date` nesse campo. O que acontece?**

- ( ) A pipeline falha com erro de parse
- ( ) A linha é descartada silenciosamente
- (x) A linha é ingerida com `sales_date = null` e o valor original vai para `_rescued_data`
- ( ) O campo é ingerido como string, ignorando o schema

**Resposta correta:** A linha é ingerida com `sales_date = null` e o valor original vai para `_rescued_data`

**Feedback:** Com schema explícito, o Auto Loader não rejeita linhas com valores incompatíveis — ele captura o campo problemático em `_rescued_data` como JSON e coloca `null` no campo tipado. A linha continua na bronze. A silver é quem descarta linhas com `_rescued_data` não-nulo.

---

## Questão 3 de 5

**Por que o projeto usa schema explícito em vez de inferência automática no Auto Loader?**

- ( ) Inferência automática é mais lenta
- ( ) Schema explícito é obrigatório pela API do Auto Loader
- (x) Para garantir tipos corretos desde a ingestão e habilitar _rescued_data como detector de anomalias
- ( ) Inferência automática não funciona com arquivos CSV

**Resposta correta:** Para garantir tipos corretos desde a ingestão e habilitar _rescued_data como detector de anomalias

**Feedback:** A inferência pode errar tipos (um campo com apenas valores inteiros pode ser inferido como `INT` quando deveria ser `LONG`). Sem schema explícito, `_rescued_data` não tem referência para detectar o que é anômalo. Com schema explícito, o projeto garante tipos corretos e visibilidade de problemas de origem.

---

## Questão 4 de 5

**Qual coluna de metadados do Auto Loader permite saber exatamente em qual arquivo de origem um determinado registro estava?**

- ( ) `_source_file`
- ( ) `_batch_id`
- (x) `_metadata.file_path`
- ( ) `source_path`

**Resposta correta:** `_metadata.file_path`

**Feedback:** O Auto Loader expõe o struct `_metadata` com informações do arquivo. `_metadata.file_path` contém o caminho completo do arquivo. O projeto extrai esse campo e o armazena como `source_file_path` na bronze, permitindo rastrear cada linha até o arquivo de origem.

---

## Questão 5 de 5

**Qual é o papel do `BronzeIngestionService` no projeto?**

- ( ) Ele cria os arquivos CSV que a pipeline vai ler
- ( ) Ele gerencia o checkpoint do Auto Loader manualmente
- (x) Ele encapsula a lógica de leitura com Auto Loader, schema explícito e colunas de rastreabilidade
- ( ) Ele é responsável pela qualidade e deduplicação dos dados ingeridos

**Resposta correta:** Ele encapsula a lógica de leitura com Auto Loader, schema explícito e colunas de rastreabilidade

**Feedback:** O `BronzeIngestionService` recebe o spec da tabela (schema) e o caminho do Volume, configura o Auto Loader com `cloudFiles.format`, aplica o schema explícito via `StructType` gerado do YAML, e adiciona as 5 colunas de rastreabilidade. Qualidade e deduplicação são responsabilidades da silver.
