# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 01
# MAGIC ## Delta Tables — Fundamentos

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno demonstra os fundamentos do formato Delta Lake: criação de tabelas, escrita, leitura, transações ACID e time travel. O objetivo é construir uma base sólida antes de entrar nas camadas de pipeline do projeto.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Por que Delta e não Parquet simples?
# MAGIC
# MAGIC Parquet é um formato colunar eficiente para leitura. Delta é Parquet com uma camada extra chamada **transaction log** (`_delta_log/`).
# MAGIC
# MAGIC Esse log transforma o diretório de arquivos em algo muito mais robusto:
# MAGIC
# MAGIC - **ACID**: escrita e leitura são consistentes mesmo com processos simultâneos
# MAGIC - **Schema enforcement**: o schema é gravado e validado a cada escrita
# MAGIC - **Time travel**: versões antigas dos dados continuam acessíveis
# MAGIC - **Rollback**: é possível voltar a uma versão anterior
# MAGIC - **Compaction**: vacuuming e otimização sem interromper leitores
# MAGIC
# MAGIC No projeto Spark Declarative Pipelines, **todas as tabelas de todas as camadas** (bronze, silver, gold) são tabelas Delta. O Auto Loader, as streaming tables e as materialized views escrevem em Delta por padrão.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, DateType


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]

    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)

    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")

    raise RuntimeError(
        "Não foi possível criar ou reutilizar um Volume para este módulo.\n" + "\n".join(errors)
    )


CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_01_delta")
TARGET_SCHEMA = "sdp_curso_delta_lab"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")
for table in ["produtos_raw", "produtos_gold", "vendas_raw"]:
    spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.{TARGET_SCHEMA}.{table}")

DELTA_PATH = f"{BASE_PATH}/delta_demo"

setup_variables = {
    "CATALOG": CATALOG,
    "SCHEMA": SCHEMA,
    "TARGET_SCHEMA": TARGET_SCHEMA,
    "VOLUME": VOLUME,
    "BASE_PATH": BASE_PATH,
    "DELTA_PATH": DELTA_PATH,
}

# COMMAND ----------

print("Variáveis principais do módulo:")
for k, v in setup_variables.items():
    print(f"- {k}: {v}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Criar uma tabela Delta com dados de exemplo
# MAGIC
# MAGIC Vamos usar um domínio simples: produtos de uma loja esportiva.
# MAGIC
# MAGIC O `saveAsTable` cria a tabela no Unity Catalog com formato Delta por padrão. Não é necessário especificar o formato — Delta é o padrão do Databricks.

# COMMAND ----------

produtos_df = spark.createDataFrame(
    [
        (1, "Mountain Bike 500", "Bikes", 2999.90, "2024-01-01"),
        (2, "Capacete Trail Pro", "Accessories", 349.90, "2024-01-01"),
        (3, "Luva de Ciclismo M", "Clothing", 89.90, "2024-01-01"),
        (4, "Pedal de Alumínio", "Components", 199.90, "2024-01-01"),
        (5, "Road Bike 700", "Bikes", 4599.90, "2024-02-01"),
    ],
    "product_id INT, name STRING, category STRING, list_price DOUBLE, created_date STRING",
)

produtos_df.write.format("delta").mode("overwrite").saveAsTable(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw")

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Inspecionar o transaction log
# MAGIC
# MAGIC O `_delta_log/` guarda um arquivo JSON para cada transação. Cada arquivo descreve o que mudou: arquivos adicionados, removidos e o schema registrado.
# MAGIC
# MAGIC Esse log é a fundação do ACID no Delta Lake.

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL sdp_curso_delta_lab.produtos_raw

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Escrever dados adicionais — modo append
# MAGIC
# MAGIC Com `mode("append")`, os dados novos são somados aos existentes. O transaction log registra os novos arquivos sem tocar nos anteriores.

# COMMAND ----------

novos_produtos_df = spark.createDataFrame(
    [
        (6, "Camiseta UV Pro", "Clothing", 129.90, "2024-03-01"),
        (7, "Óculos de Sol MTB", "Accessories", 279.90, "2024-03-01"),
    ],
    "product_id INT, name STRING, category STRING, list_price DOUBLE, created_date STRING",
)

novos_produtos_df.write.format("delta").mode("append").saveAsTable(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw")

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw").orderBy("product_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Atualizar um registro com UPDATE
# MAGIC
# MAGIC Delta suporta `UPDATE`, `DELETE` e `MERGE` diretamente em tabelas gerenciadas.
# MAGIC
# MAGIC Isso é fundamental para as camadas silver e gold do projeto, onde registros são atualizados ou substituídos.

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE sdp_curso_delta_lab.produtos_raw
# MAGIC SET list_price = 3199.90
# MAGIC WHERE product_id = 1

# COMMAND ----------

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw").filter("product_id = 1"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Time travel — acessar versões anteriores
# MAGIC
# MAGIC O transaction log preserva todas as versões. Você pode consultar versões antigas com `VERSION AS OF` ou `TIMESTAMP AS OF`.
# MAGIC
# MAGIC Esse recurso é crucial para auditoria, rollback e debugging de pipelines.

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY sdp_curso_delta_lab.produtos_raw

# COMMAND ----------

versao_original = spark.read.format("delta").option("versionAsOf", 0).table(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw")
display(versao_original.filter("product_id = 1"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Schema enforcement na prática
# MAGIC
# MAGIC O Delta rejeita escritas com schema incompatível. Isso protege a integridade dos dados downstream.
# MAGIC
# MAGIC O projeto usa essa característica para garantir que dados fora do schema esperado sejam capturados na coluna `_rescued_data` e não contaminem silenciosamente as camadas seguintes.

# COMMAND ----------

try:
    df_schema_errado = spark.createDataFrame(
        [(99, "Produto Teste", "Bikes", "preco_invalido", "2024-04-01")],
        "product_id INT, name STRING, category STRING, list_price STRING, created_date STRING",
    )
    df_schema_errado.write.format("delta").mode("append").saveAsTable(f"{CATALOG}.{TARGET_SCHEMA}.produtos_raw")
    print("ATENÇÃO: a escrita passou quando não deveria.")
except Exception as e:
    print("Schema enforcement funcionou corretamente.")
    print("Erro:", str(e)[:300])

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Delta no projeto Spark Declarative Pipelines
# MAGIC
# MAGIC No projeto, todas as tabelas são Delta. Mas você nunca escreve `format("delta")` diretamente nas camadas — quem faz isso são as abstrações do Lakeflow.
# MAGIC
# MAGIC A tabela `bronze_fact_sales_events_raw`, por exemplo, é criada pelo Auto Loader via streaming table. A tabela `silver_fact_sales_events_clean` é criada com expectations e deduplicação. A tabela `gold_sales_analytics_obt` é a One Big Table com joins de dimensão.
# MAGIC
# MAGIC Todas são Delta. O formato é transparente porque o Databricks gerencia isso internamente.
# MAGIC
# MAGIC O que você **controla** no projeto é:
# MAGIC - o schema de cada tabela (em YAML)
# MAGIC - as regras de qualidade (expectations em YAML)
# MAGIC - as chaves de deduplicação (business_keys em YAML)
# MAGIC - as transformações em Python

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. O que você praticou
# MAGIC
# MAGIC - Criou uma tabela Delta com `saveAsTable`
# MAGIC - Adicionou dados com `append`
# MAGIC - Atualizou registros com `UPDATE`
# MAGIC - Acessou versões anteriores com time travel
# MAGIC - Viu schema enforcement em ação
# MAGIC - Entendeu por que o projeto usa Delta em todas as camadas

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Perguntas de checkpoint
# MAGIC
# MAGIC 1. O que diferencia uma tabela Delta de um diretório Parquet simples?
# MAGIC 2. Onde o Delta armazena o histórico de transações?
# MAGIC 3. O que acontece quando você tenta gravar um DataFrame com schema diferente em uma tabela Delta existente?
# MAGIC 4. Como o time travel ajuda no debugging de uma pipeline de dados?
# MAGIC 5. No projeto Spark Declarative Pipelines, quem escreve em Delta? O engenheiro escreve esse código diretamente?
