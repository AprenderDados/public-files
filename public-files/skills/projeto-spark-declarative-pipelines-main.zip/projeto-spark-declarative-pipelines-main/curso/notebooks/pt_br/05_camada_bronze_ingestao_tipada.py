# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 05
# MAGIC ## Camada Bronze — Ingestão Tipada e Rastreável

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno destrincha a camada bronze do projeto: por que o schema é explícito, o papel das colunas de rastreabilidade, como a coluna _rescued_data funciona, e como o BronzeIngestionService encapsula tudo isso. Você vai ver o YAML de configuração e o código real do projeto.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O papel da camada bronze
# MAGIC
# MAGIC A camada bronze existe para uma função muito específica: **receber e preservar o dado bruto com máximo de fidelidade**, sem nenhuma transformação de negócio.
# MAGIC
# MAGIC O que a bronze faz:
# MAGIC - lê arquivos do Volume com Auto Loader
# MAGIC - aplica o schema explícito configurado em YAML
# MAGIC - adiciona colunas de rastreabilidade operacional
# MAGIC - captura na coluna `_rescued_data` qualquer valor que não encaixe no schema
# MAGIC
# MAGIC O que a bronze **não** faz:
# MAGIC - normalização de valores (maiúsculas/minúsculas, trim, etc.)
# MAGIC - validação de regras de negócio
# MAGIC - deduplicação
# MAGIC - joins com outras tabelas
# MAGIC
# MAGIC Tudo isso é responsabilidade da silver.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, LongType, IntegerType, StringType,
    DateType, TimestampType, DecimalType
)


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)
    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")
    raise RuntimeError("Não foi possível criar Volume.\n" + "\n".join(errors))


CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_05_bronze")
TARGET_SCHEMA = "sdp_curso_bronze_lab"
LANDING_EVENTS = f"{BASE_PATH}/landing/events"
CHECKPOINT_EVENTS = f"{BASE_PATH}/checkpoints/events_bronze"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")
for t in ["bronze_eventos_tipados", "bronze_eventos_tudo_string"]:
    spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.{TARGET_SCHEMA}.{t}")

try:
    dbutils.fs.rm(LANDING_EVENTS, True)
    dbutils.fs.rm(CHECKPOINT_EVENTS, True)
except Exception:
    pass
dbutils.fs.mkdirs(LANDING_EVENTS)

print(f"CATALOG: {CATALOG}, TARGET_SCHEMA: {TARGET_SCHEMA}")
print(f"BASE_PATH: {BASE_PATH}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. O problema de usar "tudo string"
# MAGIC
# MAGIC Alguns projetos chegam na bronze com um schema do tipo "aceito tudo como string e processo depois". Isso parece seguro mas cria problemas:
# MAGIC
# MAGIC - **Erros aparecem tarde**: um campo numérico inválido só vai quebrar quando algum cast downstream falhar
# MAGIC - **Debugging difícil**: não se sabe em qual arquivo o dado problemático entrou
# MAGIC - **Sem proteção de tipo**: dois campos que deveriam ser numéricos podem ter chegado trocados sem que ninguém perceba
# MAGIC
# MAGIC O projeto usa **schema explícito** com `_rescued_data` exatamente para evitar isso.

# COMMAND ----------

eventos_batch_01 = """event_id,order_id,product_id,customer_id,event_type,event_date,quantity,amount,currency
E001,O001,10,C001,SALE,2024-04-01,2,599.80,USD
E002,O001,11,C001,SALE,2024-04-01,1,349.90,USD
E003,O002,10,C002,ADJUSTMENT,2024-04-02,-1,-299.90,USD
E004,O003,12,C003,SALE,invalid_date,1,89.90,USD
E005,O003,13,C004,DESCONHECIDO,2024-04-02,1,texto_invalido,USD
"""

dbutils.fs.put(f"{LANDING_EVENTS}/batch_01.csv", eventos_batch_01, True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Ingestão com "tudo string" — o que acontece?

# COMMAND ----------

CHECKPOINT_STRING = f"{CHECKPOINT_EVENTS}_string"
try:
    dbutils.fs.rm(CHECKPOINT_STRING, True)
except Exception:
    pass

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .option("inferSchema", "false")
    .load(LANDING_EVENTS)
    .writeStream
    .format("delta")
    .option("checkpointLocation", CHECKPOINT_STRING)
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.bronze_eventos_tudo_string")
    .awaitTermination()
)

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.bronze_eventos_tudo_string"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** todas as 5 linhas entraram, inclusive `E004` com `invalid_date` e `E005` com `texto_invalido` no campo de valor. A bronze "tudo string" aceita tudo silenciosamente — e o problema vai aparecer muito mais tarde.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Ingestão com schema explícito e _rescued_data

# COMMAND ----------

CHECKPOINT_TIPADO = f"{CHECKPOINT_EVENTS}_tipado"
try:
    dbutils.fs.rm(CHECKPOINT_TIPADO, True)
except Exception:
    pass

schema_eventos = StructType([
    StructField("event_id", StringType(), False),
    StructField("order_id", StringType(), True),
    StructField("product_id", IntegerType(), True),
    StructField("customer_id", StringType(), True),
    StructField("event_type", StringType(), True),
    StructField("event_date", DateType(), True),
    StructField("quantity", IntegerType(), True),
    StructField("amount", DecimalType(19, 4), True),
    StructField("currency", StringType(), True),
])

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .schema(schema_eventos)
    .load(LANDING_EVENTS)
    .select(
        "event_id", "order_id", "product_id", "customer_id",
        "event_type", "event_date", "quantity", "amount", "currency",
        F.current_timestamp().alias("ingestion_ts"),
        F.col("_metadata.file_path").alias("source_file_path"),
        F.col("_metadata.file_modification_time").alias("source_file_modification_time"),
        F.col("_metadata.file_name").alias("source_file_name"),
        "_rescued_data",
    )
    .writeStream
    .format("delta")
    .option("checkpointLocation", CHECKPOINT_TIPADO)
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.bronze_eventos_tipados")
    .awaitTermination()
)

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.bronze_eventos_tipados"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** `E004` e `E005` têm `_rescued_data` não-nulo porque algum campo não encaixou no schema. Os valores problemáticos foram capturados em JSON nessa coluna, não em strings silenciosas.

# COMMAND ----------

print("Registros com _rescued_data não-nulo:")
display(
    spark.table(f"{CATALOG}.{TARGET_SCHEMA}.bronze_eventos_tipados")
    .filter(F.col("_rescued_data").isNotNull())
    .select("event_id", "event_date", "amount", "_rescued_data")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. As cinco colunas de rastreabilidade
# MAGIC
# MAGIC O projeto adiciona cinco colunas operacionais a cada registro na bronze. Essas colunas permitem rastrear exatamente de onde veio cada linha e quando ela foi ingerida.
# MAGIC
# MAGIC | Coluna | Tipo | Origem | Pergunta que responde |
# MAGIC |---|---|---|---|
# MAGIC | `ingestion_ts` | TIMESTAMP | `current_timestamp()` | Quando foi ingerido? |
# MAGIC | `source_file_path` | STRING | `_metadata.file_path` | Em qual caminho do Volume? |
# MAGIC | `source_file_modification_time` | TIMESTAMP | `_metadata.file_modification_time` | Quando o arquivo foi escrito? |
# MAGIC | `source_file_name` | STRING | `_metadata.file_name` | Qual arquivo? |
# MAGIC | `source_batch_id` | STRING | extraído do nome do arquivo | Qual batch de geração? |
# MAGIC
# MAGIC Essas colunas nunca são removidas. Elas sobem para a silver e estão disponíveis para debugging ao longo de toda a pipeline.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Como o spec YAML configura a bronze
# MAGIC
# MAGIC No projeto, cada tabela bronze tem um arquivo YAML com seu schema completo. Exemplo do spec do fato de vendas:
# MAGIC
# MAGIC ```yaml
# MAGIC # config/tables/bronze/fact_sales_events.yml
# MAGIC table_name: bronze_fact_sales_events_raw
# MAGIC source_format: csv
# MAGIC fields:
# MAGIC   - name: sales_event_id
# MAGIC     type: long
# MAGIC     nullable: false
# MAGIC   - name: order_id
# MAGIC     type: long
# MAGIC     nullable: true
# MAGIC   - name: event_type
# MAGIC     type: string
# MAGIC     nullable: false
# MAGIC   - name: sales_date
# MAGIC     type: date
# MAGIC     nullable: true
# MAGIC   - name: amount_delta
# MAGIC     type: decimal(19,4)
# MAGIC     nullable: true
# MAGIC ```
# MAGIC
# MAGIC O `BronzeIngestionService` usa o `spark_schema.py` para converter esse YAML em um `StructType` do Spark e configura o Auto Loader com esse schema.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. O que você praticou
# MAGIC
# MAGIC - Comparou ingestão "tudo string" com schema explícito
# MAGIC - Viu como `_rescued_data` captura valores problemáticos sem quebrar a pipeline
# MAGIC - Adicionou as cinco colunas de rastreabilidade operacional
# MAGIC - Entendeu o papel da bronze (receber e preservar sem transformação de negócio)
# MAGIC - Viu como o spec YAML configura o schema da bronze no projeto real

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Por que a camada bronze usa schema explícito em vez de inferência ou "tudo string"?
# MAGIC 2. O que acontece com um valor que não encaixa no schema explícito — a linha é descartada?
# MAGIC 3. Quais são as cinco colunas de rastreabilidade que a bronze adiciona? Para que cada uma serve?
# MAGIC 4. A bronze faz normalização de valores (ex: converter para maiúsculas)? Por quê?
# MAGIC 5. No projeto, onde fica a definição do schema de cada tabela bronze?
