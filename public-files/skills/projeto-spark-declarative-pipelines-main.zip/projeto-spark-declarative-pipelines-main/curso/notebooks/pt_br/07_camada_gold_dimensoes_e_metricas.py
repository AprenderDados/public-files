# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 07
# MAGIC ## Camada Gold — Dimensões Conformadas e Métricas

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno demonstra os padrões da camada gold: dimensões conformadas (joins de hierarquia), One Big Table (OBT) e métricas agregadas. Você vai entender por que todos os joins são LEFT e o que significa "conformed dimension" no contexto deste projeto.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O que a gold resolve
# MAGIC
# MAGIC A silver entrega dados limpos e normalizados, mas ainda em estrutura normalizada: fatos em uma tabela, dimensões em outras. Para consumo analítico, isso exige joins repetidos em cada consulta.
# MAGIC
# MAGIC A gold serve para publicar **ativos prontos para análise** sem processamento adicional:
# MAGIC
# MAGIC - **Dimensões conformadas**: tabelas de dimensão enriquecidas com toda a hierarquia consolidada
# MAGIC - **One Big Table (OBT)**: fatos enriquecidos com dimensões, no grão do evento
# MAGIC - **Métricas agregadas**: resultados calculados e materializados para consumo direto em dashboards

# COMMAND ----------

from pyspark.sql import functions as F


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)
    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")
    raise RuntimeError("Não foi possível criar Volume.\n" + "\n".join(errors))


CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_07_gold")
print(f"CATALOG: {CATALOG}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Dimensões conformadas — joins de hierarquia
# MAGIC
# MAGIC O catálogo de produtos tem quatro níveis: Categoria → Subcategoria → Produto → Modelo. A gold consolida tudo em uma única tabela plana.

# COMMAND ----------

categorias = spark.createDataFrame([
    (1, "Bikes"), (2, "Accessories"), (3, "Clothing"),
], "category_id INT, category_name STRING")

subcategorias = spark.createDataFrame([
    (1, 1, "Mountain Bikes"), (2, 1, "Road Bikes"), (3, 2, "Helmets"), (4, 3, "Gloves"),
], "subcategory_id INT, category_id INT, subcategory_name STRING")

produtos = spark.createDataFrame([
    (10, 1, "Mountain Bike 500", 2999.90),
    (11, 3, "Capacete Trail Pro", 349.90),
    (12, 4, "Luva de Ciclismo M", 89.90),
    (99, None, "Produto Sem Subcategoria", 49.90),
], "product_id INT, subcategory_id INT, product_name STRING, list_price DOUBLE")

# COMMAND ----------

dim_produto_gold = (
    produtos.alias("p")
    .join(subcategorias.alias("s"), on=(F.col("p.subcategory_id") == F.col("s.subcategory_id")), how="left")
    .join(categorias.alias("c"), on=(F.col("s.category_id") == F.col("c.category_id")), how="left")
    .select(
        F.col("p.product_id"),
        F.col("p.product_name"),
        F.col("p.list_price"),
        F.col("s.subcategory_name"),
        F.col("c.category_name"),
    )
)

display(dim_produto_gold.orderBy("product_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** o produto 99 (`Produto Sem Subcategoria`) aparece na dimensão conformada com `subcategory_name = null` e `category_name = null`. O LEFT JOIN garante que nenhum produto seja perdido mesmo quando a hierarquia está incompleta.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Por que todos os joins são LEFT?
# MAGIC
# MAGIC No projeto, **todos os joins da gold são LEFT (outer)**. O motivo é preservar fatos.
# MAGIC
# MAGIC Se um evento de venda referenciar um produto que foi deletado da dimensão (ou que nunca existiu), um INNER JOIN eliminaria esse evento dos relatórios. Com LEFT JOIN, o evento permanece — com valores nulos nos campos de dimensão.
# MAGIC
# MAGIC Em relatórios de auditoria e reconciliação, perder eventos é muito pior do que ter linhas com dimensões incompletas.

# COMMAND ----------

eventos = spark.createDataFrame([
    ("E001", 10, "SALE", "2024-04-01", 599.80),
    ("E002", 11, "SALE", "2024-04-01", 349.90),
    ("E003", 999, "SALE", "2024-04-02", 89.90),
], "event_id STRING, product_id INT, event_type STRING, event_date STRING, amount DOUBLE")

print("Com INNER JOIN — evento com product_id 999 desaparece:")
display(
    eventos.join(dim_produto_gold, on="product_id", how="inner")
    .select("event_id", "product_id", "product_name", "category_name", "amount")
    .orderBy("event_id")
)

# COMMAND ----------

print("Com LEFT JOIN — evento com product_id 999 permanece com dimensões nulas:")
display(
    eventos.join(dim_produto_gold, on="product_id", how="left")
    .select("event_id", "product_id", "product_name", "category_name", "amount")
    .orderBy("event_id")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. One Big Table (OBT) — fato enriquecido com dimensões
# MAGIC
# MAGIC A OBT une fatos com todas as dimensões em uma tabela plana no grão do evento. Isso elimina a necessidade de joins no momento do consumo.

# COMMAND ----------

clientes = spark.createDataFrame([
    (201, "Ana Silva", "Northwest"),
    (202, "Bruno Costa", "Canada"),
    (203, None, None),
], "customer_id INT, customer_name STRING, territory_name STRING")

obt = (
    eventos.alias("e")
    .join(dim_produto_gold.alias("p"), on="product_id", how="left")
    .join(clientes.alias("c"), on=(F.col("e.product_id").isNotNull()), how="left")
    .select(
        F.col("e.event_id"),
        F.col("e.event_type"),
        F.col("e.event_date"),
        F.col("e.amount"),
        F.col("p.product_name"),
        F.col("p.category_name"),
    )
)

print("One Big Table (OBT) — evento enriquecido:")
display(obt.orderBy("event_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Métricas agregadas
# MAGIC
# MAGIC A gold publica métricas calculadas e materializadas. Em vez de calcular `SUM`, `COUNT` e `AVG` a cada consulta no dashboard, a gold já entrega o resultado pronto.

# COMMAND ----------

eventos_completos = spark.createDataFrame([
    ("E001", "2024-04-01", "SALE", 2, 599.80),
    ("E002", "2024-04-01", "SALE", 1, 349.90),
    ("E003", "2024-04-02", "SALE", 3, 899.70),
    ("E004", "2024-04-02", "ADJUSTMENT", -1, -299.90),
    ("E005", "2024-04-03", "SALE", 1, 89.90),
    ("E006", "2024-04-03", "CANCEL", -1, -89.90),
], "event_id STRING, sales_date STRING, event_type STRING, quantity INT, amount DOUBLE")

daily_sales = (
    eventos_completos
    .groupBy("sales_date")
    .agg(
        F.sum("quantity").alias("net_quantity"),
        F.round(F.sum("amount"), 2).alias("net_revenue"),
        F.count("*").alias("event_count"),
        F.count(F.when(F.col("event_type").isin("ADJUSTMENT", "CANCEL"), True)).alias("correction_event_count"),
    )
    .orderBy("sales_date")
)

print("gold_daily_sales — métricas diárias:")
display(daily_sales)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Como o projeto implementa a gold
# MAGIC
# MAGIC O projeto tem duas classes para a gold:
# MAGIC
# MAGIC **`ConformedDimensionService`** — constrói dimensões conformadas:
# MAGIC ```python
# MAGIC # src/course_lakeflow/gold/conformed_dimension_service.py
# MAGIC class ConformedDimensionService:
# MAGIC     def build_dim_product(self, silver_tables: dict) -> DataFrame:
# MAGIC         return (
# MAGIC             silver_tables["product"].alias("p")
# MAGIC             .join(silver_tables["subcategory"].alias("s"), ...)
# MAGIC             .join(silver_tables["category"].alias("c"), ...)
# MAGIC             .join(silver_tables["model"].alias("m"), ...)
# MAGIC             .join(silver_tables["desc_culture"].alias("d"), ...)
# MAGIC             .select(...)
# MAGIC         )
# MAGIC ```
# MAGIC
# MAGIC **`GoldAggregationService`** — constrói OBT e métricas:
# MAGIC ```python
# MAGIC # src/course_lakeflow/gold/aggregation_service.py
# MAGIC class GoldAggregationService:
# MAGIC     def build_sales_analytics_obt(self, ...) -> DataFrame: ...
# MAGIC     def build_daily_sales(self, ...) -> DataFrame: ...
# MAGIC     def build_daily_sales_by_product(self, ...) -> DataFrame: ...
# MAGIC     def build_arrival_vs_business_date(self, ...) -> DataFrame: ...
# MAGIC     def build_correction_impact(self, ...) -> DataFrame: ...
# MAGIC ```
# MAGIC
# MAGIC As tabelas gold do projeto são `materialized_view` porque o conteúdo é recalculado a cada execução da pipeline — elas não são streaming.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Tabela de decisão — quando usar cada tipo de ativo na gold
# MAGIC
# MAGIC | Ativo | Tipo de pipeline | Quando usar |
# MAGIC |---|---|---|
# MAGIC | Dimensão conformada | `materialized_view` | Estado corrente, recalculado a cada execução |
# MAGIC | One Big Table (OBT) | `materialized_view` | Enriquecimento completo, grão do evento |
# MAGIC | Métrica agregada | `materialized_view` | Resultado calculado para consumo direto |
# MAGIC | Tabela de estado incremental | `streaming_table` | Acumulação de eventos ao longo do tempo |

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. O que você praticou
# MAGIC
# MAGIC - Construiu uma dimensão conformada com joins de hierarquia (categoria → subcategoria → produto)
# MAGIC - Entendeu por que todos os joins são LEFT (preservar eventos mesmo com dimensões incompletas)
# MAGIC - Construiu uma OBT enriquecendo fatos com dimensões
# MAGIC - Calculou métricas agregadas com `SUM`, `COUNT` e filtros por tipo de evento
# MAGIC - Entendeu como o projeto separa `ConformedDimensionService` e `GoldAggregationService`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Perguntas de checkpoint
# MAGIC
# MAGIC 1. O que é uma dimensão conformada e por que ela simplifica o consumo analítico?
# MAGIC 2. Por que todos os joins da gold são LEFT e não INNER?
# MAGIC 3. O que é uma One Big Table (OBT)? Qual é a vantagem de materiá-la em vez de calculá-la ad hoc?
# MAGIC 4. Por que as tabelas gold usam `materialized_view` e não `streaming_table`?
# MAGIC 5. No cálculo de `net_revenue`, eventos do tipo `ADJUSTMENT` e `CANCEL` são incluídos ou excluídos? Por quê?
