# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 08
# MAGIC ## Configuração Declarativa em YAML com Pydantic

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno explica por que o projeto separa configuração de código, como o YAML de tabelas é estruturado, como o Pydantic valida a configuração em tempo de carregamento, como o ConfigLoader faz merge entre ambientes, e como o spark_schema.py converte tipos YAML em StructType do Spark.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Por que configuração declarativa?
# MAGIC
# MAGIC Imagine que você tem 14 tabelas bronze, 14 silver e 7 gold. Cada tabela tem schema, regras de qualidade e chaves de deduplicação. Se tudo isso estiver hardcoded no código Python, qualquer mudança de schema exige editar código, testar e re-implantar.
# MAGIC
# MAGIC Com configuração declarativa em YAML:
# MAGIC
# MAGIC - **O schema fica em um lugar** — o YAML é a fonte da verdade, não o código
# MAGIC - **O código é genérico** — `BronzeIngestionService` funciona para qualquer tabela cujo spec seja carregado
# MAGIC - **Mudanças são rastreáveis** — um PR que muda um campo de `INT` para `LONG` é visível como alteração de YAML, não como alteração de código Python
# MAGIC - **Promoção entre ambientes é segura** — `config/environments/dev.yml` sobreescreve apenas o que precisa ser diferente em dev

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. A estrutura do spec de tabela
# MAGIC
# MAGIC No projeto, cada tabela tem um arquivo YAML em `config/tables/{camada}/{nome}.yml`. Veja a estrutura do fato de vendas na silver:
# MAGIC
# MAGIC ```yaml
# MAGIC # config/tables/silver/fact_sales_events.yml
# MAGIC table_name: silver_fact_sales_events_clean
# MAGIC source_table: bronze_fact_sales_events_raw
# MAGIC source_format: delta
# MAGIC
# MAGIC fields:
# MAGIC   - name: sales_event_id
# MAGIC     type: long
# MAGIC     nullable: false
# MAGIC   - name: event_type
# MAGIC     type: string
# MAGIC     nullable: false
# MAGIC   - name: sales_date
# MAGIC     type: date
# MAGIC     nullable: true
# MAGIC   - name: amount_delta
# MAGIC     type: decimal(19,4)
# MAGIC     nullable: true
# MAGIC
# MAGIC business_keys:
# MAGIC   - sales_event_id
# MAGIC
# MAGIC quality_rules:
# MAGIC   - name: valid_event_type
# MAGIC     expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
# MAGIC     action: drop
# MAGIC   - name: non_null_sales_event_id
# MAGIC     expression: "sales_event_id IS NOT NULL"
# MAGIC     action: fail
# MAGIC   - name: valid_date_order
# MAGIC     expression: "arrival_date >= sales_date"
# MAGIC     action: warn
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Pydantic valida o YAML na leitura
# MAGIC
# MAGIC O projeto usa Pydantic para garantir que o YAML carregado é válido antes de qualquer execução. Se um campo obrigatório estiver ausente ou com tipo errado, o erro aparece imediatamente ao carregar a configuração — não no meio da execução da pipeline.

# COMMAND ----------

from pydantic import BaseModel, field_validator
from typing import Optional
import yaml


class FieldSpec(BaseModel):
    name: str
    type: str
    nullable: bool = True


class QualityRuleSpec(BaseModel):
    name: str
    expression: str
    action: str

    @field_validator("action")
    @classmethod
    def action_must_be_valid(cls, v):
        allowed = {"warn", "drop", "fail"}
        if v not in allowed:
            raise ValueError(f"action deve ser um de {allowed}, recebido: {v!r}")
        return v


class TableSpec(BaseModel):
    table_name: str
    source_table: Optional[str] = None
    source_format: str = "delta"
    fields: list[FieldSpec] = []
    business_keys: list[str] = []
    quality_rules: list[QualityRuleSpec] = []


spec_yaml_valido = """
table_name: silver_fact_vendas_clean
source_table: bronze_fact_vendas_raw
source_format: delta
fields:
  - name: event_id
    type: long
    nullable: false
  - name: event_type
    type: string
    nullable: false
  - name: amount
    type: decimal(19,4)
    nullable: true
business_keys:
  - event_id
quality_rules:
  - name: valid_event_type
    expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
    action: drop
  - name: non_null_id
    expression: "event_id IS NOT NULL"
    action: fail
"""

spec = TableSpec(**yaml.safe_load(spec_yaml_valido))

print("Spec carregado com sucesso:")
print(f"  table_name: {spec.table_name}")
print(f"  source_table: {spec.source_table}")
print(f"  campos: {[f.name for f in spec.fields]}")
print(f"  business_keys: {spec.business_keys}")
print(f"  quality_rules: {[(r.name, r.action) for r in spec.quality_rules]}")

# COMMAND ----------

spec_yaml_invalido = """
table_name: tabela_invalida
quality_rules:
  - name: regra_ruim
    expression: "id IS NOT NULL"
    action: ignorar_tudo
"""

try:
    TableSpec(**yaml.safe_load(spec_yaml_invalido))
    print("ATENÇÃO: deveria ter falhado.")
except Exception as e:
    print("Pydantic detectou o erro de configuração na leitura:")
    print(str(e)[:400])

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Converter tipos YAML em StructType do Spark
# MAGIC
# MAGIC O projeto tem um módulo `spark_schema.py` que converte os tipos do YAML (strings como `"long"`, `"decimal(19,4)"`) em tipos Spark (`LongType()`, `DecimalType(19, 4)`).

# COMMAND ----------

import re
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, IntegerType,
    DateType, TimestampType, DoubleType, BooleanType, DecimalType
)


def yaml_type_to_spark(type_str: str):
    t = type_str.lower().strip()
    if t in ("string", "str"):
        return StringType()
    if t in ("long", "bigint"):
        return LongType()
    if t in ("int", "integer"):
        return IntegerType()
    if t in ("date",):
        return DateType()
    if t in ("timestamp",):
        return TimestampType()
    if t in ("double", "float"):
        return DoubleType()
    if t in ("boolean", "bool"):
        return BooleanType()
    match = re.match(r"decimal\((\d+),\s*(\d+)\)", t)
    if match:
        return DecimalType(int(match.group(1)), int(match.group(2)))
    raise ValueError(f"Tipo YAML desconhecido: {type_str!r}")


def build_spark_schema(fields: list[FieldSpec]) -> StructType:
    return StructType([
        StructField(f.name, yaml_type_to_spark(f.type), f.nullable)
        for f in fields
    ])


spark_schema = build_spark_schema(spec.fields)
print("StructType gerado a partir do YAML:")
spark_schema.printTreeString()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Herança por ambiente com ConfigLoader
# MAGIC
# MAGIC O projeto tem um arquivo base (`config/environments/base.yml`) e arquivos de override por ambiente (`dev.yml`, `acc.yml`, `prd.yml`). O `ConfigLoader` faz merge entre base e ambiente com uma política explícita: chaves do ambiente sobrescrevem chaves da base.

# COMMAND ----------

base_yml = """
catalog: main
environment: base
bronze_schema: sdp_bronze
silver_schema: sdp_silver
gold_schema: sdp_gold
generator:
  coalesce: 1
  file_format: csv
"""

dev_yml = """
catalog: main
environment: dev
bronze_schema: sdp_dev_bronze
silver_schema: sdp_dev_silver
gold_schema: sdp_dev_gold
"""

base_config = yaml.safe_load(base_yml)
dev_config = yaml.safe_load(dev_yml)

merged_config = {**base_config, **dev_config}

print("Configuração base:")
for k, v in base_config.items():
    print(f"  {k}: {v}")

print("\nOverride de dev:")
for k, v in dev_config.items():
    print(f"  {k}: {v}")

print("\nConfiguração final (merged):")
for k, v in merged_config.items():
    print(f"  {k}: {v}")

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** a chave `generator` veio do base (dev não a sobrescreveu). As chaves de schema foram substituídas pelos valores de dev. O merge garante que dev herda o que não foi explicitamente sobrescrito.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. O fluxo completo no projeto
# MAGIC
# MAGIC No projeto, o fluxo de configuração é:
# MAGIC
# MAGIC ```
# MAGIC config/environments/base.yml
# MAGIC        +
# MAGIC config/environments/dev.yml
# MAGIC        ↓ merge (ConfigLoader)
# MAGIC EnvironmentConfig (Pydantic)
# MAGIC        +
# MAGIC config/tables/bronze/fact_sales_events.yml
# MAGIC        ↓ carregamento (ConfigLoader)
# MAGIC TableSpec (Pydantic)
# MAGIC        ↓ build_spark_schema()
# MAGIC StructType
# MAGIC        ↓
# MAGIC BronzeIngestionService.read_stream(spec, path)
# MAGIC        ↓
# MAGIC DataFrame com schema tipado
# MAGIC ```
# MAGIC
# MAGIC Cada camada da pipeline usa o spec para:
# MAGIC - schema da tabela (bronze)
# MAGIC - regras de qualidade (silver)
# MAGIC - chaves de deduplicação (silver)
# MAGIC - nome da tabela destino (todas as camadas)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. O que você praticou
# MAGIC
# MAGIC - Entendeu por que configuração declarativa em YAML é preferível a valores hardcoded
# MAGIC - Criou modelos Pydantic para validar specs de tabela
# MAGIC - Viu como Pydantic detecta erros de configuração antes da execução
# MAGIC - Implementou a conversão de tipos YAML em StructType do Spark
# MAGIC - Entendeu o mecanismo de merge entre ambiente base e ambiente específico
# MAGIC - Viu o fluxo completo de config → Pydantic → StructType → Auto Loader

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Qual é a principal vantagem de colocar o schema de uma tabela em YAML em vez de hardcoded no código Python?
# MAGIC 2. O que acontece quando o Pydantic detecta um erro no YAML (ex: action inválido)?
# MAGIC 3. O projeto tem um YAML por tabela ou um único YAML para todas as tabelas?
# MAGIC 4. Como funciona a herança entre `base.yml` e `dev.yml`?
# MAGIC 5. Qual módulo do projeto converte strings como `"decimal(19,4)"` em `DecimalType(19, 4)` do Spark?
