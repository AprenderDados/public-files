# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 02
# MAGIC ## Auto Loader — Ingestão Incremental de Arquivos

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno demonstra o Auto Loader (cloudFiles): como ele detecta arquivos novos de forma incremental, como usar schema explícito, e como as colunas de metadados funcionam. Esses são os fundamentos da camada bronze do projeto.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O problema que o Auto Loader resolve
# MAGIC
# MAGIC Imagine que arquivos CSV chegam em um Volume do Unity Catalog ao longo do dia. Você precisa ingerir esses arquivos em uma tabela Delta de forma incremental — sem reprocessar o que já foi lido e sem perder arquivos novos.
# MAGIC
# MAGIC Três abordagens comuns:
# MAGIC
# MAGIC | Abordagem | Problema |
# MAGIC |---|---|
# MAGIC | `spark.read` simples | Lê tudo a cada execução, sem controle do que é novo |
# MAGIC | COPY INTO | Bom para cargas em lote, mas sem streaming nativo |
# MAGIC | **Auto Loader (cloudFiles)** | Rastreia arquivos processados, detecta novos, funciona em streaming |
# MAGIC
# MAGIC O Auto Loader usa um checkpoint interno para saber quais arquivos já foram lidos. Na próxima execução, só os novos arquivos são processados.
# MAGIC
# MAGIC No projeto, toda a camada bronze usa Auto Loader via o serviço `BronzeIngestionService`.

# COMMAND ----------

import json
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, DateType, LongType, TimestampType


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]

    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)

    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")

    raise RuntimeError(
        "Não foi possível criar ou reutilizar um Volume para este módulo.\n" + "\n".join(errors)
    )


CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_02_autoloader")
TARGET_SCHEMA = "sdp_curso_autoloader_lab"
LANDING_PATH = f"{BASE_PATH}/landing/vendas"
CHECKPOINT_PATH = f"{BASE_PATH}/checkpoints/vendas_bronze"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")
for table in ["vendas_bronze_demo", "vendas_bronze_schema_explicito"]:
    spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.{TARGET_SCHEMA}.{table}")

try:
    dbutils.fs.rm(LANDING_PATH, True)
    dbutils.fs.rm(CHECKPOINT_PATH, True)
except Exception:
    pass
dbutils.fs.mkdirs(LANDING_PATH)

setup_variables = {
    "CATALOG": CATALOG,
    "SCHEMA": SCHEMA,
    "TARGET_SCHEMA": TARGET_SCHEMA,
    "VOLUME": VOLUME,
    "BASE_PATH": BASE_PATH,
    "LANDING_PATH": LANDING_PATH,
    "CHECKPOINT_PATH": CHECKPOINT_PATH,
}

# COMMAND ----------

print("Variáveis principais do módulo:")
for k, v in setup_variables.items():
    print(f"- {k}: {v}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Criar arquivos CSV de exemplo
# MAGIC
# MAGIC Vamos simular a chegada de dois batches de vendas em arquivos CSV.

# COMMAND ----------

batch_01 = """sales_event_id,product_id,customer_id,quantity,amount,sales_date
1001,10,201,2,599.80,2024-04-01
1002,11,202,1,349.90,2024-04-01
1003,10,203,3,899.70,2024-04-02
"""

batch_02 = """sales_event_id,product_id,customer_id,quantity,amount,sales_date
1004,12,204,1,89.90,2024-04-03
1005,13,205,2,399.80,2024-04-03
"""

dbutils.fs.put(f"{LANDING_PATH}/batch_01.csv", batch_01, True)
print("Arquivo batch_01.csv depositado.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Ingestão com schema inferido
# MAGIC
# MAGIC O Auto Loader pode inferir o schema automaticamente. Isso é conveniente para exploração, mas **não é o padrão do projeto**. O projeto sempre usa schema explícito para garantir tipos corretos e capturar erros de origem.

# COMMAND ----------

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(LANDING_PATH)
    .writeStream
    .format("delta")
    .option("checkpointLocation", f"{CHECKPOINT_PATH}_inferido")
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_demo")
    .awaitTermination()
)

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_demo"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. As colunas de metadados `_metadata`
# MAGIC
# MAGIC O Auto Loader expõe informações sobre o arquivo de origem via a coluna especial `_metadata`. Essa coluna é um struct com campos como:
# MAGIC
# MAGIC - `_metadata.file_path` — caminho completo do arquivo
# MAGIC - `_metadata.file_name` — nome do arquivo
# MAGIC - `_metadata.file_modification_time` — timestamp de modificação do arquivo
# MAGIC - `_metadata.file_size` — tamanho em bytes
# MAGIC
# MAGIC No projeto, a camada bronze adiciona essas colunas como campos explícitos de rastreabilidade. Isso é feito no `BronzeIngestionService`.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT _metadata FROM sdp_curso_autoloader_lab.vendas_bronze_demo LIMIT 3

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Ingestão com schema explícito e colunas de metadados
# MAGIC
# MAGIC Este é o padrão real do projeto. O schema é definido explicitamente (via YAML no projeto, via StructType aqui), e as colunas de metadados são extraídas da coluna `_metadata` e adicionadas como campos de rastreabilidade.

# COMMAND ----------

CHECKPOINT_EXPLICITO = f"{CHECKPOINT_PATH}_explicito"
try:
    dbutils.fs.rm(CHECKPOINT_EXPLICITO, True)
except Exception:
    pass

schema_vendas = StructType([
    StructField("sales_event_id", LongType(), False),
    StructField("product_id", IntegerType(), False),
    StructField("customer_id", IntegerType(), False),
    StructField("quantity", IntegerType(), True),
    StructField("amount", DecimalType(19, 4), True),
    StructField("sales_date", DateType(), True),
])

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .schema(schema_vendas)
    .load(LANDING_PATH)
    .select(
        "sales_event_id",
        "product_id",
        "customer_id",
        "quantity",
        "amount",
        "sales_date",
        F.current_timestamp().alias("ingestion_ts"),
        F.col("_metadata.file_path").alias("source_file_path"),
        F.col("_metadata.file_modification_time").alias("source_file_modification_time"),
        F.col("_metadata.file_name").alias("source_file_name"),
        "_rescued_data",
    )
    .writeStream
    .format("delta")
    .option("checkpointLocation", CHECKPOINT_EXPLICITO)
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito")
    .awaitTermination()
)

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Simular chegada de um segundo arquivo — comportamento incremental
# MAGIC
# MAGIC O Auto Loader rastreia o que já foi processado pelo checkpoint. Quando um novo arquivo chega, somente ele é lido na próxima execução.

# COMMAND ----------

dbutils.fs.put(f"{LANDING_PATH}/batch_02.csv", batch_02, True)
print("Arquivo batch_02.csv depositado.")

# COMMAND ----------

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .schema(schema_vendas)
    .load(LANDING_PATH)
    .select(
        "sales_event_id", "product_id", "customer_id", "quantity", "amount", "sales_date",
        F.current_timestamp().alias("ingestion_ts"),
        F.col("_metadata.file_path").alias("source_file_path"),
        F.col("_metadata.file_modification_time").alias("source_file_modification_time"),
        F.col("_metadata.file_name").alias("source_file_name"),
        "_rescued_data",
    )
    .writeStream
    .format("delta")
    .option("checkpointLocation", CHECKPOINT_EXPLICITO)
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito")
    .awaitTermination()
)

display(
    spark.table(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito")
    .orderBy("source_file_name", "sales_event_id")
    .select("sales_event_id", "sales_date", "source_file_name", "ingestion_ts")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. A coluna `_rescued_data`
# MAGIC
# MAGIC Quando um valor não encaixa no schema explícito, ele não causa erro — é capturado na coluna `_rescued_data` como JSON.
# MAGIC
# MAGIC Isso é fundamental no projeto: a bronze aceita dados com problema e os rastreia. A silver descarta linhas onde `_rescued_data` é não-nulo.

# COMMAND ----------

batch_problematico = """sales_event_id,product_id,customer_id,quantity,amount,sales_date
1006,20,206,dois,VALOR_INVALIDO,2024-04-04
"""

try:
    dbutils.fs.rm(CHECKPOINT_EXPLICITO, True)
    dbutils.fs.rm(f"{LANDING_PATH}/batch_03.csv", True)
except Exception:
    pass

dbutils.fs.put(f"{LANDING_PATH}/batch_03.csv", batch_problematico, True)

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .schema(schema_vendas)
    .load(LANDING_PATH)
    .select(
        "sales_event_id", "product_id", "customer_id", "quantity", "amount", "sales_date",
        F.current_timestamp().alias("ingestion_ts"),
        F.col("_metadata.file_name").alias("source_file_name"),
        "_rescued_data",
    )
    .writeStream
    .format("delta")
    .option("checkpointLocation", CHECKPOINT_EXPLICITO)
    .trigger(availableNow=True)
    .toTable(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito")
    .awaitTermination()
)

display(
    spark.table(f"{CATALOG}.{TARGET_SCHEMA}.vendas_bronze_schema_explicito")
    .filter(F.col("_rescued_data").isNotNull())
    .select("sales_event_id", "quantity", "amount", "_rescued_data", "source_file_name")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Como o projeto usa o Auto Loader
# MAGIC
# MAGIC No projeto, o `BronzeIngestionService` encapsula toda essa lógica:
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/bronze/bronze_ingestion_service.py
# MAGIC class BronzeIngestionService:
# MAGIC     def read_stream(self, spec: TableSpec, data_path: str) -> DataFrame:
# MAGIC         spark_schema = build_spark_schema(spec.fields)
# MAGIC         return (
# MAGIC             spark.readStream
# MAGIC             .format("cloudFiles")
# MAGIC             .option("cloudFiles.format", spec.source_format)
# MAGIC             .option("header", "true")
# MAGIC             .schema(spark_schema)
# MAGIC             .load(data_path)
# MAGIC             .select(
# MAGIC                 *[col for col in spec.output_columns],
# MAGIC                 current_timestamp().alias("ingestion_ts"),
# MAGIC                 col("_metadata.file_path").alias("source_file_path"),
# MAGIC                 col("_metadata.file_modification_time").alias("source_file_modification_time"),
# MAGIC                 col("_metadata.file_name").alias("source_file_name"),
# MAGIC                 "_rescued_data",
# MAGIC             )
# MAGIC         )
# MAGIC ```
# MAGIC
# MAGIC O schema vem do YAML. As colunas de metadados são adicionadas sempre. O caminho vem do `ResolvedProjectContext`. Tudo isso declarativo — o notebook de pipeline só chama `service.read_stream(spec, path)`.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. O que você praticou
# MAGIC
# MAGIC - Criou arquivos CSV em um Volume do Unity Catalog
# MAGIC - Usou Auto Loader com schema inferido e schema explícito
# MAGIC - Extraiu colunas de metadados (`_metadata.file_path`, `file_name`, `file_modification_time`)
# MAGIC - Observou o comportamento incremental: somente novos arquivos são processados
# MAGIC - Viu a coluna `_rescued_data` capturando valores inválidos sem quebrar a ingestão
# MAGIC - Entendeu como o projeto encapsula esse padrão no `BronzeIngestionService`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Qual é a diferença prática entre usar `spark.read` e `spark.readStream` com o Auto Loader?
# MAGIC 2. Por que o projeto usa schema explícito em vez de inferência automática?
# MAGIC 3. O que acontece com um valor que não encaixa no schema explícito? Como o Auto Loader lida com isso?
# MAGIC 4. Onde o Auto Loader armazena o registro de quais arquivos já foram processados?
# MAGIC 5. Quais são as 5 colunas de rastreabilidade que a camada bronze do projeto adiciona a cada registro?
