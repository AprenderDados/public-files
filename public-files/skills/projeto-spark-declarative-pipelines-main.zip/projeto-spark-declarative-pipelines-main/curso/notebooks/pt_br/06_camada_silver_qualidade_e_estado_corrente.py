# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 06
# MAGIC ## Camada Silver — Qualidade e Estado Corrente

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno explica os dois padrões centrais da camada silver do projeto: current-state de dimensões (publicar apenas o último batch completo) e limpeza de fatos (normalização, filtragem de rescued data, deduplicação com window functions). Você vai ver os padrões com dados simples antes de conectar com o código real.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O que a silver resolve
# MAGIC
# MAGIC A camada bronze recebe e preserva tudo — inclusive dados com problemas. A silver existe para publicar dados confiáveis e normalizados que as camadas downstream possam consumir com segurança.
# MAGIC
# MAGIC A silver aplica três tipos de transformação:
# MAGIC
# MAGIC 1. **Qualidade** — descarta linhas com `_rescued_data` não-nulo e aplica expectations declaradas
# MAGIC 2. **Normalização** — padroniza valores (maiúsculas, trim, arredondamento de decimais)
# MAGIC 3. **Deduplicação** — elimina duplicatas por chave de negócio, com critério de desempate determinístico
# MAGIC
# MAGIC Para dimensões, a silver também implementa o **current-state pattern**: publica apenas o batch mais recente, descartando o histórico de batches anteriores.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import Window


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)
    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")
    raise RuntimeError("Não foi possível criar Volume.\n" + "\n".join(errors))


CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_06_silver")
TARGET_SCHEMA = "sdp_curso_silver_lab"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")

print(f"CATALOG: {CATALOG}, TARGET_SCHEMA: {TARGET_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Current-state pattern para dimensões
# MAGIC
# MAGIC A bronze acumula todos os batches de dimensão como append-only. Cada batch é um snapshot completo da dimensão com um `extract_batch_id` e um `extract_ts`.
# MAGIC
# MAGIC A silver não quer o histórico de batches — ela quer apenas o estado mais recente. A lógica é:
# MAGIC
# MAGIC 1. Encontrar qual é o batch com o maior `extract_ts`
# MAGIC 2. Filtrar apenas as linhas desse batch
# MAGIC
# MAGIC Isso naturalmente representa deleções: se uma chave desapareceu do último batch, ela não aparece na silver.

# COMMAND ----------

dim_bronze_data = [
    (1, "Mountain Bike 500", "B", "2024-04-01T10:00:00", "batch_20240401"),
    (2, "Capacete Trail", "A", "2024-04-01T10:00:00", "batch_20240401"),
    (3, "Luva Ciclismo M", "A", "2024-04-01T10:00:00", "batch_20240401"),
    (1, "Mountain Bike 500 Pro", "B", "2024-04-08T10:00:00", "batch_20240408"),
    (2, "Capacete Trail Pro", "A", "2024-04-08T10:00:00", "batch_20240408"),
]

dim_bronze_df = spark.createDataFrame(
    dim_bronze_data,
    "product_id INT, name STRING, grade STRING, extract_ts STRING, extract_batch_id STRING"
).withColumn("extract_ts", F.to_timestamp("extract_ts"))

print("Bronze acumulada (todos os batches):")
display(dim_bronze_df.orderBy("extract_batch_id", "product_id"))

# COMMAND ----------

def get_current_batch(df):
    latest_batch = (
        df.groupBy("extract_batch_id")
        .agg(F.max("extract_ts").alias("batch_ts"))
        .orderBy(F.col("batch_ts").desc())
        .first()["extract_batch_id"]
    )
    return df.filter(F.col("extract_batch_id") == latest_batch)


dim_silver_df = get_current_batch(dim_bronze_df)

print("Silver: apenas o batch mais recente")
display(dim_silver_df.orderBy("product_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:**
# MAGIC - O produto 3 (`Luva Ciclismo M`) não aparece na silver porque foi removido do último batch
# MAGIC - O produto 1 tem o nome atualizado (`Mountain Bike 500 Pro`) — o estado corrente reflete a mudança
# MAGIC
# MAGIC Sem SCD2. Sem marcadores de deleção. Só o último estado importa.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Deduplicação com window functions
# MAGIC
# MAGIC Fatos podem chegar duplicados por várias razões: reenvio do arquivo, reprocessamento, falha de idempotência no gerador. A silver elimina essas duplicatas por chave de negócio, mantendo a ocorrência mais recente.

# COMMAND ----------

fatos_com_duplicatas = spark.createDataFrame(
    [
        ("E001", "O001", "SALE", "2024-04-01", 2, 599.80, "2024-04-01T10:00:00", "batch_01"),
        ("E001", "O001", "SALE", "2024-04-01", 2, 599.80, "2024-04-01T10:05:00", "batch_01"),
        ("E002", "O001", "SALE", "2024-04-01", 1, 349.90, "2024-04-01T10:00:00", "batch_01"),
        ("E003", "O002", "ADJUSTMENT", "2024-04-02", -1, -299.90, "2024-04-02T09:00:00", "batch_02"),
        ("E003", "O002", "ADJUSTMENT", "2024-04-02", -1, -299.90, "2024-04-02T09:00:00", "batch_02"),
    ],
    "event_id STRING, order_id STRING, event_type STRING, event_date STRING, quantity INT, amount DOUBLE, extract_ts STRING, batch_id STRING"
).withColumn("extract_ts", F.to_timestamp("extract_ts"))

print("Fatos com duplicatas:")
display(fatos_com_duplicatas.orderBy("event_id", "extract_ts"))

# COMMAND ----------

def deduplicate_facts(df, business_keys: list[str]):
    window = Window.partitionBy(*business_keys).orderBy(F.col("extract_ts").desc())
    return (
        df.withColumn("_rn", F.row_number().over(window))
        .filter(F.col("_rn") == 1)
        .drop("_rn")
    )


fatos_deduplicados = deduplicate_facts(fatos_com_duplicatas, ["event_id"])

print("Fatos deduplicados (mantém a ocorrência mais recente por event_id):")
display(fatos_deduplicados.orderBy("event_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Filtragem de rescued data e normalização
# MAGIC
# MAGIC Antes de deduplicar, a silver descarta linhas com `_rescued_data` não-nulo e normaliza valores como texto (maiúsculas, trim) e decimais (arredondamento).

# COMMAND ----------

fatos_com_problemas = spark.createDataFrame(
    [
        ("E010", "SALE", "usd", 2, 599.80, None),
        ("E011", "adjustment", " USD ", 1, 349.9012345, None),
        ("E012", "CANCEL", "USD", -1, -299.90, '{"amount": "texto"}'),
    ],
    "event_id STRING, event_type STRING, currency STRING, quantity INT, amount DOUBLE, _rescued_data STRING"
)

print("Antes da silver (com problemas):")
display(fatos_com_problemas)

# COMMAND ----------

def apply_silver_normalization(df):
    return (
        df.filter(F.col("_rescued_data").isNull())
        .withColumn("event_type", F.upper(F.trim("event_type")))
        .withColumn("currency", F.upper(F.trim("currency")))
        .withColumn("amount", F.round("amount", 2))
        .drop("_rescued_data")
    )


fatos_silver = apply_silver_normalization(fatos_com_problemas)

print("Após a silver (normalizado, sem rescued data):")
display(fatos_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Como o projeto implementa esses padrões
# MAGIC
# MAGIC **Para dimensões:**
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/silver/silver_support.py
# MAGIC class LatestFullLoadSelector:
# MAGIC     def current_batch(self, df: DataFrame) -> DataFrame:
# MAGIC         latest = self.latest_batch(df)
# MAGIC         return df.filter(col("extract_batch_id") == latest)
# MAGIC
# MAGIC     def latest_batch(self, df: DataFrame) -> str:
# MAGIC         return (
# MAGIC             df.groupBy("extract_batch_id")
# MAGIC             .agg(max("extract_ts").alias("ts"))
# MAGIC             .orderBy(col("ts").desc())
# MAGIC             .first()["extract_batch_id"]
# MAGIC         )
# MAGIC ```
# MAGIC
# MAGIC **Para fatos:**
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/silver/sales_event_builder.py
# MAGIC class SalesEventSilverBuilder:
# MAGIC     def build(self, bronze_df: DataFrame) -> DataFrame:
# MAGIC         return (
# MAGIC             bronze_df
# MAGIC             .filter(col("_rescued_data").isNull())
# MAGIC             .withColumn("event_type", upper(trim(col("event_type"))))
# MAGIC             .withColumn("currency_code", upper(trim(col("currency_code"))))
# MAGIC             .withColumn("amount_delta", round(col("amount_delta"), 4))
# MAGIC             .transform(self._deduplicate)
# MAGIC             .select(*self.spec.output_columns)
# MAGIC         )
# MAGIC ```
# MAGIC
# MAGIC As chaves de deduplicação (`business_keys`) vêm do YAML do spec de tabela.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Tabela de decisão — bronze vs silver
# MAGIC
# MAGIC | Responsabilidade | Bronze | Silver |
# MAGIC |---|---|---|
# MAGIC | Lê arquivos com Auto Loader | ✓ | ✗ |
# MAGIC | Schema explícito | ✓ | — |
# MAGIC | Colunas de rastreabilidade | ✓ | preserva |
# MAGIC | `_rescued_data` | ✓ (captura) | ✓ (filtra) |
# MAGIC | Normalização (upper, trim) | ✗ | ✓ |
# MAGIC | Expectations de qualidade | ✗ | ✓ |
# MAGIC | Deduplicação | ✗ | ✓ |
# MAGIC | Current-state de dimensões | ✗ | ✓ |

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. O que você praticou
# MAGIC
# MAGIC - Implementou o current-state pattern para dimensões com `extract_batch_id`
# MAGIC - Implementou deduplicação com window functions (`row_number()`)
# MAGIC - Filtrou `_rescued_data` e normalizou valores
# MAGIC - Entendeu a separação de responsabilidades entre bronze e silver
# MAGIC - Viu como o projeto implementa esses padrões em `silver_support.py` e `sales_event_builder.py`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Perguntas de checkpoint
# MAGIC
# MAGIC 1. O que é o "current-state pattern" para dimensões? Como ele representa deleções?
# MAGIC 2. Por que a bronze acumula batches como append-only enquanto a silver publica apenas o último?
# MAGIC 3. Como a deduplicação com window functions garante que a versão mais recente de um registro é mantida?
# MAGIC 4. O que acontece com uma linha que tem `_rescued_data` não-nulo na silver?
# MAGIC 5. Quais são as três etapas que a silver aplica sobre os fatos (na ordem correta)?
