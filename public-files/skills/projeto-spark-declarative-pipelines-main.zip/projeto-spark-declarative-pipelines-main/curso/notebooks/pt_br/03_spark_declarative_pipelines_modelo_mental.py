# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 03
# MAGIC ## Spark Declarative Pipelines — Modelo Mental

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno apresenta o modelo mental das Spark Declarative Pipelines: o que são streaming tables e materialized views, como os decorators funcionam, o que é o pipeline graph, e como esse modelo aparece no projeto real. Você vai criar e executar uma pipeline simples com três camadas.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O que é uma pipeline declarativa?
# MAGIC
# MAGIC Uma pipeline imperativa diz **como** fazer: "leia esse arquivo, filtre essas linhas, grave nessa tabela, chame esse notebook".
# MAGIC
# MAGIC Uma pipeline declarativa diz **o que** você quer: "este ativo depende daquele, tem essa regra de qualidade, é atualizado de forma incremental".
# MAGIC
# MAGIC A Databricks implementa isso como **Spark Declarative Pipelines** (anteriormente Delta Live Tables). A vantagem:
# MAGIC
# MAGIC - dependências são explícitas — o sistema monta o grafo e executa na ordem correta
# MAGIC - qualidade é parte da definição do ativo, não um passo separado
# MAGIC - comportamento incremental é declarado, não implementado manualmente
# MAGIC - observabilidade nativa via event log e pipeline graph

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Os dois tipos principais de ativo
# MAGIC
# MAGIC ### Streaming Table (`@dp.table`)
# MAGIC
# MAGIC Representa uma tabela que recebe dados de forma incremental ou em streaming. Cada execução da pipeline processa apenas os dados novos desde a última execução.
# MAGIC
# MAGIC Use quando:
# MAGIC - o dado chega continuamente (Auto Loader, Kafka, etc.)
# MAGIC - você quer processamento incremental eficiente
# MAGIC - a tabela acumula dados ao longo do tempo (append-only ou com CDC)
# MAGIC
# MAGIC ### Materialized View (`@dp.materialized_view`)
# MAGIC
# MAGIC Representa um resultado derivado materializado. Na execução, a view é recalculada a partir das tabelas fonte.
# MAGIC
# MAGIC Use quando:
# MAGIC - o resultado é uma agregação ou join
# MAGIC - o dado precisa estar disponível sem recalcular ad hoc
# MAGIC - a lógica é mais "qual é o estado atual" do que "quais novos dados chegaram"
# MAGIC
# MAGIC No projeto:
# MAGIC - Tabelas bronze e silver (fatos): `@dp.table` (streaming, incremental)
# MAGIC - Dimensões silver (current-state): `@dp.table` com semântica de estado corrente
# MAGIC - Tabelas gold (agregações e OBT): `@dp.materialized_view`

# COMMAND ----------

import json
import time
import re
import requests
from pathlib import Path, PurePosixPath


def option_get(option_like):
    try:
        return option_like.get()
    except Exception:
        try:
            return option_like.getOrElse(None)
        except Exception:
            return None


def notebook_context():
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    api_url = option_get(ctx.apiUrl())
    if not api_url:
        host = option_get(ctx.browserHostName())
        if host:
            api_url = f"https://{host}"
    token = option_get(ctx.apiToken())
    notebook_path = option_get(ctx.notebookPath())
    user_name = option_get(ctx.userName()) or spark.sql("SELECT current_user()").first()[0]
    if not api_url or not token or not notebook_path:
        raise RuntimeError("Não foi possível resolver contexto do notebook.")
    return {"api_url": api_url.rstrip("/"), "token": token, "notebook_path": notebook_path, "user_name": user_name}


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)
    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")
    raise RuntimeError("Não foi possível criar ou reutilizar um Volume.\n" + "\n".join(errors))


def api_call(api_url, token, method, path, payload=None, params=None):
    response = requests.request(
        method=method,
        url=f"{api_url}{path}",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload, params=params, timeout=120,
    )
    if response.status_code >= 400:
        raise RuntimeError(f"Erro na API {method} {path}: {response.status_code} {response.text[:1200]}")
    return {} if not response.text else response.json()


def sanitize_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]+", "_", value).strip("_").lower()


def delete_pipeline_if_exists(api_url, token, pipeline_name):
    existing = api_call(api_url, token, "GET", "/api/2.0/pipelines")
    pipelines = existing if isinstance(existing, list) else existing.get("statuses", [])
    for p in pipelines:
        if p.get("name") == pipeline_name:
            api_call(api_url, token, "DELETE", f"/api/2.0/pipelines/{p['pipeline_id']}")
            time.sleep(5)


def create_pipeline(api_url, token, payload):
    return api_call(api_url, token, "POST", "/api/2.0/pipelines", payload)["pipeline_id"]


def run_pipeline(api_url, token, pipeline_id, validate_only=False):
    resp = api_call(api_url, token, "POST", f"/api/2.0/pipelines/{pipeline_id}/updates", {"cause": "USER_ACTION", "validate_only": validate_only})
    update_id = resp["update_id"]
    started = time.time()
    while True:
        result = api_call(api_url, token, "GET", f"/api/2.0/pipelines/{pipeline_id}/updates/{update_id}")
        update = result.get("update", result)
        state = update.get("state", "UNKNOWN")
        if state in {"COMPLETED", "CANCELED", "FAILED"}:
            return state
        if (time.time() - started) > 1800:
            raise TimeoutError("Timeout aguardando pipeline.")
        time.sleep(15)


CTX = notebook_context()
API_URL = CTX["api_url"]
API_TOKEN = CTX["token"]
NOTEBOOK_PATH = CTX["notebook_path"]
CURRENT_USER = CTX["user_name"]
USER_SLUG = sanitize_name(CURRENT_USER.split("@")[0])

CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_03_sdp")
TARGET_SCHEMA = "sdp_curso_sdp_lab"
EVENT_LOG_TABLE = "sdp_curso_sdp_event_log"
PIPELINE_NAME = f"SDP Curso Topico 03 - {USER_SLUG}"
RAW_PATH = f"{BASE_PATH}/raw/pedidos"

NOTEBOOK_DIR_WORKSPACE = PurePosixPath(NOTEBOOK_PATH).parent
NOTEBOOK_DIR_LOCAL = Path("/Workspace") / str(NOTEBOOK_DIR_WORKSPACE).lstrip("/")
PROJECT_DIR_LOCAL = NOTEBOOK_DIR_LOCAL / "03_sdp_projeto"
PROJECT_DIR_LOCAL.mkdir(parents=True, exist_ok=True)

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")
for table in [EVENT_LOG_TABLE, "bronze_pedidos", "silver_pedidos", "gold_resumo_diario"]:
    spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.{TARGET_SCHEMA}.{table}")

try:
    dbutils.fs.rm(RAW_PATH, True)
except Exception:
    pass
dbutils.fs.mkdirs(RAW_PATH)

PIPELINE_SOURCE_LOCAL = PROJECT_DIR_LOCAL / "pedidos_pipeline.py"
PIPELINE_SOURCE_WORKSPACE = PIPELINE_SOURCE_LOCAL.as_posix()

setup_variables = {
    "CATALOG": CATALOG, "SCHEMA": SCHEMA, "TARGET_SCHEMA": TARGET_SCHEMA,
    "VOLUME": VOLUME, "BASE_PATH": BASE_PATH, "RAW_PATH": RAW_PATH,
    "PIPELINE_NAME": PIPELINE_NAME, "PIPELINE_SOURCE_WORKSPACE": PIPELINE_SOURCE_WORKSPACE,
}

# COMMAND ----------

print("Variáveis principais do módulo:")
for k, v in setup_variables.items():
    print(f"- {k}: {v}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Criar dados de exemplo

# COMMAND ----------

pedidos_batch_01 = """pedido_id,cliente_id,data_pedido,valor,status
101,C001,2024-04-01,250.00,pago
102,C002,2024-04-01,180.00,criado
103,C001,2024-04-02,95.50,pago
104,C003,2024-04-02,-30.00,pago
105,C004,2024-04-03,410.00,cancelado
"""

dbutils.fs.put(f"{RAW_PATH}/pedidos_01.csv", pedidos_batch_01, True)
display(spark.read.option("header", "true").csv(RAW_PATH))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Escrever o código da pipeline
# MAGIC
# MAGIC Aqui está o ponto central do tópico: o código da pipeline **declara ativos**, não executa passos.
# MAGIC
# MAGIC - `@dp.table` declara uma streaming table — a pipeline cuida do checkpoint e do processamento incremental
# MAGIC - `@dp.expect_or_drop` declara uma regra de qualidade — linhas inválidas são descartadas automaticamente
# MAGIC - `@dp.materialized_view` declara um resultado materializado — a pipeline recalcula quando necessário
# MAGIC
# MAGIC Você não escreve `for loop`, não gerencia checkpoint, não chama `writeStream.start()`. Você **descreve** o que quer.

# COMMAND ----------

pipeline_code = f"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

source = spark.conf.get("source")


@dp.table(
    name="bronze_pedidos",
    comment="Pedidos brutos ingeridos com Auto Loader.",
    table_properties={{"quality": "bronze", "pipelines.reset.allowed": "false"}},
)
def bronze_pedidos():
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("header", "true")
        .schema("pedido_id LONG, cliente_id STRING, data_pedido STRING, valor DOUBLE, status STRING")
        .load(f"{{source}}/pedidos")
        .select(
            "pedido_id", "cliente_id",
            F.to_date("data_pedido").alias("data_pedido"),
            "valor", F.upper("status").alias("status"),
            F.current_timestamp().alias("ingestion_ts"),
            F.col("_metadata.file_name").alias("source_file"),
        )
    )


@dp.table(
    name="silver_pedidos",
    comment="Pedidos limpos com valor válido e status conhecido.",
    table_properties={{"quality": "silver"}},
)
@dp.expect_or_drop("valor_positivo", "valor > 0")
@dp.expect_or_drop("status_valido", "status IN ('PAGO', 'CRIADO', 'CANCELADO')")
def silver_pedidos():
    return spark.readStream.table("bronze_pedidos")


@dp.materialized_view(
    name="gold_resumo_diario",
    comment="Receita e contagem de pedidos por dia.",
    table_properties={{"quality": "gold"}},
)
def gold_resumo_diario():
    return (
        spark.read.table("silver_pedidos")
        .groupBy("data_pedido")
        .agg(
            F.count("*").alias("total_pedidos"),
            F.sum("valor").alias("receita_bruta"),
            F.round(F.avg("valor"), 2).alias("ticket_medio"),
        )
        .orderBy("data_pedido")
    )
""".strip()

PIPELINE_SOURCE_LOCAL.write_text(pipeline_code, encoding="utf-8")
print("Arquivo da pipeline criado.")
print(PIPELINE_SOURCE_WORKSPACE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Criar a pipeline por API
# MAGIC
# MAGIC A pipeline é um objeto gerenciado no workspace. Você a cria uma vez e a dispara quantas vezes quiser — cada execução processa apenas o que é novo (para streaming tables) ou recalcula (para materialized views).

# COMMAND ----------

pipeline_payload = {
    "pipeline_type": "WORKSPACE",
    "name": PIPELINE_NAME,
    "root_path": PROJECT_DIR_LOCAL.as_posix(),
    "catalog": CATALOG,
    "target": TARGET_SCHEMA,
    "serverless": True,
    "development": True,
    "continuous": False,
    "channel": "CURRENT",
    "photon": True,
    "libraries": [{"glob": {"include": f"{PROJECT_DIR_LOCAL.as_posix()}/**"}}],
    "configuration": {"source": BASE_PATH},
    "event_log": {"catalog": CATALOG, "schema": TARGET_SCHEMA, "name": EVENT_LOG_TABLE},
}

delete_pipeline_if_exists(API_URL, API_TOKEN, PIPELINE_NAME)
PIPELINE_ID = create_pipeline(API_URL, API_TOKEN, pipeline_payload)
PIPELINE_URL = f"{API_URL}/pipelines/{PIPELINE_ID}"
print("Pipeline criada:", PIPELINE_URL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Executar e observar

# COMMAND ----------

estado = run_pipeline(API_URL, API_TOKEN, PIPELINE_ID)
print("Estado final:", estado)

# COMMAND ----------

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.bronze_pedidos"))

# COMMAND ----------

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.silver_pedidos"))

# COMMAND ----------

display(spark.table(f"{CATALOG}.{TARGET_SCHEMA}.gold_resumo_diario"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. O pipeline graph
# MAGIC
# MAGIC Na UI do Databricks, ao abrir a pipeline, você vê o **pipeline graph**: um diagrama que mostra os ativos e suas dependências.
# MAGIC
# MAGIC No exemplo acima:
# MAGIC ```
# MAGIC bronze_pedidos → silver_pedidos → gold_resumo_diario
# MAGIC ```
# MAGIC
# MAGIC O graph também mostra:
# MAGIC - quantas linhas foram processadas por ativo
# MAGIC - quantas linhas foram descartadas por cada expectation
# MAGIC - erros de execução por ativo
# MAGIC - tempo de execução
# MAGIC
# MAGIC No projeto real, o graph mostra 27 ativos: 14 na bronze, 14 na silver e 7 na gold. A pipeline cuida de executar tudo na ordem correta.
# MAGIC
# MAGIC Abra a pipeline no link acima para visualizar.

# COMMAND ----------

print("Pipeline para inspeção:", PIPELINE_URL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Como o projeto usa essa estrutura
# MAGIC
# MAGIC No projeto, os arquivos de pipeline ficam em `src/course_lakeflow/pipelines/`:
# MAGIC
# MAGIC - `bronze_dimensions.py` — 13 dimensões bronze
# MAGIC - `bronze_facts.py` — 1 fato bronze
# MAGIC - `silver_dimensions.py` — 13 dimensões silver (current-state)
# MAGIC - `silver_facts.py` — 1 fato silver com expectations
# MAGIC - `gold_metrics.py` — 2 dimensões conformadas + 1 OBT + 4 métricas
# MAGIC
# MAGIC Cada arquivo importa serviços de `common/`, `bronze/`, `silver/` e `gold/`. Os serviços contêm a lógica; os arquivos de pipeline declaram os ativos.
# MAGIC
# MAGIC Exemplo real de uma dimensão bronze do projeto:
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/pipelines/bronze_dimensions.py
# MAGIC @dp.table(name=spec.table_name, ...)
# MAGIC def bronze_production_product_full_raw():
# MAGIC     return ingestion_service.read_stream(spec, context.data_path("dimensions", "production_product"))
# MAGIC ```
# MAGIC
# MAGIC O `spec` vem do YAML. O `context` resolve o caminho físico. A função declara o ativo.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. O que você praticou
# MAGIC
# MAGIC - Entendeu a diferença entre streaming table e materialized view
# MAGIC - Escreveu código declarativo com `@dp.table` e `@dp.materialized_view`
# MAGIC - Aplicou uma expectation com `@dp.expect_or_drop`
# MAGIC - Criou e executou uma pipeline de três camadas por API
# MAGIC - Observou o pipeline graph na UI
# MAGIC - Entendeu como o projeto organiza as definições de pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Qual é a diferença entre uma streaming table e uma materialized view em uma pipeline declarativa?
# MAGIC 2. Quando você usa `@dp.table` vs `@dp.materialized_view`?
# MAGIC 3. O que o pipeline graph mostra que uma sequência de notebooks não mostraria?
# MAGIC 4. O que acontece com linhas que violam uma regra `@dp.expect_or_drop`?
# MAGIC 5. Por que os arquivos de pipeline do projeto (`bronze_dimensions.py`, `silver_facts.py`, etc.) não contêm a lógica de transformação diretamente?
