# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 09
# MAGIC ## Unity Catalog — Volumes e Schemas

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno apresenta os conceitos centrais do Unity Catalog relevantes para o projeto: o namespace de três níveis (catalog.schema.table), Volumes como storage gerenciado, caminhos de Volume (/Volumes/...), criação programática de schemas e volumes, e como o projeto lida com compatibilidade com workspaces free-tier.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O namespace de três níveis
# MAGIC
# MAGIC O Unity Catalog organiza todos os objetos em um namespace hierárquico de três níveis:
# MAGIC
# MAGIC ```
# MAGIC catalog
# MAGIC   └── schema (também chamado de "database")
# MAGIC         └── table / view / volume / function
# MAGIC ```
# MAGIC
# MAGIC Para referenciar uma tabela: `catalog.schema.tabela`
# MAGIC
# MAGIC Para referenciar um volume: `catalog.schema.volume`
# MAGIC
# MAGIC Para acessar arquivos dentro de um volume: `/Volumes/catalog/schema/volume/caminho/arquivo.csv`
# MAGIC
# MAGIC No projeto, cada camada tem seu próprio schema. Exemplo em ambiente dev:
# MAGIC
# MAGIC | Camada | Schema | Exemplo de tabela |
# MAGIC |---|---|---|
# MAGIC | Bronze | `sdp_dev_bronze` | `main.sdp_dev_bronze.bronze_fact_sales_events_raw` |
# MAGIC | Silver | `sdp_dev_silver` | `main.sdp_dev_silver.silver_fact_sales_events_clean` |
# MAGIC | Gold | `sdp_dev_gold` | `main.sdp_dev_gold.gold_daily_sales` |
# MAGIC | Ops (gerador) | `sdp_dev_ops` | `main.sdp_dev_ops.generation_state` |

# COMMAND ----------

from pyspark.sql import functions as F


current_catalog = spark.sql("SELECT current_catalog()").first()[0]
current_schema = spark.sql("SELECT current_schema()").first()[0]
current_user = spark.sql("SELECT current_user()").first()[0]

print(f"Catálogo atual: {current_catalog}")
print(f"Schema atual: {current_schema}")
print(f"Usuário atual: {current_user}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Criar schemas programaticamente
# MAGIC
# MAGIC No projeto, o `WorkspaceBootstrapService` cria todos os schemas necessários antes de qualquer execução da pipeline. O setup é idempotente — `IF NOT EXISTS` garante que rodar duas vezes não causa erros.

# COMMAND ----------

DEMO_CATALOG = current_catalog
DEMO_SCHEMA_BASE = "sdp_uc_lab"

schemas_para_criar = [
    f"{DEMO_CATALOG}.{DEMO_SCHEMA_BASE}_bronze",
    f"{DEMO_CATALOG}.{DEMO_SCHEMA_BASE}_silver",
    f"{DEMO_CATALOG}.{DEMO_SCHEMA_BASE}_gold",
]

for schema_fqn in schemas_para_criar:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_fqn}")
    print(f"Schema criado (ou já existia): {schema_fqn}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. O que são Volumes?
# MAGIC
# MAGIC Volumes são objetos do Unity Catalog para armazenamento de arquivos — não de tabelas Delta. Eles funcionam como uma "pasta gerenciada" dentro do namespace do UC.
# MAGIC
# MAGIC | | Tabelas Delta | Volumes |
# MAGIC |---|---|---|
# MAGIC | Tipo de conteúdo | Dados estruturados | Arquivos (CSV, JSON, Parquet, etc.) |
# MAGIC | Acesso | SQL, DataFrame, DLT | Caminho /Volumes/... |
# MAGIC | Governança | Unity Catalog | Unity Catalog |
# MAGIC | Casos de uso | bronze, silver, gold | landing zone, arquivos de config, artefatos |
# MAGIC
# MAGIC No projeto, os Volumes são usados como **landing zone**: o gerador deposita arquivos CSV ali, e o Auto Loader os lê da pipeline.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Criar volumes programaticamente

# COMMAND ----------

DEMO_SCHEMA_COMMON = f"{DEMO_CATALOG}.{DEMO_SCHEMA_BASE}_bronze"

volumes_para_criar = ["raw_data", "checkpoints", "generator_output"]

for volume_name in volumes_para_criar:
    try:
        spark.sql(f"CREATE VOLUME IF NOT EXISTS {DEMO_SCHEMA_COMMON}.{volume_name}")
        print(f"Volume criado: {DEMO_SCHEMA_COMMON}.{volume_name}")
    except Exception as e:
        print(f"Não foi possível criar {volume_name}: {str(e).splitlines()[0]}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Caminhos de Volume — /Volumes/catalog/schema/volume/...
# MAGIC
# MAGIC Uma vez criado um volume, seus arquivos são acessados via caminho `/Volumes/{catalog}/{schema}/{volume}/{subdir}/{arquivo}`.
# MAGIC
# MAGIC Esse caminho funciona em qualquer lugar que aceite caminhos de arquivo no Databricks: `dbutils.fs`, `spark.read`, `spark.readStream`, `dbutils.fs.put`, etc.

# COMMAND ----------

volume_path = f"/Volumes/{DEMO_SCHEMA_COMMON.replace('.', '/')}/raw_data"
demo_subdir = f"{volume_path}/demo_uploads"

try:
    dbutils.fs.mkdirs(demo_subdir)
    print(f"Diretório criado: {demo_subdir}")

    conteudo_csv = "id,nome,valor\n1,Produto A,100.00\n2,Produto B,200.00\n"
    dbutils.fs.put(f"{demo_subdir}/demo.csv", conteudo_csv, True)
    print(f"Arquivo criado: {demo_subdir}/demo.csv")

    df = spark.read.option("header", "true").csv(demo_subdir)
    display(df)
except Exception as e:
    print(f"Erro ao usar o volume: {str(e).splitlines()[0]}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Compatibilidade com workspaces free-tier
# MAGIC
# MAGIC No Databricks free-tier, alguns catálogos e schemas não podem ser criados da mesma forma que em um workspace enterprise. O projeto usa uma estratégia de fallback:
# MAGIC
# MAGIC - Tenta criar o volume no catálogo e schema atual
# MAGIC - Se falhar, tenta catálogos alternativos (`workspace`, `main`)
# MAGIC - Se falhar novamente, tenta schemas alternativos (`aprender_dados`, `default`)
# MAGIC
# MAGIC Em ambientes free-tier, o projeto também usa **isolamento por schema**: em vez de catálogos separados para cada ambiente, usa prefixos de schema como `sdp_dev_bronze`, `sdp_acc_bronze`.

# COMMAND ----------

def ensure_volume_with_fallback(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]

    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)

    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            path = f"/Volumes/{catalog}/{schema}/{volume}"
            print(f"Volume disponível em: {catalog}.{schema}.{volume}")
            print(f"Caminho: {path}")
            return catalog, schema, volume, path
        except Exception as exc:
            errors.append(f"  - {catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")

    raise RuntimeError("Não foi possível criar o volume:\n" + "\n".join(errors))


cat, schema, vol, path = ensure_volume_with_fallback("sdp_uc_demo_fallback")
print(f"\nVariáveis resolvidas: CATALOG={cat}, SCHEMA={schema}, VOLUME={vol}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Como o projeto usa o Unity Catalog
# MAGIC
# MAGIC O `ResolvedProjectContext` é a classe central para resolução de caminhos e nomes no projeto:
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/common/runtime_context.py
# MAGIC class ResolvedProjectContext:
# MAGIC     def table_fqn(self, layer: str, table_name: str) -> str:
# MAGIC         return f"{self.catalog}.{self.schema_name(layer)}.{table_name}"
# MAGIC
# MAGIC     def volume_path(self, volume_logical: str) -> str:
# MAGIC         volume_name = self.volumes_map[volume_logical]
# MAGIC         return f"/Volumes/{self.catalog}/{self.schema_name('ops')}/{volume_name}"
# MAGIC
# MAGIC     def data_path(self, subdir: str, logical_name: str) -> str:
# MAGIC         base = self.volume_path("raw_data")
# MAGIC         return f"{base}/{subdir}/{logical_name}"
# MAGIC ```
# MAGIC
# MAGIC Isso garante que o código das pipelines nunca hardcoda caminhos — ele consulta o contexto resolvido em runtime baseado nas configurações de ambiente.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Tabela de decisão — quando usar tabela Delta vs Volume
# MAGIC
# MAGIC | Cenário | Use tabela Delta | Use Volume |
# MAGIC |---|---|---|
# MAGIC | Dado estruturado para análise | ✓ | |
# MAGIC | Arquivo de entrada (CSV, JSON, Parquet bruto) | | ✓ |
# MAGIC | Resultado de pipeline para dashboard | ✓ | |
# MAGIC | Artefato de CI/CD (databricks.yml, pipeline_payload.json) | | ✓ |
# MAGIC | Landing zone de ingestão | | ✓ |
# MAGIC | Tabela de estado operacional (generation_state) | ✓ | |

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. O que você praticou
# MAGIC
# MAGIC - Inspecionou o catálogo, schema e usuário atuais
# MAGIC - Criou schemas com `CREATE SCHEMA IF NOT EXISTS`
# MAGIC - Criou volumes e entendeu a diferença entre tabelas Delta e volumes
# MAGIC - Usou o caminho `/Volumes/...` para criar arquivos e lê-los com Spark
# MAGIC - Implementou a estratégia de fallback para workspaces free-tier
# MAGIC - Entendeu como o `ResolvedProjectContext` abstrai caminhos e nomes de tabelas

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Qual é a estrutura do namespace do Unity Catalog? Dê um exemplo de caminho completo de tabela e de arquivo em volume.
# MAGIC 2. Qual é a diferença entre uma tabela Delta e um Volume no Unity Catalog?
# MAGIC 3. Por que o projeto usa Volumes como landing zone em vez de DBFS ou storage externo?
# MAGIC 4. Como o projeto garante compatibilidade com workspaces free-tier sem SLA de catálogos múltiplos?
# MAGIC 5. O que é o `ResolvedProjectContext` e qual problema ele resolve no projeto?
