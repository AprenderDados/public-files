# Databricks notebook source
# MAGIC %md
# MAGIC # Tópico 04
# MAGIC ## Expectations — Qualidade Declarativa de Dados

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## O que este caderno faz
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required — Notebook serverless</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Este caderno demonstra os três modos de expectation em Spark Declarative Pipelines: warn (registra e passa), drop (descarta a linha) e fail (para a pipeline). Você vai ver cada modo em ação e entender como o projeto usa expectations configuradas em YAML.</p>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. O que são expectations?
# MAGIC
# MAGIC Expectations são regras de qualidade declaradas como parte do ativo de pipeline. Elas não são comentários nem documentação — fazem parte do comportamento executável da pipeline.
# MAGIC
# MAGIC Três modos:
# MAGIC
# MAGIC | Decorator | Ação | Quando usar |
# MAGIC |---|---|---|
# MAGIC | `@dp.expect("nome", "expressão")` | Registra violações no event log, dado passa | Monitoramento sem bloquear |
# MAGIC | `@dp.expect_or_drop("nome", "expressão")` | Descarta linhas que violam a regra | Dado ruim não deve avançar |
# MAGIC | `@dp.expect_or_fail("nome", "expressão")` | Para a pipeline inteira se a regra for violada | Violação é inaceitável operacionalmente |
# MAGIC
# MAGIC No projeto, as expectations são configuradas em YAML por tabela. A classe `quality_decorator.py` aplica o decorator correto em tempo de execução baseado na propriedade `action` da regra.

# COMMAND ----------

import json
import time
import re
import requests
from pathlib import Path, PurePosixPath
from pyspark.sql import functions as F


def option_get(option_like):
    try:
        return option_like.get()
    except Exception:
        try:
            return option_like.getOrElse(None)
        except Exception:
            return None


def notebook_context():
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    api_url = option_get(ctx.apiUrl())
    if not api_url:
        host = option_get(ctx.browserHostName())
        if host:
            api_url = f"https://{host}"
    token = option_get(ctx.apiToken())
    notebook_path = option_get(ctx.notebookPath())
    user_name = option_get(ctx.userName()) or spark.sql("SELECT current_user()").first()[0]
    return {"api_url": api_url.rstrip("/"), "token": token, "notebook_path": notebook_path, "user_name": user_name}


def ensure_course_volume(volume_name: str):
    current_catalog = spark.sql("SELECT current_catalog()").first()[0]
    current_schema = spark.sql("SELECT current_schema()").first()[0]
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            candidate = (catalog, schema, volume_name)
            if candidate not in candidates:
                candidates.append(candidate)
    errors = []
    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception as exc:
            errors.append(f"{catalog}.{schema}.{volume}: {str(exc).splitlines()[0]}")
    raise RuntimeError("Não foi possível criar Volume.\n" + "\n".join(errors))


def sanitize_name(value):
    return re.sub(r"[^a-zA-Z0-9_]+", "_", value).strip("_").lower()


def api_call(api_url, token, method, path, payload=None, params=None):
    response = requests.request(
        method=method, url=f"{api_url}{path}",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload, params=params, timeout=120,
    )
    if response.status_code >= 400:
        raise RuntimeError(f"Erro na API: {response.status_code} {response.text[:1000]}")
    return {} if not response.text else response.json()


def delete_pipeline_if_exists(api_url, token, name):
    existing = api_call(api_url, token, "GET", "/api/2.0/pipelines")
    for p in (existing if isinstance(existing, list) else existing.get("statuses", [])):
        if p.get("name") == name:
            api_call(api_url, token, "DELETE", f"/api/2.0/pipelines/{p['pipeline_id']}")
            time.sleep(5)


def create_and_run(api_url, token, payload):
    pipeline_id = api_call(api_url, token, "POST", "/api/2.0/pipelines", payload)["pipeline_id"]
    resp = api_call(api_url, token, "POST", f"/api/2.0/pipelines/{pipeline_id}/updates", {"cause": "USER_ACTION"})
    update_id = resp["update_id"]
    started = time.time()
    while True:
        result = api_call(api_url, token, "GET", f"/api/2.0/pipelines/{pipeline_id}/updates/{update_id}")
        state = result.get("update", result).get("state", "UNKNOWN")
        if state in {"COMPLETED", "CANCELED", "FAILED"}:
            return pipeline_id, state
        if (time.time() - started) > 1800:
            raise TimeoutError("Timeout aguardando pipeline.")
        time.sleep(15)


CTX = notebook_context()
API_URL = CTX["api_url"]
API_TOKEN = CTX["token"]
NOTEBOOK_PATH = CTX["notebook_path"]
CURRENT_USER = CTX["user_name"]
USER_SLUG = sanitize_name(CURRENT_USER.split("@")[0])

CATALOG, SCHEMA, VOLUME, BASE_PATH = ensure_course_volume("sdp_curso_04_expectations")
TARGET_SCHEMA = "sdp_curso_expect_lab"
RAW_PATH = f"{BASE_PATH}/raw"
NOTEBOOK_DIR_LOCAL = Path("/Workspace") / str(PurePosixPath(NOTEBOOK_PATH).parent).lstrip("/")
PROJECT_DIR = NOTEBOOK_DIR_LOCAL / "04_expectations_project"
PROJECT_DIR.mkdir(parents=True, exist_ok=True)

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TARGET_SCHEMA}")
for t in ["exp_warn_demo", "exp_drop_demo", "exp_fail_demo_fonte", "sdp_exp_event_log"]:
    spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.{TARGET_SCHEMA}.{t}")

try:
    dbutils.fs.rm(RAW_PATH, True)
except Exception:
    pass
dbutils.fs.mkdirs(RAW_PATH)

# COMMAND ----------

print(f"CATALOG: {CATALOG}")
print(f"TARGET_SCHEMA: {TARGET_SCHEMA}")
print(f"BASE_PATH: {BASE_PATH}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Dados com problemas de qualidade
# MAGIC
# MAGIC Vamos usar um conjunto de transações que mistura dados válidos e inválidos.

# COMMAND ----------

transacoes_csv = """transacao_id,cliente_id,valor,tipo,data_transacao
T001,C001,250.00,debito,2024-04-01
T002,C002,-50.00,credito,2024-04-01
T003,C003,0.00,debito,2024-04-02
T004,C004,180.00,pix,2024-04-02
T005,C005,90.00,debito,2024-04-03
T006,C006,320.00,INVALIDO,2024-04-03
"""

dbutils.fs.put(f"{RAW_PATH}/transacoes.csv", transacoes_csv, True)
display(spark.read.option("header", "true").csv(RAW_PATH))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Modo WARN — registra violação, dado passa
# MAGIC
# MAGIC `@dp.expect` registra a violação no event log mas não remove a linha nem para a pipeline. Útil para monitoramento e alerta sem bloquear o fluxo.

# COMMAND ----------

pipeline_warn = f"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

source = spark.conf.get("source")


@dp.table(name="exp_warn_demo", comment="Transações com warn em valor negativo.")
@dp.expect("valor_positivo_aviso", "valor > 0")
def exp_warn_demo():
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("header", "true")
        .schema("transacao_id STRING, cliente_id STRING, valor DOUBLE, tipo STRING, data_transacao STRING")
        .load(f"{{source}}")
        .select("transacao_id", "cliente_id", F.round("valor", 2).alias("valor"), "tipo",
                F.to_date("data_transacao").alias("data_transacao"))
    )
""".strip()

PIPELINE_WARN_LOCAL = PROJECT_DIR / "warn_pipeline.py"
PIPELINE_WARN_LOCAL.write_text(pipeline_warn, encoding="utf-8")

PIPELINE_WARN_NAME = f"SDP Curso Expect Warn - {USER_SLUG}"
delete_pipeline_if_exists(API_URL, API_TOKEN, PIPELINE_WARN_NAME)

pipeline_id_warn, state_warn = create_and_run(API_URL, API_TOKEN, {
    "pipeline_type": "WORKSPACE", "name": PIPELINE_WARN_NAME,
    "root_path": PROJECT_DIR.as_posix(), "catalog": CATALOG, "target": TARGET_SCHEMA,
    "serverless": True, "development": True, "continuous": False, "channel": "CURRENT", "photon": True,
    "libraries": [{"glob": {"include": f"{PROJECT_DIR.as_posix()}/**"}}],
    "configuration": {"source": RAW_PATH},
    "event_log": {"catalog": CATALOG, "schema": TARGET_SCHEMA, "name": "sdp_exp_event_log"},
})

print("Estado (warn):", state_warn)

# COMMAND ----------

resultado_warn = spark.table(f"{CATALOG}.{TARGET_SCHEMA}.exp_warn_demo")
print("Total de linhas com WARN (dado passa):", resultado_warn.count())
display(resultado_warn.orderBy("transacao_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** todas as 6 linhas estão presentes, inclusive as com `valor <= 0`. O `@dp.expect` não remove — ele apenas registra no event log.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Modo DROP — descarta linhas que violam a regra
# MAGIC
# MAGIC `@dp.expect_or_drop` remove silenciosamente as linhas inválidas. A linha não entra na tabela — mas a pipeline continua executando normalmente com as linhas válidas.

# COMMAND ----------

pipeline_drop = f"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

source = spark.conf.get("source")


@dp.table(name="exp_drop_demo", comment="Transações com drop de valor inválido e tipo inválido.")
@dp.expect_or_drop("valor_positivo", "valor > 0")
@dp.expect_or_drop("tipo_valido", "upper(tipo) IN ('DEBITO', 'CREDITO', 'PIX')")
def exp_drop_demo():
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("header", "true")
        .schema("transacao_id STRING, cliente_id STRING, valor DOUBLE, tipo STRING, data_transacao STRING")
        .load(f"{{source}}")
        .select("transacao_id", "cliente_id", F.round("valor", 2).alias("valor"),
                F.upper("tipo").alias("tipo"), F.to_date("data_transacao").alias("data_transacao"))
    )
""".strip()

PIPELINE_DROP_LOCAL = PROJECT_DIR / "drop_pipeline.py"
PIPELINE_DROP_LOCAL.write_text(pipeline_drop, encoding="utf-8")

PIPELINE_DROP_NAME = f"SDP Curso Expect Drop - {USER_SLUG}"
delete_pipeline_if_exists(API_URL, API_TOKEN, PIPELINE_DROP_NAME)

pipeline_id_drop, state_drop = create_and_run(API_URL, API_TOKEN, {
    "pipeline_type": "WORKSPACE", "name": PIPELINE_DROP_NAME,
    "root_path": PROJECT_DIR.as_posix(), "catalog": CATALOG, "target": TARGET_SCHEMA,
    "serverless": True, "development": True, "continuous": False, "channel": "CURRENT", "photon": True,
    "libraries": [{"glob": {"include": f"{PROJECT_DIR.as_posix()}/**"}}],
    "configuration": {"source": RAW_PATH},
    "event_log": {"catalog": CATALOG, "schema": TARGET_SCHEMA, "name": "sdp_exp_event_log"},
})

print("Estado (drop):", state_drop)

# COMMAND ----------

resultado_drop = spark.table(f"{CATALOG}.{TARGET_SCHEMA}.exp_drop_demo")
print("Total de linhas com DROP (inválidas removidas):", resultado_drop.count())
display(resultado_drop.orderBy("transacao_id"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Observe:** apenas 3 linhas permanecem: T001 (válida), T004 (pix, válido), T005 (débito válido).
# MAGIC
# MAGIC - T002: `valor = -50.00` → descartada por `valor_positivo`
# MAGIC - T003: `valor = 0.00` → descartada por `valor_positivo`
# MAGIC - T006: `tipo = INVALIDO` → descartada por `tipo_valido`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Modo FAIL — para a pipeline se a regra for violada
# MAGIC
# MAGIC `@dp.expect_or_fail` é usado quando uma violação é inaceitável. Se alguma linha violar a regra, a pipeline inteira falha. Use para invariantes que não podem jamais ser quebradas (ex: chave primária não pode ser nula).

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Como o projeto aplica expectations via YAML
# MAGIC
# MAGIC No projeto, as expectations ficam no spec YAML de cada tabela:
# MAGIC
# MAGIC ```yaml
# MAGIC # config/tables/silver/fact_sales_events.yml
# MAGIC quality_rules:
# MAGIC   - name: valid_event_type
# MAGIC     expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
# MAGIC     action: drop
# MAGIC   - name: non_null_sales_event_id
# MAGIC     expression: "sales_event_id IS NOT NULL"
# MAGIC     action: fail
# MAGIC   - name: valid_date_order
# MAGIC     expression: "arrival_date >= sales_date"
# MAGIC     action: warn
# MAGIC ```
# MAGIC
# MAGIC A classe `quality_decorator.py` aplica o decorator correto em tempo de execução:
# MAGIC
# MAGIC ```python
# MAGIC # src/course_lakeflow/silver/quality_decorator.py
# MAGIC def apply_quality_rules(func, rules: list[QualityRuleSpec]):
# MAGIC     for rule in reversed(rules):
# MAGIC         if rule.action == "warn":
# MAGIC             func = dp.expect(rule.name, rule.expression)(func)
# MAGIC         elif rule.action == "drop":
# MAGIC             func = dp.expect_or_drop(rule.name, rule.expression)(func)
# MAGIC         elif rule.action == "fail":
# MAGIC             func = dp.expect_or_fail(rule.name, rule.expression)(func)
# MAGIC     return func
# MAGIC ```
# MAGIC
# MAGIC Isso desacopla a regra de qualidade do código da pipeline. Para mudar uma regra, você edita o YAML — não o Python.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Tabela de decisão — qual modo usar?
# MAGIC
# MAGIC | Situação | Modo correto |
# MAGIC |---|---|
# MAGIC | Quero monitorar sem bloquear | `warn` |
# MAGIC | Dado inválido não deve avançar, mas pipeline continua | `drop` |
# MAGIC | Violação indica problema grave que exige intervenção imediata | `fail` |
# MAGIC | Chave primária obrigatória | `fail` |
# MAGIC | Valor fora de faixa esperado (possível mas raro) | `warn` |
# MAGIC | Status inválido que impediria processamento correto | `drop` |

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. O que você praticou
# MAGIC
# MAGIC - Aplicou `@dp.expect` (warn) e viu que todos os dados passam
# MAGIC - Aplicou `@dp.expect_or_drop` (drop) e viu quais linhas foram descartadas
# MAGIC - Entendeu quando usar `@dp.expect_or_fail` (fail)
# MAGIC - Viu como o projeto separa a declaração de regras (YAML) da aplicação (quality_decorator.py)
# MAGIC - Construiu uma tabela de decisão para escolher o modo correto

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Perguntas de checkpoint
# MAGIC
# MAGIC 1. Qual é a diferença entre `@dp.expect` e `@dp.expect_or_drop`?
# MAGIC 2. Uma expectation do tipo `warn` remove linhas inválidas da tabela?
# MAGIC 3. Em que situação você usaria `@dp.expect_or_fail` em vez de `@dp.expect_or_drop`?
# MAGIC 4. No projeto, como as expectations são configuradas? O engenheiro escreve o decorator diretamente no código de pipeline?
# MAGIC 5. No conjunto de dados deste caderno, quais linhas sobreviveram com o modo `drop` aplicado para `valor > 0` e `tipo` válido?
