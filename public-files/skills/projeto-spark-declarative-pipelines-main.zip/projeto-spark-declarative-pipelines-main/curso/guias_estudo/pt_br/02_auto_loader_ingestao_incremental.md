# Auto Loader — Ingestão Incremental de Arquivos

## Visão geral

O Auto Loader é o mecanismo de ingestão incremental de arquivos do Databricks. Ele detecta novos arquivos em um caminho de storage (Volume do Unity Catalog, ADLS, S3, GCS) e os processa de forma incremental, sem reprocessar o que já foi lido.

No projeto, toda a camada bronze usa Auto Loader via o `BronzeIngestionService`.

## O que o Auto Loader resolve

Sem Auto Loader, ingerir arquivos incrementalmente exige gerenciar manualmente qual arquivo foi processado. Isso significa manter uma tabela de controle, comparar listas de arquivos, lidar com falhas e reprocessamentos.

O Auto Loader faz isso internamente com um **checkpoint**: um diretório com metadados que registra o offset de cada arquivo processado. Na próxima execução, só os novos arquivos são lidos.

## Dois modos de detecção de arquivos

| Modo | Como funciona | Quando usar |
|---|---|---|
| Directory listing | Compara listas de arquivos a cada execução | Volumes pequenos, baixa frequência |
| File notification | Usa eventos de storage (Event Grid, SNS) para notificação imediata | Volumes grandes, alta frequência |

No projeto, o modo padrão é directory listing — suficiente para o volume didático.

## Schema explícito vs inferência

O Auto Loader pode inferir o schema automaticamente lendo uma amostra dos arquivos. Mas o projeto usa **schema explícito** por razões importantes:

1. **Tipos corretos desde o início** — inferência pode errar tipos (ex: um campo numérico que na amostra só tem valores inteiros pode ser inferido como `INT`, mas o dado real tem decimais)
2. **_rescued_data funciona** — sem schema explícito, não há referência para detectar o que não encaixou
3. **Rastreabilidade** — o schema é documentado no YAML, não emergindo de uma amostra que pode mudar

## A coluna `_rescued_data`

Quando um valor não encaixa no schema explícito (tipo incompatível, campo ausente), o Auto Loader não descarta a linha nem falha. Ele coloca o valor problemático em `_rescued_data` como JSON e passa a linha adiante.

Exemplo:
- Schema espera `event_date DATE`
- Arquivo tem `"invalid_date"` no campo
- A coluna `event_date` fica `null`
- `_rescued_data` fica `{"event_date": "invalid_date"}`

No projeto:
- Bronze mantém `_rescued_data` — preserva o dado original com o problema
- Silver filtra `_rescued_data IS NULL` — só dados limpos avançam

## Colunas de metadados `_metadata`

O Auto Loader expõe informações sobre o arquivo via a coluna especial `_metadata` (struct):

| Campo | Tipo | Conteúdo |
|---|---|---|
| `_metadata.file_path` | STRING | Caminho completo do arquivo |
| `_metadata.file_name` | STRING | Nome do arquivo |
| `_metadata.file_modification_time` | TIMESTAMP | Quando o arquivo foi escrito |
| `_metadata.file_size` | LONG | Tamanho em bytes |

O projeto extrai esses campos como colunas explícitas de rastreabilidade na bronze.

## As cinco colunas de rastreabilidade da bronze

O `BronzeIngestionService` adiciona cinco colunas a cada registro:

| Coluna | Origem |
|---|---|
| `ingestion_ts` | `current_timestamp()` |
| `source_file_path` | `_metadata.file_path` |
| `source_file_modification_time` | `_metadata.file_modification_time` |
| `source_file_name` | `_metadata.file_name` |
| `source_batch_id` | extraído do nome do arquivo |

Essas colunas permitem responder: quando esse dado chegou? De qual arquivo? Qual batch gerou esse arquivo?

## Checkpoint e idempotência

O checkpoint é um diretório que registra o estado de leitura do stream. Ele garante que:
- arquivos já processados não sejam lidos novamente
- em caso de falha, o processamento retoma do último ponto consistente

No projeto, o checkpoint de cada tabela bronze está em um Volume separado. A pipeline Lakeflow gerencia o checkpoint automaticamente — o engenheiro não precisa configurar isso manualmente.

## Tabela de decisão — Auto Loader vs COPY INTO vs spark.read

| Critério | `spark.read` | COPY INTO | Auto Loader |
|---|---|---|---|
| Processamento incremental | ✗ | ✓ (com tracking) | ✓ (com checkpoint) |
| Streaming nativo | ✗ | ✗ | ✓ |
| Compatível com Lakeflow | parcial | parcial | ✓ nativo |
| Schema explícito | ✓ | ✓ | ✓ |
| Recovered data | ✗ | ✗ | ✓ (`_rescued_data`) |

Para pipelines Lakeflow (Spark Declarative Pipelines), Auto Loader é a escolha padrão e recomendada para ingestão de arquivos.

## Como o BronzeIngestionService encapsula o Auto Loader

```python
class BronzeIngestionService:
    def read_stream(self, spec: TableSpec, data_path: str) -> DataFrame:
        spark_schema = build_spark_schema(spec.fields)
        return (
            spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", spec.source_format)
            .option("header", "true")
            .schema(spark_schema)
            .load(data_path)
            .select(
                *spec.output_columns,
                current_timestamp().alias("ingestion_ts"),
                col("_metadata.file_path").alias("source_file_path"),
                col("_metadata.file_modification_time").alias("source_file_modification_time"),
                col("_metadata.file_name").alias("source_file_name"),
                "_rescued_data",
            )
        )
```

O schema vem do YAML. O caminho vem do `ResolvedProjectContext`. A função de pipeline só chama `service.read_stream(spec, path)`.
