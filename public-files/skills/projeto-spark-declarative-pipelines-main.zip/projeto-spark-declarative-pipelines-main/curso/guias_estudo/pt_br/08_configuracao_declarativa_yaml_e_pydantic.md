# Configuração Declarativa em YAML com Pydantic

## Visão geral

O projeto usa configuração declarativa em YAML para definir schemas, regras de qualidade, chaves de deduplicação e parâmetros de ambiente. O código Python é genérico — ele lê a configuração e executa o que ela descreve. O Pydantic valida a configuração no momento do carregamento, antes de qualquer execução da pipeline.

## Por que declarar configuração em YAML

Um projeto com 14 tabelas bronze, 14 silver e 7 gold tem muita configuração a gerenciar. As alternativas:

| Abordagem | Problema |
|---|---|
| Hardcoded no código Python | Mudança de schema exige editar código, testar, re-implantar |
| Variáveis no notebook | Espalhado, sem versionamento centralizado, sem validação |
| Configuração em banco | Overhead operacional desnecessário |
| **YAML por tabela** | Cada tabela tem seu spec, versionável, validado, legível |

Com YAML:
- A mudança de um tipo de coluna é um PR de YAML, não de Python
- O schema é legível sem precisar rodar o código
- O `ConfigLoader` carrega e valida antes da pipeline iniciar

## Estrutura do spec de tabela

```yaml
table_name: silver_fact_sales_events_clean
source_table: bronze_fact_sales_events_raw
source_format: delta

fields:
  - name: sales_event_id
    type: long
    nullable: false
  - name: event_type
    type: string
    nullable: false
  - name: sales_date
    type: date
    nullable: true
  - name: amount_delta
    type: decimal(19,4)
    nullable: true

business_keys:
  - sales_event_id

quality_rules:
  - name: valid_event_type
    expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
    action: drop
  - name: non_null_sales_event_id
    expression: "sales_event_id IS NOT NULL"
    action: fail
```

Cada campo tem: nome, tipo YAML (como string), nulabilidade. O `spark_schema.py` converte os tipos YAML em `StructType` do Spark.

## Os modelos Pydantic

Os modelos Pydantic (`common/models.py`) garantem que o YAML é válido antes da execução:

```python
class FieldSpec(BaseModel):
    name: str
    type: str
    nullable: bool = True

class QualityRuleSpec(BaseModel):
    name: str
    expression: str
    action: str  # validado: só aceita "warn", "drop", "fail"

class TableSpec(BaseModel):
    table_name: str
    source_table: Optional[str] = None
    source_format: str = "delta"
    fields: list[FieldSpec] = []
    business_keys: list[str] = []
    quality_rules: list[QualityRuleSpec] = []
```

Se o YAML tiver `action: ignorar_tudo`, o Pydantic vai lançar um erro de validação imediatamente — antes de qualquer tabela ser lida ou escrita.

## A conversão de tipos YAML para Spark

O módulo `spark_schema.py` converte tipos declarados em YAML para tipos Spark:

| Tipo YAML | Tipo Spark |
|---|---|
| `string` | `StringType()` |
| `long` / `bigint` | `LongType()` |
| `int` / `integer` | `IntegerType()` |
| `date` | `DateType()` |
| `timestamp` | `TimestampType()` |
| `double` | `DoubleType()` |
| `decimal(p,s)` | `DecimalType(p, s)` |

Tipos inválidos lançam `ValueError` — outro ponto de validação antes da execução.

## Herança por ambiente

A configuração segue herança por ambiente:

```
config/environments/base.yml    # padrões compartilhados
config/environments/dev.yml     # overrides de desenvolvimento
config/environments/acc.yml     # overrides de homologação
config/environments/prd.yml     # overrides de produção
```

O `ConfigLoader` faz merge com política shallow:
- chaves do ambiente sobrescrevem chaves do base
- chaves ausentes no ambiente herdam do base

```python
merged = {**base_config, **env_config}
```

Isso permite que `dev.yml` defina apenas o que é diferente em dev (ex: nomes de schema com prefixo `_dev_`) sem precisar repetir toda a configuração base.

## O fluxo completo de configuração

```
config/environments/base.yml + dev.yml
          ↓ ConfigLoader.load_environment()
    EnvironmentConfig (Pydantic)
          +
config/tables/bronze/fact_sales_events.yml
          ↓ ConfigLoader.load_table_spec()
    TableSpec (Pydantic)
          ↓ build_spark_schema()
    StructType do Spark
          ↓
    BronzeIngestionService.read_stream(spec, path)
          ↓
    DataFrame com schema tipado
```

## Recursos de configuração além de tabelas

O projeto também tem YAML para:

- **Catálogos** (`config/resources/catalogs.yml`) — mapeia nomes lógicos para catálogos UC
- **Schemas** (`config/resources/schemas.yml`) — mapeia camadas para nomes de schema por ambiente
- **Volumes** (`config/resources/volumes.yml`) — mapeia nomes lógicos para volumes UC
- **Caminhos** (`config/resources/paths.yml`) — mapeia subdiretórios dentro dos volumes
- **Gerador** (`config/generator/`) — SQLs e parâmetros do gerador auxiliar

## Configuração do gerador

O gerador tem seus próprios specs YAML, mais parecidos com configuração operacional:

```yaml
# config/generator/dimensions.yml
dimensions:
  production_product:
    source_sql: |
      SELECT product_id, name, product_number, ...
      FROM adventureworks_federated.production.product
```

Cada dimensão tem um SQL de exportação. O `DimensionFullExporter` usa esse SQL para exportar o snapshot completo da dimensão para CSV no Volume.

## Erros comuns

**"O YAML é lido a cada chamada — se eu mudar, vai refletir imediatamente"**
Não. O YAML é carregado no momento de importação do módulo ou inicialização da pipeline. Uma mudança no YAML exige re-implantar ou reiniciar a pipeline.

**"Posso colocar lógica Python no YAML"**
Não. O YAML é declarativo — contém dados de configuração, não código. A lógica fica nos modelos Pydantic e nas classes de serviço Python.

**"Se o Pydantic não valida um campo, ele passa em branco"**
Não necessariamente. Campos sem `Optional` ou valor default são obrigatórios — Pydantic lança erro se ausentes.
