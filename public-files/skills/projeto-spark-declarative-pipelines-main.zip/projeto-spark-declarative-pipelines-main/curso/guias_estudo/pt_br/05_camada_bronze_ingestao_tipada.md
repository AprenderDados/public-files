# Camada Bronze — Ingestão Tipada e Rastreável

## Visão geral

A camada bronze é o ponto de entrada de todos os dados no projeto. Seu papel é receber os arquivos do Volume, aplicar o schema explícito configurado em YAML, adicionar metadados de rastreabilidade e preservar qualquer anomalia na coluna `_rescued_data` — sem descartar nenhuma linha.

## O que a bronze faz e o que ela não faz

**Faz:**
- Lê arquivos CSV do Volume com Auto Loader
- Aplica schema explícito definido no YAML
- Adiciona 5 colunas de rastreabilidade operacional
- Mantém a coluna `_rescued_data` para valores que não encaixaram no schema

**Não faz:**
- Normalização de texto (maiúsculas, trim)
- Validação de regras de negócio (event_type válido, datas consistentes)
- Deduplicação de registros
- Joins com outras tabelas

Tudo isso é responsabilidade da silver.

## Por que o schema é explícito

Usar "tudo string" parece seguro mas cria problemas sérios:

1. **Erros aparecem tarde**: um campo que deveria ser `DATE` mas chegou como string livre só vai quebrar quando um downstream tentar fazer aritmética com ele
2. **Debugging é difícil**: sem a referência do schema explícito, não há como saber que o campo era inválido na origem
3. **`_rescued_data` não funciona sem schema**: a coluna de rescue só é gerada quando há um schema de referência para comparar

Com schema explícito, o problema fica visível imediatamente na coluna `_rescued_data`, com o valor original preservado em JSON.

## O YAML de configuração da bronze

Cada tabela bronze tem um spec YAML em `config/tables/bronze/`. Exemplo simplificado:

```yaml
# config/tables/bronze/fact_sales_events.yml
table_name: bronze_fact_sales_events_raw
source_format: csv

fields:
  - name: sales_event_id
    type: long
    nullable: false
  - name: event_type
    type: string
    nullable: false
  - name: sales_date
    type: date
    nullable: true
  - name: amount_delta
    type: decimal(19,4)
    nullable: true
  - name: currency_code
    type: string
    nullable: true
```

O `spark_schema.py` converte esses tipos em `StructType` do Spark. O `BronzeIngestionService` usa esse schema ao configurar o Auto Loader.

## As 5 colunas de rastreabilidade

| Coluna | Origem | Pergunta respondida |
|---|---|---|
| `ingestion_ts` | `current_timestamp()` | Quando o registro foi ingerido? |
| `source_file_path` | `_metadata.file_path` | Em qual caminho do Volume estava o arquivo? |
| `source_file_modification_time` | `_metadata.file_modification_time` | Quando o arquivo foi criado/modificado? |
| `source_file_name` | `_metadata.file_name` | Qual era o nome do arquivo? |
| `source_batch_id` | extraído do nome do arquivo | Qual batch de geração produziu esse arquivo? |

Essas colunas nunca são descartadas. Elas sobem da bronze para a silver e ficam disponíveis para debugging ao longo de toda a pipeline.

## O gerador e o naming do batch_id

O gerador auxiliar (`incremental_sales_generator`) nomeia os arquivos com um padrão que embute o batch_id:

```
{env}_fact_sales_events_arrival_{yyyymmdd}_sales_{yyyymmdd}_{hhmmss}.csv
```

O `BronzeIngestionService` extrai esse padrão e armazena em `source_batch_id`. Assim, a bronze sabe de qual execução do gerador cada linha veio.

## Como a bronze e a silver se dividem

Uma forma de pensar: a bronze é o "caderno de registro" — anota tudo que chegou, exatamente como chegou, com metadados de quando chegou. A silver é o "diário confiável" — só contém o que foi verificado, limpo e validado.

Se algo der errado na silver, você volta à bronze para ver o dado original, incluindo o arquivo de origem e o timestamp de ingestão.

## Dimensões vs fatos na bronze

| Aspecto | Bronze de Dimensão | Bronze de Fato |
|---|---|---|
| Padrão de chegada | Full extract periodicamente | Incremental diariamente |
| Acumulação | Append-only (todos os batches) | Append-only (todos os eventos) |
| Campos extras | `extract_batch_id`, `extract_ts` | sem extras (metadata já resolve) |
| Como a silver usa | Filtra pelo último batch | Limpa, valida e deduplica |

As dimensões têm `extract_batch_id` e `extract_ts` porque a silver precisa saber qual foi o último batch completo para publicar o current-state.

## Erros comuns

**"A bronze descarta linhas com `_rescued_data` não-nulo"**
Não. Essa é responsabilidade da silver. A bronze preserva tudo — inclusive linhas problemáticas.

**"A bronze já aplica as regras de qualidade"**
Não. Expectations ficam na silver. A bronze ingerir uma linha com `event_type = "UNKNOWN"` não é um problema — é esperado. A silver vai descartar essa linha.

**"O schema explícito quebra a pipeline se um campo estiver errado"**
Não. O schema explícito faz o campo errado ir para `_rescued_data` — a linha continua presente. A pipeline só quebra se uma expectation `fail` for violada na silver.
