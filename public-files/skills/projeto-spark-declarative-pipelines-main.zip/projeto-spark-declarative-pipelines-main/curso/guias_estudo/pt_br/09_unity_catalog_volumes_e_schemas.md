# Unity Catalog — Volumes e Schemas

## Visão geral

O Unity Catalog (UC) é a camada de governança centralizada do Databricks. Ele organiza todos os objetos — tabelas, views, volumes, funções — em um namespace hierárquico de três níveis: catálogo → schema → objeto. No projeto, o UC é fundamental para organizar as camadas do pipeline (bronze, silver, gold) e para armazenar os arquivos de ingestão em Volumes gerenciados.

## O namespace de três níveis

```
catalog
  └── schema (equivale ao "database" tradicional)
        ├── table / view / function
        └── volume
```

Para referenciar uma tabela: `catalog.schema.tabela`

Para referenciar um arquivo dentro de um volume: `/Volumes/catalog/schema/volume/caminho/arquivo.csv`

O namespace é consistente em SQL, Python e na UI do Databricks.

## Schemas no projeto

Cada camada do pipeline tem seu próprio schema. A convenção de nomes usa o ambiente como prefixo:

| Ambiente | Bronze | Silver | Gold | Ops (gerador) |
|---|---|---|---|---|
| dev | `sdp_dev_bronze` | `sdp_dev_silver` | `sdp_dev_gold` | `sdp_dev_ops` |
| acc | `sdp_acc_bronze` | `sdp_acc_silver` | `sdp_acc_gold` | `sdp_acc_ops` |
| prd | `sdp_prd_bronze` | `sdp_prd_silver` | `sdp_prd_gold` | `sdp_prd_ops` |

Essa convenção permite que múltiplos ambientes coexistam no mesmo catálogo — importante para compatibilidade com workspaces free-tier, onde não é possível criar catálogos adicionais.

## O que são Volumes

Volumes são objetos do Unity Catalog para armazenamento de arquivos — não de tabelas Delta. Eles funcionam como pastas gerenciadas dentro do namespace do UC.

| | Tabelas Delta | Volumes |
|---|---|---|
| Tipo de conteúdo | Dados estruturados (linhas/colunas) | Arquivos (CSV, JSON, Parquet, imagens, etc.) |
| Acesso via SQL | `SELECT * FROM schema.tabela` | — |
| Acesso via caminho | — | `/Volumes/catalog/schema/volume/...` |
| Governança UC | ✓ | ✓ |

Volumes gerenciados: o UC gerencia o storage subjacente.
Volumes externos: apontam para storage externo (ADLS, S3, GCS).

No projeto, o projeto usa volumes gerenciados para manter o setup simples.

## Como acessar arquivos em Volumes

O caminho de um volume tem o formato:

```
/Volumes/{catalog}/{schema}/{volume}/{subdiretório}/{arquivo}
```

Esse caminho funciona em qualquer API que aceite caminhos de arquivo no Databricks:

```python
# Escrever um arquivo
dbutils.fs.put("/Volumes/main/sdp_dev_ops/raw_data/dims/produto/batch.csv", conteudo, True)

# Ler com Spark
df = spark.read.option("header", "true").csv("/Volumes/main/sdp_dev_ops/raw_data/dims/produto/")

# Auto Loader
spark.readStream.format("cloudFiles").load("/Volumes/main/sdp_dev_ops/raw_data/dims/produto/")
```

## Como o projeto usa Volumes

O projeto tem volumes mapeados por finalidade:

| Volume lógico | Uso |
|---|---|
| `raw_data` | Landing zone — arquivos CSV do gerador |
| `checkpoints` | Checkpoints do Auto Loader (um por tabela) |
| `generator_output` | Manifests e artefatos do gerador |

O gerador deposita arquivos em subdiretórios por tipo:
```
/Volumes/.../raw_data/
  dimensions/
    production_product/
      sdp_dev_production_product_20240401T100000Z.csv
  facts/
    sdp_dev_fact_sales_events_arrival_20240401_sales_20240401_100000.csv
```

## Compatibilidade com workspaces free-tier

Em workspaces free-tier, algumas operações de catálogo são limitadas. O projeto implementa uma estratégia de fallback:

1. Tenta criar o volume no catálogo e schema atuais
2. Se falhar, tenta catálogos alternativos (`workspace`, `main`)
3. Se falhar novamente, tenta schemas alternativos (`aprender_dados`, `default`)

```python
def ensure_volume_with_fallback(volume_name: str):
    candidates = []
    for catalog in [current_catalog, "workspace", "main"]:
        for schema in ["aprender_dados", current_schema, "default"]:
            if (catalog, schema, volume_name) not in candidates:
                candidates.append((catalog, schema, volume_name))

    for catalog, schema, volume in candidates:
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")
            return catalog, schema, volume, f"/Volumes/{catalog}/{schema}/{volume}"
        except Exception:
            continue

    raise RuntimeError("Não foi possível criar o volume.")
```

Esse padrão aparece nos notebooks de setup e em toda a estrutura de setup do projeto.

## O ResolvedProjectContext

O `ResolvedProjectContext` (`common/runtime_context.py`) abstrai o acesso ao namespace do UC. Em vez de construir caminhos manualmente, o código de pipeline consulta o contexto:

```python
class ResolvedProjectContext:
    def table_fqn(self, layer: str, table_name: str) -> str:
        # → "main.sdp_dev_bronze.bronze_fact_sales_events_raw"
        return f"{self.catalog}.{self.schema_name(layer)}.{table_name}"

    def volume_path(self, volume_logical: str) -> str:
        # → "/Volumes/main/sdp_dev_ops/raw_data"
        ...

    def data_path(self, subdir: str, logical_name: str) -> str:
        # → "/Volumes/main/sdp_dev_ops/raw_data/facts"
        ...
```

Isso garante que nenhuma parte do código de pipeline hardcoda caminhos. Se o projeto muda de catálogo ou ambiente, só o YAML de configuração precisa ser atualizado.

## Tabela de decisão — tabela Delta vs Volume

| Caso de uso | Use tabela Delta | Use Volume |
|---|---|---|
| Dado estruturado para análise (bronze, silver, gold) | ✓ | |
| Arquivo de entrada (CSV do gerador) | | ✓ |
| Estado operacional (generation_state) | ✓ | |
| Checkpoint do Auto Loader | | ✓ |
| Artefato de bundle (databricks.yml, payload.json) | | ✓ |
| Dashboard JSON | | ✓ |

## Erros comuns

**"Volume e DBFS são a mesma coisa"**
Não. DBFS (Databricks File System) é legado e não tem governança de Unity Catalog. Volumes têm permissões, auditoria e integração com UC. Para projetos novos, use Volumes.

**"Posso criar uma tabela dentro de um Volume"**
Não. Volumes armazenam arquivos, não tabelas. Para criar uma tabela, use `CREATE TABLE` ou `saveAsTable` — elas ficam em schemas, não em volumes.

**"Todo acesso a Volume precisa de /Volumes/"**
Sim. O prefixo `/Volumes/` é obrigatório para acessar arquivos em volumes gerenciados. Caminhos relativos ou DBFS paths (`dbfs:/`) não funcionam para volumes.
