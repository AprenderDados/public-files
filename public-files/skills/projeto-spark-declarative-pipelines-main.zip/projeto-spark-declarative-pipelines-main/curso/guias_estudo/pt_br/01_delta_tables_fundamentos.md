# Delta Tables — Fundamentos

## Visão geral

Delta Lake é o formato de tabela padrão do Databricks. Toda tabela que você cria no projeto — bronze, silver ou gold — é uma tabela Delta. Entender o que torna o Delta diferente de um diretório Parquet simples é a base para entender por que o projeto consegue garantir consistência, rastreabilidade e qualidade ao longo de três camadas.

## O que é o transaction log

O Delta Lake não é só Parquet. É Parquet com um transaction log — um diretório `_delta_log/` que registra cada operação realizada na tabela.

Cada commit grava um arquivo JSON com:
- quais arquivos foram adicionados
- quais arquivos foram removidos
- o schema no momento da operação
- metadados da operação (timestamp, versão, número de linhas)

Esse log é o que habilita ACID, time travel e rollback.

## Por que ACID importa em pipelines

Em um pipeline de dados, várias operações podem acontecer ao mesmo tempo: a pipeline bronze escrevendo, um analista lendo a silver, um job de compactação organizando os arquivos. Sem ACID, essas operações podem se interferir.

O Delta garante:

- **Atomicidade** — a escrita ou acontece inteira ou não acontece
- **Consistência** — o estado da tabela é sempre válido
- **Isolamento** — leitores não veem escritas incompletas
- **Durabilidade** — o que foi commitado, ficou

No projeto, isso é especialmente relevante na gold: a materialized view é recalculada e re-escrita a cada execução. Com ACID, analistas que consultam a gold durante essa recalculação continuam lendo a versão anterior até o novo commit estar completo.

## Time travel

Porque o log registra todas as versões, você pode consultar o estado da tabela em qualquer momento passado.

```sql
-- Por número de versão
SELECT * FROM tabela VERSION AS OF 3

-- Por timestamp
SELECT * FROM tabela TIMESTAMP AS OF '2024-04-01 10:00:00'
```

Usos práticos:
- Debugging de pipeline: comparar o estado da tabela antes e depois de uma execução problemática
- Rollback: restaurar para uma versão anterior após uma carga incorreta
- Auditoria: verificar qual era o dado em um momento específico

## Schema enforcement

Ao criar uma tabela Delta, o schema é registrado no log. Escritas subsequentes com schema incompatível são rejeitadas automaticamente.

Isso é importante no projeto por dois motivos:

1. Garante que a camada bronze rejeita arquivos com tipos errados (os valores são capturados em `_rescued_data`)
2. Garante que mudanças de schema no código sejam explícitas — você não consegue acidentalmente mudar o tipo de uma coluna

## Schema evolution

Quando uma mudança de schema é intencional, o Delta permite evolução controlada com `mergeSchema = true`. Isso adiciona novas colunas sem quebrar as existentes.

No projeto, a evolução de schema é gerenciada via os arquivos YAML de configuração. Mudar um tipo no YAML e re-implantar é uma operação consciente, não acidental.

## Delta no projeto Spark Declarative Pipelines

No projeto, você nunca escreve `format("delta")` diretamente no código de pipeline. O Lakeflow (Spark Declarative Pipelines) escreve em Delta por padrão em todas as streaming tables e materialized views.

O que o engenheiro controla:
- o schema de cada tabela (via YAML)
- as regras de qualidade (via expectations no YAML)
- as transformações (via Python nas classes de serviço)

O Delta é a infraestrutura — transparente e sempre presente.

## Comparação: Delta vs Parquet vs CSV

| Característica | CSV | Parquet | Delta |
|---|---|---|---|
| Compressão colunar | ✗ | ✓ | ✓ |
| ACID | ✗ | ✗ | ✓ |
| Time travel | ✗ | ✗ | ✓ |
| Schema enforcement | ✗ | parcial | ✓ |
| UPDATE / DELETE / MERGE | ✗ | ✗ | ✓ |
| Streaming nativo | ✗ | ✗ | ✓ |

## Perguntas comuns e erros frequentes

**"Posso usar Delta fora do Databricks?"**
Sim. O Delta Lake é open source. Mas o Databricks é o ambiente onde a integração é mais completa, especialmente com Lakeflow, UC e Auto Loader.

**"Delta e Parquet são a mesma coisa?"**
Não. Delta armazena dados em arquivos Parquet, mas adiciona o transaction log por cima. Um diretório Parquet simples não tem ACID nem time travel.

**"Se eu deletar um registro do Delta, ele some do time travel?"**
Não imediatamente. O dado permanece nos arquivos Parquet antigos e está acessível via time travel até o `VACUUM` ser executado. O `VACUUM` remove arquivos de versões mais antigas que o retention period configurado (padrão: 7 dias).
