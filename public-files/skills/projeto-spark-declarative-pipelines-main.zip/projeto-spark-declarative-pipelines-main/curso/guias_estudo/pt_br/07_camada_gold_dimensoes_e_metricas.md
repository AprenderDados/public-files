# Camada Gold — Dimensões Conformadas e Métricas

## Visão geral

A camada gold publica ativos analíticos prontos para consumo — sem transformações adicionais necessárias. Ela conforma dimensões (consolidando hierarquias em tabelas planas), cria uma One Big Table (OBT) com fatos enriquecidos e materializa métricas agregadas para dashboards.

## Dimensões conformadas

Uma "dimensão conformada" é uma tabela de dimensão enriquecida com toda a informação necessária em uma única visão plana — sem precisar de joins adicionais para análise.

No projeto, a dimensão de produto tem quatro níveis hierárquicos:

```
production_productcategory
    → production_productsubcategory
        → production_product
            → production_productmodel
                → production_productdescription (via culture = 'en')
```

A `gold_dim_product` consolida tudo isso em 12 colunas. Em vez de fazer joins em 5 tabelas para uma consulta simples de vendas por categoria, você faz uma única consulta na dimensão conformada.

## Por que todos os joins são LEFT

O projeto usa LEFT JOIN em todos os enriquecimentos da gold. O motivo: preservar eventos de venda mesmo quando a dimensão associada está incompleta.

Cenários onde isso importa:

- Produto foi deletado da dimensão mas ainda aparece em eventos históricos
- Cliente não tem endereço cadastrado
- Produto sem subcategoria (hierarquia incompleta)

Com INNER JOIN, esses eventos desapareceriam dos relatórios. Com LEFT JOIN, o evento permanece com valores nulos nos campos de dimensão ausentes.

**Regra prática:** em métricas de faturamento, perder eventos é sempre pior do que ter nulos.

## One Big Table (OBT)

A `gold_sales_analytics_obt` é uma tabela plana no grão do evento de venda — enriquecida com todas as colunas de produto e cliente conformados.

Composição:
- 13 colunas do evento de venda (fact)
- 12 colunas da dimensão de produto conformada
- 17 colunas da dimensão de cliente conformada
- Total: ~38 colunas

**Vantagem:** dashboards, relatórios ad hoc e análises exploratórias não precisam fazer joins. O dado está pronto.

**Tradeoff:** a tabela é maior e mais custosa para materializar. Para o volume didático do projeto, isso é irrelevante.

## Métricas agregadas

O projeto materializa 4 tabelas de métricas na gold:

### `gold_daily_sales`
Totais diários de vendas. Inclui todos os tipos de evento (`SALE`, `ADJUSTMENT`, `CANCEL`). As métricas `net_quantity` e `net_revenue` são somadas — cancelamentos e ajustes negativos reduzem o total automaticamente.

| Métrica | Significado |
|---|---|
| `net_quantity` | `SUM(quantity_delta)` — inclui negativos de ajustes |
| `net_revenue` | `SUM(amount_delta)` — inclui negativos de cancelamentos |
| `event_count` | Total de todos os eventos |
| `correction_event_count` | Apenas `ADJUSTMENT` e `CANCEL` |

### `gold_daily_sales_by_product`
Mesmas métricas com breakdown por produto e categoria. Grão: `sales_date × product_id`.

### `gold_arrival_vs_business_date`
Analisa latência: agrupa por `arrival_date` × `sales_date` para mostrar eventos que chegaram com atraso (`arrival_date > sales_date`).

### `gold_correction_impact`
Analisa o impacto de correções tardias: agrupa por `arrival_date` × `sales_date` × `event_type` para quantificar quanto cada tipo de correção impactou receita e quantidade.

## Materialized view na gold — por que faz sentido

As tabelas gold são `materialized_view` porque:
- O conteúdo é recalculado a cada execução da pipeline
- Não há acumulação incremental — a cada execução, o estado da gold reflete o estado atual da silver
- Joins e agregações são operações batch, não streaming

Diferente da bronze e silver (que usam streaming tables para processar incrementalmente), a gold recalcula tudo com base no estado corrente.

## State corrente de dimensões na gold — o tradeoff explícito

A gold usa o estado **corrente** das dimensões, não o estado "as-of" da data de venda. Isso significa:

- `product_name` na OBT reflete o nome atual do produto, não o nome quando a venda ocorreu
- Se um produto foi renomeado, todos os eventos históricos aparecem com o nome novo

Esse tradeoff é **intencional**. SCD2 (manter histórico de atributos de dimensão) seria a solução completa, mas tornaria o projeto muito mais complexo — distanciando do foco didático.

## As duas classes de serviço da gold

**`ConformedDimensionService`** (`gold/conformed_dimension_service.py`):
- `build_dim_product()` — junta produto + subcategoria + categoria + modelo + descrição
- `build_dim_customer()` — junta cliente + pessoa + endereço + estado/província + território + loja

**`GoldAggregationService`** (`gold/aggregation_service.py`):
- `build_sales_analytics_obt()` — OBT com fatos + dimensões
- `build_daily_sales()` — totais diários
- `build_daily_sales_by_product()` — totais por produto
- `build_arrival_vs_business_date()` — análise de latência
- `build_correction_impact()` — impacto de correções

## Erros comuns

**"A gold processa dados incrementalmente como a bronze"**
Não. As tabelas gold são materialized views — recalculadas completamente a cada execução.

**"Net revenue só inclui SALE"**
Não. `net_revenue` é a soma de todos os `amount_delta`, incluindo os negativos de `ADJUSTMENT` e `CANCEL`. Isso é o resultado líquido real.

**"A OBT deveria usar INNER JOIN para garantir dados completos"**
Não. INNER JOIN eliminaria eventos com dimensão ausente. LEFT JOIN é deliberado para preservar todos os eventos.
