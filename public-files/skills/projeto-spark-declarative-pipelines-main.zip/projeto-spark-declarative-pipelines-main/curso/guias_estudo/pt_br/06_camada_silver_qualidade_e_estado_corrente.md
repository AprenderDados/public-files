# Camada Silver — Qualidade e Estado Corrente

## Visão geral

A camada silver é responsável por publicar dados confiáveis e normalizados para consumo downstream. Ela recebe o dado bruto da bronze e aplica três etapas: qualidade (filtros e expectations), normalização (padronização de valores) e deduplicação (eliminação de duplicatas por chave de negócio).

Para dimensões, a silver também implementa o **current-state pattern**: publica apenas o batch mais recente, descartando o histórico de batches anteriores.

## O current-state pattern para dimensões

As dimensões chegam na bronze como full extracts — snapshots completos. Cada batch tem um `extract_batch_id` e um `extract_ts` únicos.

A silver não quer o histórico de batches. Ela quer **o estado mais recente** da dimensão. O algoritmo é simples:

1. Agrupa por `extract_batch_id` e pega o maior `extract_ts`
2. Filtra apenas as linhas com esse `extract_batch_id`

```python
class LatestFullLoadSelector:
    def latest_batch(self, df: DataFrame) -> str:
        return (
            df.groupBy("extract_batch_id")
            .agg(max("extract_ts").alias("ts"))
            .orderBy(col("ts").desc())
            .first()["extract_batch_id"]
        )

    def current_batch(self, df: DataFrame) -> DataFrame:
        return df.filter(col("extract_batch_id") == self.latest_batch(df))
```

**Por que isso representa deleções naturalmente:**
Se uma chave estava no batch de segunda e não está no batch de sexta, ela simplesmente não aparece na silver na sexta. Não precisa de marcador de deleção, CDC artificial ou lógica especial.

## Sem SCD2 — decisão intencional

Dimensão Slowly Changing Type 2 (SCD2) preserva o histórico de mudanças de atributos. Por exemplo: um produto mudou de categoria, e você quer saber em que categoria estava quando a venda ocorreu.

O projeto decidiu **não usar SCD2**. A gold usa o estado corrente das dimensões (não o estado "as-of" da data de venda). Essa decisão é intencional:

- Simplifica enormemente a pipeline
- Mantém o foco didático nas camadas de ingestão e qualidade
- O estado corrente é suficiente para o domínio analítico do projeto

## Deduplicação com window functions

Fatos podem chegar duplicados por várias razões: reenvio de arquivo, reprocessamento, falha de idempotência no gerador. A silver elimina duplicatas por chave de negócio usando `row_number()`.

```python
class FactDeduplicationService:
    def deduplicate(self, df: DataFrame, business_keys: list[str]) -> DataFrame:
        window = (
            Window
            .partitionBy(*business_keys)
            .orderBy(
                col("extract_ts").desc(),
                col("source_file_modification_time").desc(),
                col("ingestion_ts").desc(),
            )
        )
        return (
            df.withColumn("_rn", row_number().over(window))
            .filter(col("_rn") == 1)
            .drop("_rn")
        )
```

Critério de desempate (em caso de duplicata com o mesmo `extract_ts`):
1. `extract_ts` mais recente
2. `source_file_modification_time` mais recente
3. `ingestion_ts` mais recente

Esse critério é determinístico — sempre o mesmo resultado para o mesmo dado.

## Normalização de valores

A silver padroniza valores antes de gravar:

| Transformação | Colunas | Motivo |
|---|---|---|
| `upper(trim(col))` | `event_type`, `currency_code` | Consistência para comparações e expectations |
| `round(col, n)` | `amount_delta` | Evitar discrepâncias de arredondamento |
| `trim(col)` | nomes de dimensão | Evitar problemas com espaços invisíveis |

Essas transformações acontecem **depois** do filtro de `_rescued_data` e **antes** das expectations. A ordem importa: não faz sentido normalizar dados que serão descartados.

## O pipeline de transformação da silver de fatos

1. `filter(_rescued_data IS NULL)` — descarta linhas com schema corrompido
2. `upper(event_type)`, `upper(currency_code)` — normalização
3. `round(amount_delta, 4)` — precisão monetária
4. `deduplicate(business_keys)` — remove duplicatas
5. Expectations declaradas — regras de qualidade

## Os 13 builders de dimensão

O projeto tem um builder por dimensão silver (`source_current_builders.py`). Cada builder estende `BaseCurrentDimensionBuilder` e implementa:

1. `filter_rescued_data()` — herdado da base
2. `current_batch()` — via `LatestFullLoadSelector`
3. transformações específicas da dimensão (trim, upper conforme necessário)
4. `project_output_columns()` — valida que todas as colunas esperadas existem

Exemplo: `ProductCurrentBuilder` converte `product_number` para maiúsculas e faz trim de `name`.

## Separação de responsabilidades — bronze vs silver

| Responsabilidade | Bronze | Silver |
|---|---|---|
| Ler arquivos com Auto Loader | ✓ | ✗ |
| Schema explícito | ✓ | — |
| Colunas de rastreabilidade | ✓ (adiciona) | ✓ (preserva) |
| `_rescued_data` | ✓ (captura) | ✓ (filtra e descarta) |
| Normalização textual | ✗ | ✓ |
| Expectations declaradas | ✗ | ✓ |
| Deduplicação | ✗ | ✓ |
| Current-state de dimensões | ✗ | ✓ |

## Erros comuns

**"A silver reprocessa todo o histórico da bronze a cada execução"**
Não. A silver de fatos usa streaming table — ela processa apenas os eventos novos desde o último checkpoint. A silver de dimensões usa o batch mais recente da bronze, não todos os batches.

**"A deduplicação precisa ser exata para funcionar — se o mesmo dado veio duas vezes, sempre vai ter duplicata"**
A deduplicação por `row_number()` é exata nas chaves de negócio declaradas. Se dois registros têm o mesmo `sales_event_id`, somente o mais recente fica.

**"O current-state pattern ignora dados históricos da bronze"**
Intencionalmente. A bronze preserva o histórico de todos os batches. A silver publica apenas o estado atual. Se você precisar do histórico, consulte a bronze diretamente.
