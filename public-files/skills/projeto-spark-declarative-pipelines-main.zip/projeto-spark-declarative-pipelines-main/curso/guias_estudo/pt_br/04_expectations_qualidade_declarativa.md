# Expectations — Qualidade Declarativa de Dados

## Visão geral

Expectations são regras de qualidade declaradas como parte de um ativo de pipeline declarativa. Elas não são comentários nem validações manuais — fazem parte do comportamento executável da pipeline e são monitoradas via event log e pipeline graph.

## Os três modos

| Decorator | Ação quando a regra é violada | Linhas com violação |
|---|---|---|
| `@dp.expect("nome", "expr")` | Registra no event log | Passam para a tabela |
| `@dp.expect_or_drop("nome", "expr")` | Registra no event log | São descartadas silenciosamente |
| `@dp.expect_or_fail("nome", "expr")` | Para a pipeline com erro | A pipeline falha antes de gravar |

## Quando usar cada modo

**`expect` (warn)**
Use para monitoramento. Você quer saber se o dado tem problemas, mas não quer bloquear o fluxo. Útil quando o dado "errado" ainda tem valor downstream ou quando você está no processo de entender a qualidade da origem.

Exemplo: `"valid_date_order", "arrival_date >= sales_date"`. Datas fora de ordem são suspeitas mas não impedem análise — vale registrar e investigar.

**`expect_or_drop` (drop)**
Use quando dado inválido não deve avançar, mas a pipeline deve continuar com os dados válidos. A maioria das regras de negócio de qualidade usa esse modo.

Exemplo: `"valid_event_type", "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"`. Um tipo de evento desconhecido não faz sentido na silver — descarta.

**`expect_or_fail` (fail)**
Use quando a violação indica um problema sério que exige intervenção humana imediata. Se a regra for violada, nada pode ser commitado — é melhor parar do que avançar com dado corrompido.

Exemplo: `"non_null_sales_event_id", "sales_event_id IS NOT NULL"`. Um evento de venda sem ID é impossível de rastrear — a pipeline deve falhar.

## Tabela de decisão rápida

| Situação | Modo |
|---|---|
| Chave primária não pode ser nula | `fail` |
| Tipo de evento inválido (ex: `UNKNOWN`) | `drop` |
| Valor fora de faixa esperado (suspeito, mas não inválido) | `warn` |
| Data de negócio anterior à data de chegada | `warn` |
| Moeda com formato errado | `warn` |
| Quantidade zero em uma venda | `drop` |
| Campo obrigatório ausente | `fail` ou `drop` dependendo da criticidade |

## Como as expectations aparecem no pipeline graph

No pipeline graph do Databricks, cada ativo com expectations mostra:

- quantas linhas passaram
- quantas linhas violaram cada regra
- o modo de cada regra (warn, drop, fail)

Isso torna a qualidade de dados visível sem precisar de consultas manuais.

## Stacking de decorators

Você pode aplicar múltiplas expectations no mesmo ativo:

```python
@dp.table(name="silver_pedidos")
@dp.expect_or_fail("non_null_id", "pedido_id IS NOT NULL")
@dp.expect_or_drop("valor_positivo", "valor > 0")
@dp.expect("data_valida", "data_pedido >= '2020-01-01'")
def silver_pedidos():
    return spark.readStream.table("bronze_pedidos")
```

As regras são aplicadas em sequência. Se `non_null_id` falhar, a pipeline para. Se `valor_positivo` falhar, a linha é descartada. Se `data_valida` falhar, a linha passa mas a violação é registrada.

## Como o projeto aplica expectations via YAML

O projeto armazena as regras em YAML por tabela e as aplica dinamicamente:

```yaml
# config/tables/silver/fact_sales_events.yml
quality_rules:
  - name: valid_event_type
    expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
    action: drop
  - name: non_null_sales_event_id
    expression: "sales_event_id IS NOT NULL"
    action: fail
  - name: valid_date_order
    expression: "arrival_date >= sales_date"
    action: warn
```

A classe `quality_decorator.py` lê essas regras e aplica os decorators corretos em runtime:

```python
def apply_quality_rules(func, rules: list[QualityRuleSpec]):
    for rule in reversed(rules):
        if rule.action == "warn":
            func = dp.expect(rule.name, rule.expression)(func)
        elif rule.action == "drop":
            func = dp.expect_or_drop(rule.name, rule.expression)(func)
        elif rule.action == "fail":
            func = dp.expect_or_fail(rule.name, rule.expression)(func)
    return func
```

Para mudar uma regra, você edita o YAML — não o Python. Isso torna as mudanças de política de qualidade rastreáveis e independentes do código de transformação.

## Expectations no projeto — tabela silver de fatos

A silver do fato de vendas tem 8 expectations declaradas no YAML:

| Regra | Expressão | Ação |
|---|---|---|
| `valid_event_type` | `event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')` | drop |
| `non_null_sales_event_id` | `sales_event_id IS NOT NULL` | fail |
| `non_null_product_id` | `product_id IS NOT NULL` | drop |
| `non_null_customer_id` | `customer_id IS NOT NULL` | drop |
| `non_null_territory_id` | `territory_id IS NOT NULL` | drop |
| `valid_date_order` | `arrival_date >= sales_date` | warn |
| `non_zero_quantity` | `quantity_delta <> 0` | drop |
| `valid_currency_code` | `length(currency_code) = 3` | warn |

Observe a mistura de modos: falhar para ID nulo (impossível de processar), descartar para tipo/produto/chave inválidos (sem sentido avançar), avisar para datas e moeda (suspeitos mas ainda processáveis).
