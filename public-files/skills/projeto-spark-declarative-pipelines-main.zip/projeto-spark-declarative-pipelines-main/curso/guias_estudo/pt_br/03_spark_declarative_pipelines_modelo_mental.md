# Spark Declarative Pipelines — Modelo Mental

## Visão geral

Spark Declarative Pipelines (anteriormente Delta Live Tables) é o framework de pipeline declarativa do Databricks. Em vez de orquestrar notebooks manualmente, você **declara ativos** — tabelas e views com dependências, regras de qualidade e comportamento incremental. A pipeline cuida da execução.

## Imperativo vs declarativo — a diferença central

Em uma pipeline imperativa clássica:
```
Job 1: lê arquivo → escreve bronze
Job 2: lê bronze → transforma → escreve silver
Job 3: lê silver → agrega → escreve gold
```

O engenheiro gerencia a ordem, dependências, falhas e retries.

Em uma pipeline declarativa:
```python
@dp.table(name="bronze_pedidos")
def bronze_pedidos(): return spark.readStream...

@dp.table(name="silver_pedidos")
def silver_pedidos(): return spark.readStream.table("bronze_pedidos")...

@dp.materialized_view(name="gold_resumo")
def gold_resumo(): return spark.read.table("silver_pedidos").groupBy(...)
```

O sistema descobre as dependências (`silver → bronze`, `gold → silver`), monta o grafo e executa na ordem correta. O engenheiro não gerencia isso.

## Os dois tipos principais de ativo

### Streaming Table (`@dp.table`)

Representa uma tabela que processa dados de forma incremental. Cada execução da pipeline lê apenas os dados novos desde o último checkpoint.

Característica central: **append-only incrementalmente**. O dado que já foi processado fica na tabela. O novo dado é adicionado.

Usado para:
- camada bronze (arquivos novos chegam continuamente)
- camada silver de fatos (eventos de venda chegam incrementalmente)

### Materialized View (`@dp.materialized_view`)

Representa um resultado derivado que é materializado (persistido em disco). A cada execução, a view é recalculada a partir dos dados mais recentes das tabelas fonte.

Característica central: **re-calculada a cada execução**. O estado anterior é substituído pelo novo.

Usado para:
- camada gold (dimensões conformadas, OBT, métricas)
- dimensões silver current-state (sempre reflete o último batch)

## Tabela de decisão — qual tipo usar?

| Situação | Tipo correto |
|---|---|
| Auto Loader ingerindo arquivos novos | `streaming_table` (`@dp.table`) |
| Fatos chegando incrementalmente | `streaming_table` |
| Dimensão publicando estado corrente | pode ser `streaming_table` com lógica de latest batch |
| Agregação que reflete o estado atual | `materialized_view` |
| Join de dimensões (conformed dim) | `materialized_view` |
| One Big Table com enriquecimento | `materialized_view` |

## O pipeline graph

Ao abrir a pipeline na UI do Databricks, o pipeline graph mostra:
- todos os ativos e suas dependências (quem depende de quem)
- status de cada ativo na execução atual
- contagem de linhas processadas e descartadas
- erros por ativo

No projeto, o graph tem 27 ativos: 14 bronze, 13 silver dimensões + 1 silver fato, 2 gold dimensões + 1 OBT + 4 métricas. A pipeline executa tudo em paralelo onde não há dependência.

## A biblioteca moderna: `pyspark.pipelines`

O padrão moderno usa `from pyspark import pipelines as dp`. Os decorators são:

| Decorator | Tipo de ativo |
|---|---|
| `@dp.table` | Streaming table |
| `@dp.materialized_view` | Materialized view |
| `@dp.expect` | Expectation — warn |
| `@dp.expect_or_drop` | Expectation — drop |
| `@dp.expect_or_fail` | Expectation — fail |

Funções especiais:
- `dp.create_streaming_table` — cria uma streaming table sem função associada (target de CDC)
- `dp.create_auto_cdc_flow` — aplica CDC em uma streaming table

## Como o projeto organiza as definições de pipeline

Os arquivos em `src/course_lakeflow/pipelines/` declaram os ativos:

```
bronze_dimensions.py   → 13 streaming tables de dimensão bronze
bronze_facts.py        → 1 streaming table de fato bronze
silver_dimensions.py   → 13 tabelas silver (current-state por latest batch)
silver_facts.py        → 1 streaming table de fato silver com expectations
gold_metrics.py        → 2 dimensões + 1 OBT + 4 métricas (materialized views)
```

Cada arquivo importa serviços do pacote `course_lakeflow`. A lógica de transformação fica nos serviços, não nos arquivos de pipeline. Os arquivos de pipeline só declaram o que existe e de onde vem.

## Event log

A pipeline mantém um event log — uma tabela Delta que registra eventos de execução:

- início e fim de cada update
- erros de expectation
- contagem de linhas por ativo
- erros de execução

O event log é configurado no payload de criação da pipeline:
```python
"event_log": {"catalog": CATALOG, "schema": TARGET_SCHEMA, "name": "meu_event_log"}
```

## Erros comuns de entendimento

**"A pipeline executa os ativos em sequência, um por um"**
Não. A pipeline executa em paralelo ativos sem dependência entre si. Por exemplo, as 13 dimensões bronze podem ser processadas simultaneamente.

**"Streaming table e materialized view são a mesma coisa"**
Não. Streaming table processa incrementalmente e mantém o histórico. Materialized view recalcula e substitui o estado anterior.

**"Preciso chamar `writeStream.start()` na pipeline declarativa"**
Não. Você declara o ativo com `@dp.table` e retorna o DataFrame. A pipeline gerencia o write, checkpoint e execução.
