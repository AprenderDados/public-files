# Curso — Spark Declarative Pipelines na Prática

Este diretório contém o material didático do projeto, organizado por tópico. A proposta é diferente da documentação do projeto: aqui cada tópico é tratado de forma isolada, com exemplos próprios e explicações progressivas.

O objetivo não é explicar o projeto inteiro de uma vez. É explicar cada habilidade técnica que o projeto usa — mostrando o conceito de forma simples, depois conectando com o código real.

## Organização

```
notebooks/pt_br/    cadernos executáveis por tópico (Databricks .py)
guias_estudo/pt_br/ referências de estudo em Markdown por tópico
simulados/pt_br/    questionários de fixação por tópico
slides/pt_br/       roteiros de slides para gravação por tópico
```

## Tópicos

| # | Tópico | Conceito central |
|---|---|---|
| 01 | Delta Tables — Fundamentos | Formato Delta, ACID, time travel |
| 02 | Auto Loader — Ingestão Incremental | cloudFiles, schema explícito, metadados |
| 03 | Spark Declarative Pipelines — Modelo Mental | streaming tables, materialized views, decorators |
| 04 | Expectations — Qualidade Declarativa | warn, drop, fail |
| 05 | Camada Bronze — Ingestão Tipada e Rastreável | schema from config, rescued data, metadata columns |
| 06 | Camada Silver — Qualidade e Estado Corrente | current-state pattern, deduplicação, normalização |
| 07 | Camada Gold — Dimensões Conformadas e Métricas | conformed dims, OBT, agregações |
| 08 | Configuração Declarativa em YAML com Pydantic | config-driven development, herança, type safety |
| 09 | Unity Catalog — Volumes e Schemas | UC namespace, volumes, paths, free-tier |

## Como usar

Cada caderno é autocontido. Ele cria seu próprio ambiente (schema e volume) e pode ser executado do zero sem depender de outros cadernos.

Após cada caderno, o guia de estudo aprofunda o conceito com tabelas de decisão, comparações e conexões com o código real do projeto. O simulado oferece questões de fixação. O roteiro de slides serve para gravação de aula.

## Conexão com o projeto

Os cadernos mostram o conceito de forma simples. A conexão com o código real do projeto (`src/course_lakeflow/`) é feita nas seções finais de cada caderno e nos guias de estudo. A ideia é: entenda o conceito isolado primeiro, depois veja como o projeto o usa em escala.
