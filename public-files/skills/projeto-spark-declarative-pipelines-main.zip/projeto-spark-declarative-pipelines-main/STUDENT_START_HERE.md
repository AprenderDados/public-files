# Por onde começar

Você não precisa ler o README inteiro antes de começar.
Um assistente vai te guiar por tudo — passo a passo, com explicações, no seu ritmo.

---

## Passo 1 — Abra seu agente de IA

Qualquer ferramenta funciona:
- Claude (claude.ai)
- ChatGPT
- GitHub Copilot Chat
- Qualquer outro com campo de instrução de sistema

---

## Passo 2 — Cole o conteúdo do assistente

Abra este arquivo do repositório:

```
ai/skills/student-project-assistant/SKILL.md
```

Copie **todo o conteúdo** e cole como instrução de sistema do seu agente:
- Claude → Project Instructions
- ChatGPT → Custom Instructions ou System Prompt do GPT
- Copilot → instrução de contexto

---

## Passo 3 — Diga ao agente

```
Quero começar o projeto.
```

O assistente vai perguntar seu ponto atual e seu objetivo, e guiar tudo a partir daí.

Se quiser ser mais direto, use uma destas mensagens:

```text
Quero começar do zero no modo workspace files.
```

```text
Quero começar do zero no modo bundle.
```

---

## Pré-requisito: ambiente pronto

O assistente assume que seu ambiente Databricks está configurado:
- Workspace com Unity Catalog habilitado
- Lakehouse Federation com `adventureworks_federated` configurada
- Projeto disponível no workspace (como workspace files ou via bundle)
- Python local `>=3.11` se você quiser validar testes ou usar bundle localmente
- Databricks CLI autenticado se você optar pelo caminho com bundle

Checagem local mínima:

```bash
python3.11 --version
bash scripts/bootstrap_local_env.sh
```

Se o ambiente ainda não está pronto, leia primeiro:
- [`docs/workspace_direct_setup.md`](docs/workspace_direct_setup.md) — modo sem CLI
- [`docs/federation_setup.md`](docs/federation_setup.md) — como configurar a federation
- [`README.md`](README.md) — instruções completas de setup com bundle

Ponto operacional importante:

- neste workspace, rode a pipeline Python e a pipeline SQL em sequência
- não dispare as duas em paralelo

---

## Mapa de progresso

Conforme avança no projeto, use este arquivo para acompanhar as etapas concluídas:

```
ai/skills/student-project-assistant/CHECKPOINTS.md
```

Você pode compartilhar o arquivo com o assistente quando quiser uma revisão do que fez.
