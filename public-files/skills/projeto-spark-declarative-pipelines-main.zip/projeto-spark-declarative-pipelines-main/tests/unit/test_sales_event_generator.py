import pytest

from incremental_sales_generator.sales_event_generator import SalesEventGenerator


class FakeDataFrame:
    def __init__(self, persist_error: Exception | None = None):
        self.persist_error = persist_error

    def persist(self, storage_level):
        if self.persist_error is not None:
            raise self.persist_error
        return self


def test_persist_if_supported_tracks_persisted_dataframe():
    df = FakeDataFrame()
    persisted_dfs = []

    result = SalesEventGenerator._persist_if_supported(df, persisted_dfs)

    assert result is df
    assert persisted_dfs == [df]


def test_persist_if_supported_skips_serverless_persist_error():
    df = FakeDataFrame(Exception("[NOT_SUPPORTED_WITH_SERVERLESS] PERSIST TABLE is not supported"))
    persisted_dfs = []

    result = SalesEventGenerator._persist_if_supported(df, persisted_dfs)

    assert result is df
    assert persisted_dfs == []


def test_persist_if_supported_raises_unexpected_error():
    df = FakeDataFrame(RuntimeError("unexpected persist failure"))

    with pytest.raises(RuntimeError, match="unexpected persist failure"):
        SalesEventGenerator._persist_if_supported(df, [])


def test_should_append_registry_respects_configured_limit():
    assert SalesEventGenerator._should_append_registry(5_000_000, 5_000_000)
    assert not SalesEventGenerator._should_append_registry(5_000_001, 5_000_000)
    assert SalesEventGenerator._should_append_registry(5_000_001, None)


def test_should_generate_late_events_respects_threshold_and_flag():
    assert SalesEventGenerator._should_generate_late_events(5_000_000, True, 5_000_000)
    assert not SalesEventGenerator._should_generate_late_events(5_000_001, True, 5_000_000)
    assert not SalesEventGenerator._should_generate_late_events(10, False, 5_000_000)
    assert SalesEventGenerator._should_generate_late_events(5_000_001, True, None)


def test_resolve_target_file_count_uses_fixed_count_for_parquet():
    assert (
        SalesEventGenerator._resolve_target_file_count(
            total_rows=1_000_000_000,
            coalesce_output_files=1,
            parquet_output_files=32,
            csv_max_rows_per_output_file=250_000,
            file_format="parquet",
        )
        == 32
    )


def test_resolve_target_file_count_uses_row_limit_for_csv():
    assert (
        SalesEventGenerator._resolve_target_file_count(
            total_rows=1_000_000,
            coalesce_output_files=1,
            parquet_output_files=32,
            csv_max_rows_per_output_file=250_000,
            file_format="csv",
        )
        == 4
    )
