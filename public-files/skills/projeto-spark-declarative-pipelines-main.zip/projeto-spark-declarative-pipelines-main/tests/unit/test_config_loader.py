from pathlib import Path

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.spark_schema import SparkSchemaBuilder


def test_load_bronze_fact_table_spec():
    project_root = Path(__file__).resolve().parents[2]
    loader = ConfigLoader(project_root)

    spec = loader.load_table_spec("bronze", "fact_sales_events_raw.yml")

    assert spec.logical_name == "fact_sales_events_raw"
    assert spec.layer == "bronze"
    assert len(spec.schema) >= 5


def test_build_spark_schema_from_bronze_fact_table_spec():
    project_root = Path(__file__).resolve().parents[2]
    loader = ConfigLoader(project_root)
    spec = loader.load_table_spec("bronze", "fact_sales_events_raw.yml")

    schema = SparkSchemaBuilder.build(spec.schema)

    assert schema.fieldNames()[0] == "sales_event_id"
    assert "amount_delta" in schema.fieldNames()


def test_load_silver_dimension_with_explicit_schema():
    project_root = Path(__file__).resolve().parents[2]
    loader = ConfigLoader(project_root)

    spec = loader.load_table_spec("silver", "production_product_current.yml")

    assert spec.logical_name == "production_product_current"
    assert spec.asset_type == "materialized_view"
    assert spec.schema[0].name == "extract_batch_id"
    assert spec.business_keys == ["product_id"]


def test_generator_defaults_include_registry_limit():
    from incremental_sales_generator.config import GeneratorConfigLoader

    project_root = Path(__file__).resolve().parents[2]
    config = GeneratorConfigLoader(project_root).load()

    assert config.defaults.parquet_output_files == 32
    assert config.defaults.csv_max_rows_per_output_file == 250_000
    assert config.defaults.max_registry_rows == 5_000_000
    assert config.defaults.max_rows_for_late_events == 5_000_000
