# Guia prático: Databricks Free Edition com VS Code

Este guia mostra como usar a Databricks Free Edition a partir do Visual Studio Code com a extensão oficial da Databricks.

A ideia é trabalhar localmente no VS Code, mantendo o código em arquivos e Git, mas executar no workspace remoto do Databricks.

> Atualizado em: 2026-05-15

## 1. O que você vai configurar

Ao final do guia, você terá:

- uma conta Databricks Free Edition;
- o Visual Studio Code preparado para Python;
- a extensão oficial Databricks instalada;
- um projeto local conectado ao workspace Databricks;
- autenticação configurada;
- sincronização da pasta local para o workspace remoto;
- um arquivo ou notebook executando no Databricks.

## 2. Conceitos rápidos

### Databricks Free Edition

A Free Edition é uma versão gratuita do Databricks para estudo, protótipos e experimentação pessoal.

Na Free Edition, o compute é **serverless-only** e sujeito a quotas. Isso significa:

- você não cria clusters customizados;
- você não escolhe tamanho de cluster livremente;
- se a quota diária for excedida, o compute pode ficar indisponível até o limite resetar;
- os dados e configurações continuam no workspace mesmo quando o compute fica temporariamente indisponível.

### Extensão Databricks para VS Code

A extensão permite conectar o VS Code ao workspace Databricks para:

- configurar autenticação;
- selecionar o workspace alvo;
- selecionar compute quando disponível;
- sincronizar arquivos locais para uma pasta remota no workspace;
- executar arquivos Python e notebooks como workflows/jobs;
- configurar ambiente Python e Databricks Connect para execução e depuração local/remota.

Importante: no contexto da Free Edition, priorize execução como **Workflow/Job** e uso de **serverless**. O fluxo "Upload and Run File" em cluster depende de cluster e não é o caminho principal para Free Edition.

## 3. Pré-requisitos

Antes de começar, instale ou tenha acesso a:

- conta Databricks Free Edition;
- Visual Studio Code 1.86 ou superior;
- Python instalado localmente;
- extensão Python da Microsoft no VS Code;
- Git, se você quiser versionar o projeto;
- navegador autenticado na sua conta Databricks.

Links úteis:

- Databricks Free Edition: https://docs.databricks.com/aws/en/getting-started/free-edition
- Limites da Free Edition: https://docs.databricks.com/aws/en/getting-started/free-edition-limitations
- Extensão Databricks para VS Code: https://docs.databricks.com/aws/en/dev-tools/vscode-ext

## 4. Criar a conta Free Edition

1. Acesse a página de signup da Databricks Free Edition.
2. Escolha o método de login disponível para você.
3. Aguarde a criação automática do workspace.
4. Entre no workspace pelo navegador.
5. Confirme que você consegue abrir a tela principal do Databricks.

Anote a URL do workspace. Ela será usada pela extensão.

Exemplo de formato:

```text
https://dbc-xxxxxxxx-xxxx.cloud.databricks.com
```

## 5. Instalar a extensão no VS Code

1. Abra o VS Code.
2. Vá em `View > Extensions`.
3. Pesquise por `Databricks`.
4. Instale a extensão oficial com publicador verificado pela Databricks.
5. Reinicie o VS Code se ele solicitar.
6. Clique no ícone da Databricks na barra lateral.

## 6. Criar ou abrir um projeto local

Você pode seguir por dois caminhos.

### Opção A: criar um projeto novo pela extensão

1. Clique no ícone da Databricks no VS Code.
2. Selecione `Create a new project`.
3. Informe a pasta local onde o projeto será criado.
4. Escolha o template mais simples disponível.
5. Se a extensão perguntar, adicione um notebook ou pacote Python de exemplo.
6. Abra o projeto criado no VS Code.

### Opção B: conectar um projeto existente

1. Abra a pasta do projeto no VS Code.
2. Clique no ícone da Databricks na barra lateral.
3. Selecione `Create configuration`.
4. Siga os prompts da extensão.

Essa opção cria arquivos de configuração do Databricks no projeto, como `databricks.yml` e arquivos auxiliares dentro de `.databricks/`.

## 7. Configurar autenticação

A forma recomendada é OAuth interativo.

1. No painel da extensão Databricks, abra a área `Configuration`.
2. Clique em `Auth Type` ou `Login to Databricks`.
3. Escolha `OAuth (user to machine)`.
4. Informe um nome para o perfil de autenticação.
5. Quando o navegador abrir, faça login no Databricks.
6. Autorize o acesso solicitado.
7. Volte para o VS Code.
8. Confirme que a extensão mostra o workspace conectado.

Evite usar Personal Access Token como primeira opção. Ele ainda pode existir em alguns fluxos, mas a Databricks recomenda OAuth para a extensão.

## 8. Selecionar workspace e compute

No painel `Configuration` da extensão:

1. Confirme o workspace alvo.
2. Verifique se a extensão reconheceu o host correto.
3. Na área de compute, selecione serverless quando disponível.

Na Free Edition, lembre-se:

- o ambiente é serverless-only;
- Databricks SQL warehouses não são o alvo principal da extensão;
- recursos como clusters customizados e GPUs não estão disponíveis;
- alguns exemplos antigos da extensão podem mencionar clusters, mas isso não representa o fluxo ideal para Free Edition.

## 9. Sincronizar a pasta local com o Databricks

A extensão cria e gerencia uma pasta remota no workspace Databricks.

1. No painel `Configuration`, localize `Remote Folder`.
2. Clique no ícone de sincronização.
3. Aguarde a sincronização inicial.
4. Use o link externo, se quiser abrir a pasta remota no navegador.

Ponto importante:

```text
VS Code local -> Workspace remoto
```

A sincronização automática é unidirecional. Edite os arquivos localmente no VS Code. Não trate a pasta remota como fonte principal de edição.

## 10. Criar um arquivo Python de teste

Crie um arquivo chamado `hello_databricks.py`:

```python
from pyspark.sql import functions as F

df = spark.range(10).withColumn("dobro", F.col("id") * 2)
display(df)
```

Esse código usa a sessão Spark disponível no Databricks. Ele não deve ser executado como Python local puro, porque depende de `spark` e `display`.

## 11. Executar no Databricks

Com o arquivo aberto no VS Code:

1. Clique no ícone `Run on Databricks` no editor, se aparecer.
2. Escolha `Run File as Workflow` ou opção equivalente de workflow/job.
3. Aguarde a aba `Databricks Job Run`.
4. Veja o output no VS Code.
5. Clique no link do job run para abrir a execução no workspace Databricks.

Se a opção `Upload and Run File` aparecer, ela pode depender de cluster. Para Free Edition, prefira executar como workflow/job usando serverless.

## 12. Trabalhar com notebooks Databricks em arquivo `.py`

Você também pode criar notebooks Databricks em formato source file.

Exemplo:

```python
# Databricks notebook source
# MAGIC %md
# MAGIC # Primeiro notebook via VS Code

# COMMAND ----------

df = spark.range(5)
display(df)

# COMMAND ----------

print("Executado no Databricks")
```

Esse formato permite versionar notebooks como texto no Git.

Para executar:

1. Abra o arquivo `.py`.
2. Use `Run File as Workflow`.
3. Acompanhe o resultado na aba criada pela extensão.

## 13. Estrutura simples de projeto para aula

Uma estrutura mínima para demonstração:

```text
databricks-free-vscode-demo/
  databricks.yml
  hello_databricks.py
  notebooks/
    01_primeiro_notebook.py
  src/
    exemplo_transformacao.py
  README.md
```

Use `notebooks/` para aulas e experimentos.

Use `src/` para código Python reutilizável.

Use `README.md` para instruções do projeto.

## 14. Boas práticas

- Edite arquivos no VS Code, não na pasta remota sincronizada.
- Versione arquivos `.py`, `.sql`, `.yml` e `.md` no Git.
- Não versione `.databricks/` se a extensão adicionou essa pasta ao `.gitignore`.
- Prefira OAuth interativo para login.
- Use nomes simples de projeto e pastas sem espaços.
- Mantenha exemplos pequenos na Free Edition para evitar quota.
- Prefira notebooks em formato `.py` quando quiser revisar mudanças no Git.
- Evite depender de recursos enterprise em uma aula focada na Free Edition.

## 15. Problemas comuns

### A extensão não conecta

Verifique:

- se a URL do workspace está correta;
- se você está logado no navegador;
- se o perfil OAuth foi criado;
- se você autorizou o acesso no navegador;
- se o VS Code foi reiniciado após instalar a extensão.

### A execução não aparece

Verifique:

- se o arquivo está dentro do projeto Databricks ativo;
- se a extensão selecionou o projeto correto;
- se a pasta local foi sincronizada;
- se há quota disponível na Free Edition;
- se você escolheu uma opção compatível com serverless.

### O código funciona no Databricks, mas não localmente

Isso é esperado quando o código usa objetos como:

```python
spark
dbutils
display
```

Esses objetos existem no runtime Databricks. Para executar localmente, você precisa separar a lógica Python pura da lógica dependente do Spark/Databricks ou configurar Databricks Connect quando fizer sentido.

### Alterei no workspace remoto e não voltou para o VS Code

A sincronização automática da extensão é pensada principalmente do local para o remoto.

Considere a pasta local como fonte de verdade.

## 16. Roteiro de demonstração em aula

1. Mostrar o workspace Free Edition no navegador.
2. Explicar que o compute é serverless e quota-limited.
3. Abrir o VS Code.
4. Instalar ou mostrar a extensão Databricks.
5. Criar um projeto simples.
6. Fazer login via OAuth.
7. Confirmar o workspace conectado.
8. Ativar a sincronização.
9. Criar `hello_databricks.py`.
10. Executar como workflow/job.
11. Abrir o job run no navegador.
12. Mostrar que o arquivo local foi sincronizado para o workspace.
13. Explicar a diferença entre editar localmente e executar remotamente.

## 17. Próximo passo: explorar o ambiente conectado

Depois que a conexão com o workspace estiver funcionando, a aula pode mudar de foco: em vez de apenas "rodar um arquivo", mostre como pensar pragmaticamente dentro de um ambiente Databricks real.

A mensagem para os alunos é:

```text
Antes de construir, investigue.
Antes de alterar, entenda.
Antes de automatizar, descubra como o ambiente está organizado.
```

### O que explorar primeiro

Use a extensão como ponto de partida para responder perguntas básicas:

- Em qual workspace estou conectado?
- Qual usuário está autenticado?
- Qual catalog e schema estão ativos?
- Quais catalogs existem?
- Quais schemas existem?
- Quais tabelas, views e volumes já existem?
- Há jobs/workflows configurados?
- Há pipelines ou bundles no projeto?
- Onde meus arquivos locais estão sendo sincronizados no workspace?

Esse tipo de exploração ajuda o aluno a sair do modo "copiar comando" e entrar no modo "entender o ambiente".

### Checklist de exploração no VS Code

No painel da extensão Databricks, mostre:

- `Configuration`: workspace, autenticação, compute e pasta remota;
- `Remote Folder`: onde o projeto local foi sincronizado;
- execução de arquivo/notebook como workflow/job;
- link para abrir o job run no navegador;
- arquivos de configuração criados no projeto, como `databricks.yml`;
- se houver bundle, a visão de recursos do bundle.

Explique que a extensão é potente porque ela aproxima três camadas:

- código local no VS Code;
- metadados e execução no Databricks;
- versionamento e automação via arquivos do projeto.

### Notebook de exploração do ambiente

Crie um arquivo chamado `notebooks/02_explorar_ambiente.py`:

```python
# Databricks notebook source
# MAGIC %md
# MAGIC # Explorando o ambiente Databricks
# MAGIC
# MAGIC Este notebook faz uma inspeção inicial do workspace, do usuário, do catalog atual e dos objetos disponíveis.

# COMMAND ----------

current_user = spark.sql("SELECT current_user() AS user").first()["user"]
current_catalog = spark.sql("SELECT current_catalog() AS catalog").first()["catalog"]
current_schema = spark.sql("SELECT current_schema() AS schema").first()["schema"]

print(f"Usuário: {current_user}")
print(f"Catalog atual: {current_catalog}")
print(f"Schema atual: {current_schema}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Catalogs disponíveis

# COMMAND ----------

display(spark.sql("SHOW CATALOGS"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schemas do catalog atual

# COMMAND ----------

display(spark.sql(f"SHOW SCHEMAS IN {current_catalog}"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tabelas e views visíveis no catalog atual

# COMMAND ----------

tables_df = spark.sql(f"""
SELECT
  table_catalog,
  table_schema,
  table_name,
  table_type,
  created,
  last_altered
FROM {current_catalog}.information_schema.tables
ORDER BY table_schema, table_name
""")

display(tables_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Volumes visíveis no catalog atual

# COMMAND ----------

volumes_df = spark.sql(f"""
SELECT
  volume_catalog,
  volume_schema,
  volume_name,
  volume_type,
  created,
  last_altered
FROM {current_catalog}.information_schema.volumes
ORDER BY volume_schema, volume_name
""")

display(volumes_df)
```

Esse notebook é intencionalmente **read-only**. Ele consulta metadados, mas não cria, altera nem remove objetos.

### Perguntas para fazer durante a demonstração

Use perguntas simples para ensinar raciocínio prático:

- "Se eu não sei onde estou, qual comando me mostra o catalog atual?"
- "Se eu quero evitar mexer no lugar errado, o que preciso verificar antes?"
- "Como descubro quais tabelas já existem antes de criar uma nova?"
- "Como diferencio tabela, view e volume?"
- "O que está no projeto local e o que está no workspace remoto?"
- "Se a execução falhou, eu olho primeiro no VS Code, no job run ou no código?"

Essas perguntas ensinam o aluno a diagnosticar, não apenas seguir receita.

### Comandos úteis para investigação

```sql
SELECT current_user();
SELECT current_catalog();
SELECT current_schema();
SHOW CATALOGS;
SHOW SCHEMAS IN main;
SHOW TABLES IN main.default;
DESCRIBE TABLE EXTENDED main.default.nome_da_tabela;
```

Com `information_schema`:

```sql
SELECT *
FROM main.information_schema.tables
ORDER BY table_schema, table_name;

SELECT *
FROM main.information_schema.volumes
ORDER BY volume_schema, volume_name;
```

Para uma primeira olhada em uma tabela:

```sql
SELECT *
FROM main.default.nome_da_tabela
LIMIT 10;
```

### Regra prática para alunos

Antes de qualquer alteração no Databricks, siga esta ordem:

1. Identifique o workspace.
2. Identifique o usuário.
3. Identifique o catalog.
4. Identifique o schema.
5. Liste os objetos existentes.
6. Leia uma amostra pequena.
7. Só depois crie, altere ou automatize.

Essa disciplina evita erros comuns, principalmente em ambientes compartilhados.

### Como conectar isso à potência da extensão

Mostre que a extensão não serve apenas para "dar run". Ela permite trabalhar como engenheiro:

- o código fica local, versionado e revisável;
- a execução acontece no Databricks;
- os metadados do ambiente podem ser investigados por notebooks e SQL;
- cada execução gera rastreabilidade no workspace;
- o aluno aprende a navegar entre VS Code, job run, workspace e Unity Catalog.

Esse é o ponto central da aula: a extensão transforma o VS Code em uma estação de trabalho para explorar, desenvolver e operar Databricks de forma mais profissional.

## 18. Mensagem final da aula

A extensão Databricks para VS Code não transforma o Databricks em uma ferramenta local. Ela integra dois mundos:

- o VS Code como ambiente de desenvolvimento, edição, Git e organização de projeto;
- o Databricks como ambiente remoto de execução, Spark, serverless compute e workspace.

Para quem está aprendendo na Free Edition, esse fluxo é uma ponte entre notebooks exploratórios e projetos de dados mais profissionais.

## Fontes oficiais

- Databricks Free Edition: https://docs.databricks.com/aws/en/getting-started/free-edition
- Limites da Databricks Free Edition: https://docs.databricks.com/aws/en/getting-started/free-edition-limitations
- Extensão Databricks para VS Code: https://docs.databricks.com/aws/en/dev-tools/vscode-ext
- Instalar a extensão Databricks para VS Code: https://docs.databricks.com/aws/en/dev-tools/vscode-ext/install
- Autenticação da extensão Databricks para VS Code: https://docs.databricks.com/aws/en/dev-tools/vscode-ext/authentication
- Configurar projeto com a extensão: https://docs.databricks.com/aws/en/dev-tools/vscode-ext/configure
- Executar arquivos e notebooks com a extensão: https://docs.databricks.com/aws/en/dev-tools/vscode-ext/run
