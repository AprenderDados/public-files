# Arquitetura do Projeto

## Visão geral

O projeto é dividido em três módulos com responsabilidades completamente separadas.

O **gerador auxiliar** (`src/incremental_sales_generator`) produz arquivos Parquet que simulam a chegada incremental de eventos de venda e full extracts de dimensões. Ele mantém estado operacional em tabelas Delta para garantir IDs únicos e rastreabilidade de cada batch gerado.

O **projeto declarative Python** (`src/course_lakeflow`) lê esses arquivos, os promove por três camadas e publica métricas analíticas usando assets Python.

O **projeto declarative SQL** (`sql_pipeline/`) implementa o mesmo fluxo em SQL puro. A organização é intencionalmente mais granular: uma tabela por arquivo `.sql`, agrupada por camada em `bronze/`, `silver/` e `gold/`.

Essa separação garante que cada módulo possa evoluir de forma independente e deixa explícita, para o aluno, a diferença entre duas abordagens declarative sobre a mesma origem.

---

## Camada Bronze

**Responsabilidade:** ingestão bruta com schema tipado e metadados de rastreabilidade.

O Auto Loader lê os arquivos Parquet dos Volumes com schema explícito definido em YAML. Isso garante que tipos errados na origem não contaminem as camadas seguintes de forma silenciosa — a coluna `_rescued_data` captura qualquer valor que não encaixe no schema esperado.

Cinco colunas operacionais são adicionadas a cada registro:

| Coluna | Origem | Finalidade |
|---|---|---|
| `ingestion_ts` | `current_timestamp()` | Quando o registro chegou na bronze |
| `source_file_path` | `_metadata.file_path` | Caminho completo do arquivo de origem |
| `source_file_modification_time` | `_metadata.file_modification_time` | Timestamp do arquivo na origem |
| `source_file_name` | extraído do caminho | Nome do arquivo |
| `source_batch_id` | extraído da pasta do batch | Identificador do batch de geração |

Tabelas de dimensão chegam como full extracts append-only. Cada batch traz o snapshot completo da dimensão com um `extract_batch_id` e `extract_ts` únicos. A bronze acumula todos os batches; a silver decide qual publicar.

---

## Camada Silver

**Responsabilidade:** qualidade declarativa, normalização e publicação de estado corrente.

### Dimensões — current-state

A silver não publica todos os batches acumulados na bronze. Ela filtra pelo batch mais recente e publica apenas o estado corrente da dimensão. A lógica de seleção do último batch é determinística: agrupa por `extract_batch_id` e seleciona o maior valor de `extract_ts`.

Isso tem uma consequência importante: deleções são naturais. Se uma chave sumiu do último full extract, ela desaparece da silver. Não é necessário CDC nem marcadores de deleção.

### Fatos — ledger incremental

Os eventos de venda chegam como ledger incremental. A silver aplica três etapas em sequência:

1. **Filtro de rescue** — descarta linhas onde `_rescued_data` é não-nulo. Essas linhas tiveram problemas no schema e não devem avançar.
2. **Normalização** — padroniza `event_type` e `currency_code` para maiúsculas, arredonda valores monetários.
3. **Deduplicação** — remove duplicatas pelo `sales_event_id`. Em caso de conflito, mantém a ocorrência mais recente por `extract_ts`, `source_file_modification_time` e `ingestion_ts`.

### Expectations declarativas

Cada tabela silver tem um conjunto de expectations configuradas em YAML. Cada expectation define:

- **nome** — identificador da regra
- **expressão SQL** — condição que o dado deve satisfazer
- **ação** — `warn` (registra e passa), `drop` (descarta a linha) ou `fail` (para a pipeline)

Exemplo de expectation do fato de vendas:

```yaml
- name: valid_event_type
  expression: "event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')"
  action: drop
```

---

## Camada Gold

**Responsabilidade:** publicar ativos analíticos prontos para consumo.

### Dimensões conformadas

A gold junta informações de múltiplas tabelas silver para construir dimensões conformadas enriquecidas.

**`gold_dim_product`** — reúne produto, subcategoria, categoria, modelo e descrição em cultura padrão. Resultado: 12 colunas com hierarquia completa de produto.

**`gold_dim_customer`** — reúne cliente, pessoa, endereço, estado/província, território e, quando aplicável, loja. Todos os joins são left (outer) para garantir que eventos de venda com dados de cliente incompletos continuem presentes.

### One Big Table analítica

**`gold_sales_analytics_obt`** — enriquece cada evento de venda com todas as colunas de produto e cliente conformadas. Fica no grão do evento individual. Serve como base para análise exploratória e construção de dashboards sem precisar de joins adicionais.

### Métricas agregadas

| Tabela | Grão | Conteúdo |
|---|---|---|
| `gold_daily_sales` | data de negócio | quantidade líquida, receita líquida, contagem de eventos |
| `gold_daily_sales_by_product` | data × produto | mesmas métricas com breakdown de produto e categoria |
| `gold_arrival_vs_business_date` | data de chegada × data de negócio | análise de latência e chegadas tardias |
| `gold_correction_impact` | data de chegada × data de negócio × tipo | impacto de ajustes e cancelamentos |

---

## Gerador auxiliar

**Responsabilidade:** produzir dados sintéticos que simulem um fluxo real.

### Dimensões

O gerador exporta cada dimensão com um SQL configurado em YAML contra a fonte Federated (AdventureWorks). Cada batch de dimensão gera um diretório Parquet coalesce(1) com `extract_batch_id` embutido no nome da pasta.

### Fatos

O gerador de fatos produz três tipos de evento num único arquivo por batch:

- **`SALE`** — evento original de venda, amostrado da base real com heurísticas de dia da semana e mix de produto.
- **`ADJUSTMENT`** — correção de quantidade ou valor de um `SALE` anterior. Referencia o evento original pelo `reference_event_id`. Pode chegar com dias de atraso.
- **`CANCEL`** — cancelamento total de um `SALE`. Mesma lógica de referência e latência.

O identificador do batch segue o padrão:

```
{env}_fact_sales_events_arrival_{yyyymmdd}_sales_{yyyymmdd}_{hhmmss}
```

### Estado operacional

O gerador mantém três tabelas de estado em Delta:

| Tabela | Finalidade |
|---|---|
| `generation_state` | próximos IDs a usar (`sales_event_id`, `order_id`, `order_line_id`) + última data de negócio |
| `generation_manifest` | log de todos os batches gerados com parâmetros e contagens |
| `sales_event_registry` | audit log completo de todos os eventos gerados |

E três tabelas de perfil estatístico:

| Tabela | Finalidade |
|---|---|
| `sales_profile_weekday` | fator relativo de volume por dia da semana |
| `sales_profile_product_mix` | participação histórica de cada produto nas vendas |
| `sales_profile_territory_mix` | distribuição histórica por território |

---

## Configuração declarativa

Toda a parametrização do projeto — schemas, tipos de coluna, regras de qualidade, chaves de deduplicação, paths lógicos — vive em arquivos YAML sob `config/`.

A estrutura segue herança por ambiente:

```
config/environments/base.yml        # configurações padrão
config/environments/dev.yml         # overrides para desenvolvimento
config/environments/acc.yml         # overrides para homologação
config/environments/prd.yml         # overrides para produção
```

O `ConfigLoader` aplica merge entre base e ambiente, com uma política shallow explícita que evita mesclagens acidentais de listas.

Os specs de tabela vivem em `config/tables/{camada}/{nome}.yml` e definem:

- `fields` — lista de campos com nome, tipo e nulabilidade
- `quality_rules` — lista de expectations com nome, expressão e ação
- `business_keys` — chaves usadas para deduplicação
- `path_ref` e `file_format` — configuração de leitura

O `spark_schema.py` converte os tipos YAML em `StructType` do Spark. O `ResolvedProjectContext` resolve nomes lógicos (como `volume:raw_data`) para caminhos físicos no Unity Catalog.

---

## Tradeoffs assumidos

**Current-state na gold**
A gold enriquece fatos com o estado atual das dimensões, não com o estado "as-of" da data de venda. Isso significa que `product_name` reflete o nome atual, não o nome na data em que a venda ocorreu. A decisão é intencional: evitar SCD2 mantém o projeto focado nos padrões de ingestão e qualidade.

**Parquet como formato de troca**
Os arquivos gerados usam Parquet para reduzir tempo de escrita, custo de leitura e fragilidade de parsing. O projeto continua simples didaticamente porque cada batch permanece isolado em uma pasta identificada.

**Coalesce(1) no gerador**
Cada batch de dimensão gera um único part-file Parquet dentro de uma pasta de batch. Isso simplifica o schema de naming e a leitura no Auto Loader, ao custo de paralelismo de escrita no gerador — aceitável para o volume didático.

**Todos os joins são left na gold**
A gold usa left join em todos os enriquecimentos de fato com dimensão. Isso garante que eventos de venda com dados de dimensão ausentes ou incompletos ainda apareçam nos resultados, mesmo que com valores nulos nos campos de enriquecimento.
