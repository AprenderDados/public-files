# Modelo de Dados — Spark Declarative Pipelines

## Contexto de negócio

Este projeto modela o processo de vendas de uma empresa fabricante de artigos esportivos (baseado no conjunto de dados AdventureWorks da Microsoft). A empresa vende produtos diretamente a clientes individuais e por meio de lojas parceiras em múltiplos territórios.

Os dados de venda chegam como eventos incrementais: cada venda gera um evento do tipo `SALE`. Correções posteriores de valor ou quantidade geram eventos do tipo `ADJUSTMENT`. Cancelamentos geram eventos do tipo `CANCEL`. Essa estrutura de ledger incremental permite rastrear não só o que foi vendido, mas quando os dados chegaram e quais correções foram feitas após o fato.

Os dados de produto, cliente e geografia chegam como extratos completos periódicos. O estado corrente de cada dimensão é o que importa para análise — não há necessidade de rastrear histórico de atributos de dimensão neste modelo.

---

## Domínio de dimensões

### Produto

O catálogo de produtos tem quatro níveis hierárquicos:

```
Categoria
  └── Subcategoria
        └── Produto
              └── Modelo (com descrição em cultura padrão)
```

**Categoria de produto** (`production_productcategory`)
Nível mais alto da hierarquia. Exemplos de categorias: `Bikes`, `Components`, `Clothing`, `Accessories`.

| Campo | Tipo | Descrição |
|---|---|---|
| `product_category_id` | INT | Chave primária da categoria |
| `name` | STRING | Nome da categoria |

**Subcategoria de produto** (`production_productsubcategory`)
Refinamento da categoria. Exemplos: `Mountain Bikes`, `Road Bikes`, `Helmets`.

| Campo | Tipo | Descrição |
|---|---|---|
| `product_subcategory_id` | INT | Chave primária da subcategoria |
| `product_category_id` | INT | Referência à categoria pai |
| `name` | STRING | Nome da subcategoria |

**Produto** (`production_product`)
Unidade comercializável. Cada produto tem um código, preço de lista e custo padrão.

| Campo | Tipo | Descrição |
|---|---|---|
| `product_id` | INT | Chave primária do produto |
| `name` | STRING | Nome do produto |
| `product_number` | STRING | Código de referência interno |
| `color` | STRING | Cor (pode ser nulo) |
| `standard_cost` | DECIMAL(19,4) | Custo de produção padrão |
| `list_price` | DECIMAL(19,4) | Preço de lista ao cliente |
| `size` | STRING | Tamanho (quando aplicável) |
| `weight` | DECIMAL(8,2) | Peso em kg (quando aplicável) |
| `product_subcategory_id` | INT | Referência à subcategoria |

**Modelo de produto** (`production_productmodel`)
Agrupa variantes de um mesmo modelo (ex: diferentes cores e tamanhos do mesmo produto).

| Campo | Tipo | Descrição |
|---|---|---|
| `product_model_id` | INT | Chave primária do modelo |
| `name` | STRING | Nome do modelo |

**Descrição de produto** (`production_productdescription` + `production_productmodelproductdescriptionculture`)
Texto descritivo do produto associado a um modelo e cultura (idioma). Este projeto usa a cultura `en` como padrão.

| Campo | Tipo | Descrição |
|---|---|---|
| `product_description_id` | INT | Chave primária da descrição |
| `description` | STRING | Texto descritivo do produto |
| `product_model_id` | INT | Referência ao modelo |
| `culture_id` | STRING | Código de cultura (ex: `en`) |

---

### Cliente

O modelo de cliente distingue dois perfis: clientes individuais (pessoa física) e lojas (pessoa jurídica).

**Cliente** (`sales_customer`)
Entidade central do relacionamento comercial. Cada cliente tem uma pessoa associada ou uma loja associada.

| Campo | Tipo | Descrição |
|---|---|---|
| `customer_id` | INT | Chave primária do cliente |
| `person_id` | INT | Referência à pessoa (quando cliente direto) |
| `store_id` | INT | Referência à loja (quando cliente via loja) |
| `territory_id` | INT | Referência ao território de venda |

**Pessoa** (`person_person`)
Dados individuais de nome e tipo de pessoa.

| Campo | Tipo | Descrição |
|---|---|---|
| `business_entity_id` | INT | Chave primária da pessoa |
| `person_type` | STRING | Tipo (`IN` = individual, `SC` = contato de loja, etc.) |
| `first_name` | STRING | Primeiro nome |
| `middle_name` | STRING | Nome do meio (pode ser nulo) |
| `last_name` | STRING | Sobrenome |
| `email_promotion` | INT | Indica preferência de contato por email |
| `suffix` | STRING | Sufixo de nome (pode ser nulo) |

**Loja** (`sales_store`)
Informações de lojas parceiras quando o cliente é pessoa jurídica.

| Campo | Tipo | Descrição |
|---|---|---|
| `business_entity_id` | INT | Chave primária da loja |
| `name` | STRING | Nome da loja |
| `sales_person_id` | INT | Vendedor responsável (pode ser nulo) |
| `demographics` | STRING | Dados demográficos em XML (não processados neste projeto) |

---

### Endereço e Geografia

**Endereço** (`person_address`)
Endereço físico usado como referência de localização do cliente.

| Campo | Tipo | Descrição |
|---|---|---|
| `address_id` | INT | Chave primária do endereço |
| `address_line_1` | STRING | Primeira linha do endereço |
| `address_line_2` | STRING | Segunda linha (pode ser nulo) |
| `city` | STRING | Cidade |
| `state_province_id` | INT | Referência ao estado/província |
| `postal_code` | STRING | CEP ou código postal |

**Ponte de endereço de entidade** (`person_businessentityaddress`)
Associação entre entidades de negócio (pessoas, lojas) e seus endereços. Uma entidade pode ter múltiplos endereços com tipos diferentes (ex: faturamento, entrega).

| Campo | Tipo | Descrição |
|---|---|---|
| `business_entity_id` | INT | Referência à entidade (pessoa ou loja) |
| `address_id` | INT | Referência ao endereço |
| `address_type_id` | INT | Tipo do endereço |

**Estado/Província** (`person_stateprovince`)
Subdivisão geográfica de primeiro nível abaixo do país.

| Campo | Tipo | Descrição |
|---|---|---|
| `state_province_id` | INT | Chave primária do estado/província |
| `state_province_code` | STRING | Código de duas letras (ex: `WA`, `CA`) |
| `country_region_code` | STRING | Código do país (ex: `US`, `CA`) |
| `name` | STRING | Nome completo do estado ou província |
| `territory_id` | INT | Referência ao território de venda |

**País/Região** (`person_countryregion`)
Referência de países e regiões.

| Campo | Tipo | Descrição |
|---|---|---|
| `country_region_code` | STRING | Código do país (ex: `US`) |
| `name` | STRING | Nome do país ou região |

---

### Território de Vendas

**Território** (`sales_salesterritory`)
Unidades geográficas de gestão comercial. Cada território tem métricas de desempenho histórico e está associado a uma região geográfica.

| Campo | Tipo | Descrição |
|---|---|---|
| `territory_id` | INT | Chave primária do território |
| `name` | STRING | Nome do território (ex: `Northwest`, `Canada`) |
| `country_region_code` | STRING | Código do país do território |
| `group_name` | STRING | Grupo regional (ex: `North America`, `Europe`) |
| `sales_ytd` | DECIMAL(19,4) | Vendas acumuladas no ano (histórico) |

---

## Fato de eventos de venda

### Visão geral

O fato central do modelo é um ledger de eventos de venda. Cada linha representa uma ocorrência de negócio — venda, ajuste ou cancelamento — com as datas de negócio e de chegada dos dados registradas separadamente.

| Campo | Tipo | Descrição |
|---|---|---|
| `sales_event_id` | LONG | Identificador único do evento |
| `order_id` | LONG | Identificador do pedido ao qual o evento pertence |
| `order_line_id` | LONG | Identificador da linha do pedido |
| `event_type` | STRING | Tipo do evento: `SALE`, `ADJUSTMENT` ou `CANCEL` |
| `sales_date` | DATE | Data de negócio — quando a venda ocorreu |
| `arrival_date` | DATE | Data de chegada — quando o dado chegou no sistema |
| `product_id` | INT | Referência ao produto |
| `customer_id` | INT | Referência ao cliente |
| `territory_id` | INT | Referência ao território |
| `quantity_delta` | INT | Variação de quantidade (negativo para cancelamentos e ajustes de redução) |
| `amount_delta` | DECIMAL(19,4) | Variação de valor monetário (negativo para cancelamentos e reduções) |
| `currency_code` | STRING | Código da moeda (ex: `USD`) |
| `reference_event_id` | LONG | Referência ao evento original (preenchido em `ADJUSTMENT` e `CANCEL`) |

### Tipos de evento

**`SALE`** — evento original de venda
Representa uma venda realizada. `quantity_delta` é positivo. `amount_delta` é positivo. `reference_event_id` é nulo.

**`ADJUSTMENT`** — correção de valor ou quantidade
Representa uma correção aplicada a uma venda anterior. Pode ser positivo ou negativo dependendo da natureza da correção. `reference_event_id` aponta para o `sales_event_id` do `SALE` original. Pode chegar dias depois da venda original.

**`CANCEL`** — cancelamento
Representa o cancelamento completo de uma venda. `quantity_delta` é o negativo da venda original. `amount_delta` é o negativo do valor original. `reference_event_id` aponta para o `SALE` cancelado.

### Regras de qualidade aplicadas na silver

| Regra | Expressão | Ação |
|---|---|---|
| `valid_event_type` | `event_type IN ('SALE', 'ADJUSTMENT', 'CANCEL')` | drop |
| `non_null_sales_event_id` | `sales_event_id IS NOT NULL` | fail |
| `non_null_product_id` | `product_id IS NOT NULL` | drop |
| `non_null_customer_id` | `customer_id IS NOT NULL` | drop |
| `non_null_territory_id` | `territory_id IS NOT NULL` | drop |
| `valid_date_order` | `arrival_date >= sales_date` | warn |
| `non_zero_quantity` | `quantity_delta <> 0` | drop |
| `valid_currency_code` | `length(currency_code) = 3` | warn |

---

## Camada Gold — ativos analíticos

### Dimensão conformada de produto

**`gold_dim_product`** — visão unificada do produto com hierarquia completa.

| Campo | Origem |
|---|---|
| `product_id` | `silver_dim_production_product_current` |
| `product_name` | produto |
| `product_number` | produto |
| `color` | produto |
| `standard_cost` | produto |
| `list_price` | produto |
| `size` | produto |
| `weight` | produto |
| `subcategory_name` | subcategoria |
| `category_name` | categoria |
| `model_name` | modelo |
| `product_description` | descrição em `en` |

### Dimensão conformada de cliente

**`gold_dim_customer`** — visão unificada do cliente com pessoa, endereço e território.

| Campo | Origem |
|---|---|
| `customer_id` | `silver_dim_sales_customer_current` |
| `person_id` | cliente |
| `store_id` | cliente |
| `territory_id` | cliente |
| `first_name` | pessoa |
| `middle_name` | pessoa |
| `last_name` | pessoa |
| `person_type` | pessoa |
| `store_name` | loja (quando aplicável) |
| `address_line_1` | endereço |
| `city` | endereço |
| `postal_code` | endereço |
| `state_province_name` | estado/província |
| `country_region_code` | país |
| `territory_name` | território |
| `territory_group` | território |

### One Big Table analítica

**`gold_sales_analytics_obt`** — evento de venda enriquecido com todas as dimensões. Grão: evento individual.

Reúne as 13 colunas do evento de venda com as 12 colunas de produto conformado e as 17 colunas de cliente conformado. Destinado a consumo analítico direto sem joins adicionais.

### Métricas agregadas

**`gold_daily_sales`** — totais diários de vendas.

| Campo | Tipo | Descrição |
|---|---|---|
| `sales_date` | DATE | Data de negócio |
| `net_quantity` | LONG | Soma de `quantity_delta` (inclui ajustes e cancelamentos) |
| `net_revenue` | DECIMAL | Soma de `amount_delta` |
| `event_count` | LONG | Total de eventos na data |
| `correction_event_count` | LONG | Total de eventos do tipo `ADJUSTMENT` ou `CANCEL` |

**`gold_daily_sales_by_product`** — totais diários com breakdown de produto.

| Campo | Tipo | Descrição |
|---|---|---|
| `sales_date` | DATE | Data de negócio |
| `product_id` | INT | Produto |
| `product_name` | STRING | Nome do produto |
| `category_name` | STRING | Categoria do produto |
| `net_quantity` | LONG | Quantidade líquida |
| `net_revenue` | DECIMAL | Receita líquida |
| `event_count` | LONG | Total de eventos |
| `correction_event_count` | LONG | Total de correções |

**`gold_arrival_vs_business_date`** — análise de latência de chegada de dados.

Agrupa por `arrival_date` e `sales_date` para identificar eventos que chegaram com atraso. Um evento chegou tarde quando `arrival_date > sales_date`.

| Campo | Tipo | Descrição |
|---|---|---|
| `arrival_date` | DATE | Data de chegada do dado |
| `sales_date` | DATE | Data de negócio da venda |
| `event_count` | LONG | Total de eventos no cruzamento |
| `net_quantity` | LONG | Quantidade líquida |
| `net_revenue` | DECIMAL | Receita líquida |
| `late_events_count` | LONG | Eventos onde `arrival_date > sales_date` |

**`gold_correction_impact`** — impacto de ajustes e cancelamentos.

Agrupa por `arrival_date`, `sales_date` e `event_type` para quantificar o efeito de correções tardias sobre a receita e quantidade.

| Campo | Tipo | Descrição |
|---|---|---|
| `arrival_date` | DATE | Data de chegada da correção |
| `sales_date` | DATE | Data de negócio da venda original |
| `event_type` | STRING | `ADJUSTMENT` ou `CANCEL` |
| `correction_count` | LONG | Número de eventos de correção |
| `quantity_impact` | LONG | Variação total de quantidade |
| `revenue_impact` | DECIMAL | Variação total de receita |

---

## Regras de negócio aplicadas nas joins e agregações

### Joins da dimensão conformada de produto

- Join entre produto e subcategoria: `product.product_subcategory_id = subcategory.product_subcategory_id` (LEFT JOIN)
- Join entre subcategoria e categoria: `subcategory.product_category_id = category.product_category_id` (LEFT JOIN)
- Join entre produto e modelo: `product.product_model_id = model.product_model_id` (LEFT JOIN, quando disponível)
- Join entre modelo e descrição: `model.product_model_id = desc_culture.product_model_id AND desc_culture.culture_id = 'en'` (LEFT JOIN)

O uso de LEFT JOIN em todos os níveis garante que produtos sem subcategoria, categoria ou descrição ainda apareçam nas dimensões conformadas, com valores nulos nos campos ausentes.

### Joins da dimensão conformada de cliente

- Join cliente-pessoa: `customer.person_id = person.business_entity_id` (LEFT JOIN)
- Join cliente-loja: `customer.store_id = store.business_entity_id` (LEFT JOIN, apenas quando store_id não é nulo)
- Join pessoa-endereço via bridge: `person.business_entity_id = bridge.business_entity_id` (LEFT JOIN, primeiro endereço por address_type_id)
- Join endereço-estado/província: `address.state_province_id = state.state_province_id` (LEFT JOIN)
- Join estado-país: `state.country_region_code = country.country_region_code` (LEFT JOIN)
- Join cliente-território: `customer.territory_id = territory.territory_id` (LEFT JOIN)

### Filtros aplicados na OBT e métricas

- Todos os tipos de evento (`SALE`, `ADJUSTMENT`, `CANCEL`) são incluídos.
- Não há filtro de exclusão de territórios ou produtos.
- Métricas líquidas (`net_quantity`, `net_revenue`) somam todos os `quantity_delta` e `amount_delta`, inclusive valores negativos de ajustes e cancelamentos.
- A coluna `correction_event_count` conta apenas eventos com `event_type IN ('ADJUSTMENT', 'CANCEL')`.
