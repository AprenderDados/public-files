# Workspace Direto Sem Bundle

Este guia cobre o caso em que o aluno não vai usar Databricks Asset Bundles e vai subir o projeto diretamente no workspace.

## Ponto importante

Para este projeto, **um `.dbc` sozinho não é suficiente**.

O motivo é simples: o projeto não depende apenas de notebooks. Ele também depende de:

- arquivos Python em `src/`
- configurações YAML em `config/`
- JSON de dashboard em `dashboards/`
- documentação auxiliar em `docs/`

Se o aluno importar apenas notebooks, os imports locais e a leitura de configuração vão falhar.

## Forma recomendada de distribuir

Escolha uma destas opções:

1. **Workspace files**
   Suba a pasta inteira do projeto para o workspace preservando a estrutura de diretórios.

2. **Git folder**
   O aluno clona o repositório diretamente no Databricks workspace.

3. **ZIP source com a árvore inteira**
   Aceitável se a estrutura final no workspace ficar igual ao projeto local.

## Quando o `.dbc` ainda faz sentido

Use `.dbc` apenas para material puramente baseado em notebooks, como o conteúdo de `curso/`.

Não use `.dbc` como mecanismo único de distribuição do projeto operacional completo.

## Sequência mínima para rodar sem jobs

Depois de importar o projeto completo no workspace:

1. Rode `notebooks/06_workspace_manual_runbook.py`
2. Rode `notebooks/00_setup_workspace.py`
3. Rode `notebooks/04_bootstrap_sales_profiles.py` *(opcional, mas recomendado)*
4. Rode `notebooks/01_generate_dimension_full.py`
5. Rode `notebooks/02_generate_sales_batch.py`
6. Crie ou atualize a pipeline **Python** manualmente
7. Execute o update da pipeline **Python** pela UI e espere terminar
8. Se quiser validar a versão SQL, crie ou atualize a pipeline **SQL** manualmente
9. Execute o update da pipeline **SQL** só depois de a Python terminar
10. Rode `notebooks/05_validate_dashboard_queries.py`
11. Importe a dashboard pronta de `dashboards/rendered/dev/sales_incremental_monitoring_v1.lvdash.json` ou monte manualmente pela UI

## Criação manual da pipeline

Use o notebook `notebooks/06_workspace_manual_runbook.py` para obter os caminhos exatos do workspace.

Campos importantes da pipeline manual em Python:

- source code: pasta `src/course_lakeflow/pipelines`
- dependency: `--editable /Workspace/.../projeto-spark-declarative-pipelines`
- configuration:
  - `course_sdp.environment=dev`
  - `course_sdp.project_root=/Workspace/.../projeto-spark-declarative-pipelines`

Campos importantes da pipeline manual em SQL:

- source code: pasta `sql_pipeline`
- não precisa dependency Python
- configuration:
  - `course_sdp.environment=dev`
  - `course_sdp.project_root=/Workspace/.../projeto-spark-declarative-pipelines`
  - `course_sdp.sql_fact_source_path=/Volumes/main/sdp_dev_landing/facts_ingest/sales_events_parquet`
  - `course_sdp.sql_dimensions_source_root=/Volumes/main/sdp_dev_landing/dimensions_ingest`

Observação:

- o notebook `03_refresh_pipeline.py` **não** executa o refresh da pipeline
- ele deve ser tratado apenas como scaffold/helper
- o refresh real deve ser feito pela UI da pipeline ou por um job com `pipeline_task`
- neste workspace, a cota observada permite apenas **1 pipeline ativa por vez**
- portanto, rode Python e SQL em sequência, nunca em paralelo

## Criação manual de jobs

Os jobs são opcionais. O caminho mínimo para aula é rodar os notebooks manualmente.

Se o workspace do aluno tiver suporte a jobs, vale criar também um job orquestrador único equivalente ao bundle:

- `Run End-to-End Course Demo`

Ele deve chamar, na ordem:

1. `Setup Course Workspace`
2. `Bootstrap Sales Profiles`
3. `Export Full Dimensions`
4. `Generate Incremental Sales Batch`
5. `Refresh Sales Pipeline`

Se quiser criar jobs na UI, crie estes cinco:

- `Setup Course Workspace`
- `Bootstrap Sales Profiles`
- `Export Full Dimensions`
- `Generate Incremental Sales Batch`
- `Refresh Sales Pipeline`

Os quatro primeiros são jobs de notebook. O último é um job de pipeline.

Todos os jobs de notebook devem usar:

- environment version `2`
- dependências:
  - `pyyaml>=6.0,<7`
  - `pydantic>=2.8,<3`

Se criar um job para `Generate Incremental Sales Batch`, mantenha execução serial:

- `max_concurrent_runs: 1`
- não dispare dois runs em paralelo para o mesmo ambiente

O gerador atualiza tabelas de estado (`generation_state`) e pode sofrer conflito transacional de Delta se duas execuções tentarem avançar os mesmos IDs ao mesmo tempo.

Se criar também jobs para refresh das pipelines:

- rode primeiro `Refresh Sales Pipeline`
- só depois rode `Refresh SQL Sales Pipeline`

No ambiente atual, disparar as duas ao mesmo tempo pode falhar por limite de pipeline ativa no workspace.

## UX recomendada para alunos

Para reduzir erro operacional:

- entregue o projeto como pasta completa, não apenas como `.dbc`
- deixe `notebooks/06_workspace_manual_runbook.py` como primeiro passo
- deixe `notebooks/05_validate_dashboard_queries.py` como último passo antes do dashboard
- trate jobs como opcional; trate notebooks como o caminho obrigatório mínimo
- entregue também [dashboard_student_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/dashboard_student_setup.md:1) como guia de import ou copiar/colar da dashboard
