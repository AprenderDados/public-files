# Dashboard V1

## Objetivo

Criar uma camada visual didática para o projeto, em cima das tabelas `gold` já existentes.

Esta V1 privilegia estabilidade e clareza didática:

- datasets pequenos e pre-agrupados
- SQL validado antes do asset ser adicionado
- múltiplas páginas temáticas, em vez de uma tela única sobrecarregada
- sem metric view como dependência obrigatória

## Datasets usados

- `gold_daily_sales`
- `gold_daily_sales_by_product`
- `gold_arrival_vs_business_date`
- `gold_correction_impact`
- `gold_sales_analytics_obt`

## Páginas e widgets

### Overview

- KPI de receita líquida total
- KPI de total de eventos
- KPI de total de eventos de correção
- gráfico de receita líquida por dia de venda
- gráfico de top produtos por receita
- tabela de `arrival_date` x `sales_date`
- tabela de impacto de correções tardias

### Commercial Mix

- KPI de produtos distintos
- KPI de categorias distintas
- KPI de subcategorias distintas
- gráfico de receita por categoria
- gráfico de receita por subcategoria
- gráfico de top produtos por quantidade
- tabela de portfólio por categoria e subcategoria

### Customers & Territories

- KPI de clientes distintos
- KPI de territórios distintos
- KPI de segmentos distintos
- gráfico de receita por território
- gráfico de receita por segmento
- tabela de top cidades por receita

### Operations & Corrections

- KPI de eventos tardios
- KPI de dias de venda afetados
- KPI de dias de chegada com correção
- gráfico de eventos tardios por dia de chegada
- gráfico de correções por tipo de evento
- tabela de detalhe de chegadas tardias
- tabela de impacto de correção por tipo

## Deployment

O dashboard é controlado como asset de bundle em:

- `resources/dashboards/sales_incremental_monitoring_v1.dashboard.yml`

Os arquivos do dashboard ficam em:

- `dashboards/sales_incremental_monitoring_v1.lvdash.json`
- `dashboards/rendered/dev/sales_incremental_monitoring_v1.lvdash.json`
- `dashboards/rendered/acc/sales_incremental_monitoring_v1.lvdash.json`
- `dashboards/rendered/prd/sales_incremental_monitoring_v1.lvdash.json`

O arquivo raiz funciona como fonte simples de edição. O bundle publica o arquivo renderizado do ambiente alvo, com FQNs explícitos nas tabelas `gold`.

O `warehouse_id` não fica fixo no repositório. Ele é fornecido como variável de bundle no deploy, via `BUNDLE_VAR_dashboard_warehouse_id`, `--var` ou `variable-overrides.json`.

## Validação recomendada

Antes de publicar ou atualizar o dashboard, rode primeiro:

- `notebooks/05_validate_dashboard_queries.py`

Esse notebook:

- prioriza o arquivo renderizado do ambiente, se ele existir
- caso contrário, resolve o catálogo e schema `gold` do ambiente
- qualifica as tabelas `gold_*` com o FQN correto
- executa cada dataset no Spark e mostra preview

Isso separa dois problemas diferentes:

- se a SQL do dataset está errada
- se o asset de dashboard está mal configurado no bundle

## Limitação assumida nesta V1

No desenho inicial, o JSON do dashboard foi mantido genérico e usava `dataset_catalog` e `dataset_schema` do recurso de bundle para apontar para a `gold` do ambiente alvo.

Na prática, esse caminho se mostrou frágil para a resolução das queries no dashboard publicado. Por isso, a solução adotada no projeto passou a ser publicar arquivos renderizados por ambiente, com tabelas fully-qualified.

Isso evita que queries como `FROM gold_daily_sales` dependam do contexto default do warehouse.

Uma evolução natural da V2 seria gerar esses arquivos renderizados a partir do mesmo resolvedor de contexto usado pelo projeto Python, em vez de mantê-los no repositório.
