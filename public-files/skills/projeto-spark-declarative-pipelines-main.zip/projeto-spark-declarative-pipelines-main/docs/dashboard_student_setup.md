# Dashboard para Alunos

Este guia cobre os dois caminhos para um aluno trabalhar com a dashboard `sales_incremental_monitoring_v1`.

Use este material **depois** de:

1. gerar os dados
2. atualizar a pipeline
3. rodar `notebooks/05_validate_dashboard_queries.py`

Se a validação das queries ainda não passou, não faz sentido montar a dashboard antes.

## Escolha rápida

### Opção A: importar a dashboard pronta

Use quando o aluno:

- já está com os dados carregados no ambiente `dev`
- quer a dashboard pronta mais rápido
- subiu a pasta completa do projeto no workspace

Arquivo para importar:

- `dashboards/rendered/dev/sales_incremental_monitoring_v1.lvdash.json`

### Opção B: montar manualmente com SQL

Use quando o aluno:

- quer entender a construção da dashboard
- quer editar datasets na UI
- prefere copiar e colar as queries manualmente

## Opção A: importar o arquivo `.lvdash.json`

O Databricks suporta exportar e importar dashboards AI/BI como arquivo `.lvdash.json`.

Passos:

1. No Databricks, abra a listagem de dashboards
2. Clique em `Import dashboard from file`
3. Selecione um arquivo `.lvdash.json` do seu computador local
4. Use este arquivo:
   - `dashboards/rendered/dev/sales_incremental_monitoring_v1.lvdash.json`
5. Confirme o import
6. Abra a dashboard importada no seu diretório de usuário
7. Se o Databricks pedir compute, selecione um SQL warehouse
8. Atualize os widgets e publique

Observações:

- o diálogo de import usa seletor de arquivo local; se o projeto estiver só no workspace, baixe esse `.lvdash.json` antes
- o arquivo `rendered/dev` já aponta para:
  - `main.sdp_dev_gold.gold_daily_sales`
  - `main.sdp_dev_gold.gold_daily_sales_by_product`
  - `main.sdp_dev_gold.gold_arrival_vs_business_date`
  - `main.sdp_dev_gold.gold_correction_impact`
  - `main.sdp_dev_gold.gold_sales_analytics_obt`
- se o aluno estiver usando outro ambiente, use o arquivo renderizado correspondente:
  - `dashboards/rendered/acc/...`
  - `dashboards/rendered/prd/...`

## Opção B: criar manualmente com copiar e colar

Crie uma dashboard vazia e adicione datasets com os nomes abaixo.

Depois crie os widgets conforme a sugestão de páginas.

## Estrutura sugerida de páginas

### Overview

- `summary` -> counters:
  - `Total Revenue`
  - `Total Events`
  - `Correction Events`
- `daily_sales` -> bar:
  - `Daily Net Revenue`
- `top_products` -> bar:
  - `Top Products by Revenue`
- `arrival_vs_business` -> table:
  - `Arrival vs Business Date`
- `correction_impact` -> table:
  - `Late Correction Impact`

### Commercial Mix

- `commercial_footprint` -> counters:
  - `Distinct Products`
  - `Distinct Categories`
  - `Distinct Subcategories`
- `category_revenue` -> bar:
  - `Revenue by Category`
- `subcategory_revenue` -> bar:
  - `Top Subcategories by Revenue`
- `top_products_by_quantity` -> bar:
  - `Top Products by Quantity`
- `product_portfolio` -> table:
  - `Portfolio by Category and Subcategory`

### Customers & Territories

- `customer_footprint` -> counters:
  - `Distinct Customers`
  - `Distinct Territories`
  - `Distinct Segments`
- `territory_revenue` -> bar:
  - `Revenue by Territory`
- `segment_revenue` -> bar:
  - `Revenue by Customer Segment`
- `top_cities` -> table:
  - `Top Cities by Revenue`

### Operations & Corrections

- `ops_summary` -> counters:
  - `Late Events`
  - `Affected Sales Days`
  - `Correction Arrival Days`
- `late_arrivals_by_arrival_day` -> bar:
  - `Late Events by Arrival Day`
- `correction_type_summary` -> bar:
  - `Correction Events by Type`
- `late_days_detail` -> table:
  - `Late Arrival Detail`
- `correction_type_summary` -> table:
  - `Correction Impact by Type`

## SQL pronta para copiar e colar

### Overview

#### Dataset `summary`

```sql
SELECT
  COALESCE(SUM(net_revenue), 0) AS total_revenue,
  COALESCE(SUM(events_count), 0) AS total_events,
  COALESCE(SUM(net_quantity), 0) AS total_quantity,
  COALESCE(SUM(correction_events_count), 0) AS total_corrections
FROM main.sdp_dev_gold.gold_daily_sales
```

#### Dataset `daily_sales`

```sql
SELECT
  CAST(sales_date AS STRING) AS sales_day,
  net_revenue,
  net_quantity,
  events_count,
  correction_events_count
FROM main.sdp_dev_gold.gold_daily_sales
ORDER BY sales_date
```

#### Dataset `top_products`

```sql
SELECT
  CONCAT(product_name, ' (#', CAST(product_id AS STRING), ')') AS product_label,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(net_quantity) AS total_quantity,
  SUM(events_count) AS total_events
FROM main.sdp_dev_gold.gold_daily_sales_by_product
GROUP BY product_id, product_name
ORDER BY total_revenue DESC, total_events DESC
LIMIT 10
```

#### Dataset `arrival_vs_business`

```sql
SELECT
  CAST(arrival_date AS STRING) AS arrival_day,
  CAST(sales_date AS STRING) AS sales_day,
  events_count,
  net_quantity,
  net_revenue,
  late_events_count
FROM main.sdp_dev_gold.gold_arrival_vs_business_date
ORDER BY arrival_date DESC, sales_date DESC
```

#### Dataset `correction_impact`

```sql
SELECT
  CAST(arrival_date AS STRING) AS arrival_day,
  CAST(sales_date AS STRING) AS sales_day,
  event_type,
  correction_events_count,
  net_quantity_impact,
  net_revenue_impact
FROM main.sdp_dev_gold.gold_correction_impact
ORDER BY arrival_date DESC, sales_date DESC
```

### Commercial Mix

#### Dataset `commercial_footprint`

```sql
SELECT
  COUNT(DISTINCT product_id) AS distinct_products,
  COUNT(DISTINCT product_category_name) AS distinct_categories,
  COUNT(DISTINCT product_subcategory_name) AS distinct_subcategories
FROM main.sdp_dev_gold.gold_sales_analytics_obt
WHERE event_type = 'SALE'
```

#### Dataset `category_revenue`

```sql
SELECT
  COALESCE(product_category_name, 'Unassigned') AS category_name,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(net_quantity) AS total_quantity,
  SUM(events_count) AS total_events
FROM main.sdp_dev_gold.gold_daily_sales_by_product
GROUP BY COALESCE(product_category_name, 'Unassigned')
ORDER BY total_revenue DESC, total_events DESC
```

#### Dataset `subcategory_revenue`

```sql
SELECT
  COALESCE(product_subcategory_name, 'Unassigned') AS subcategory_name,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(net_quantity) AS total_quantity,
  SUM(events_count) AS total_events
FROM main.sdp_dev_gold.gold_daily_sales_by_product
GROUP BY COALESCE(product_subcategory_name, 'Unassigned')
ORDER BY total_revenue DESC, total_events DESC
LIMIT 12
```

#### Dataset `top_products_by_quantity`

```sql
SELECT
  CONCAT(product_name, ' (#', CAST(product_id AS STRING), ')') AS product_label,
  SUM(net_quantity) AS total_quantity,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(events_count) AS total_events
FROM main.sdp_dev_gold.gold_daily_sales_by_product
GROUP BY product_id, product_name
ORDER BY total_quantity DESC, total_events DESC, total_revenue DESC
LIMIT 15
```

#### Dataset `product_portfolio`

```sql
SELECT
  COALESCE(product_category_name, 'Unassigned') AS category_name,
  COALESCE(product_subcategory_name, 'Unassigned') AS subcategory_name,
  COUNT(DISTINCT product_id) AS product_count,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(net_quantity) AS total_quantity
FROM main.sdp_dev_gold.gold_daily_sales_by_product
GROUP BY
  COALESCE(product_category_name, 'Unassigned'),
  COALESCE(product_subcategory_name, 'Unassigned')
ORDER BY total_revenue DESC, product_count DESC
```

### Customers & Territories

#### Dataset `customer_footprint`

```sql
SELECT
  COUNT(DISTINCT customer_id) AS distinct_customers,
  COUNT(DISTINCT territory_name) AS distinct_territories,
  COUNT(DISTINCT customer_segment) AS distinct_segments
FROM main.sdp_dev_gold.gold_sales_analytics_obt
WHERE event_type = 'SALE'
```

#### Dataset `territory_revenue`

```sql
SELECT
  COALESCE(territory_name, 'Unassigned') AS territory_name,
  ROUND(SUM(amount_delta), 2) AS total_revenue,
  SUM(quantity_delta) AS total_quantity,
  COUNT(*) AS total_events
FROM main.sdp_dev_gold.gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY COALESCE(territory_name, 'Unassigned')
ORDER BY total_revenue DESC, total_events DESC
```

#### Dataset `segment_revenue`

```sql
SELECT
  COALESCE(customer_segment, 'Unassigned') AS customer_segment,
  ROUND(SUM(amount_delta), 2) AS total_revenue,
  SUM(quantity_delta) AS total_quantity,
  COUNT(*) AS total_events
FROM main.sdp_dev_gold.gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY COALESCE(customer_segment, 'Unassigned')
ORDER BY total_revenue DESC, total_events DESC
```

#### Dataset `top_cities`

```sql
SELECT
  COALESCE(customer_city, 'Unassigned') AS customer_city,
  COALESCE(customer_country_region_name, 'Unassigned') AS country_name,
  ROUND(SUM(amount_delta), 2) AS total_revenue,
  SUM(quantity_delta) AS total_quantity,
  COUNT(*) AS total_events
FROM main.sdp_dev_gold.gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY
  COALESCE(customer_city, 'Unassigned'),
  COALESCE(customer_country_region_name, 'Unassigned')
ORDER BY total_revenue DESC, total_events DESC
LIMIT 20
```

### Operations & Corrections

#### Dataset `ops_summary`

```sql
SELECT
  COALESCE(SUM(late_events_count), 0) AS late_events,
  COUNT(DISTINCT CASE WHEN late_events_count > 0 THEN sales_date END) AS affected_sales_days,
  COUNT(DISTINCT CASE WHEN late_events_count > 0 THEN arrival_date END) AS correction_arrival_days
FROM main.sdp_dev_gold.gold_arrival_vs_business_date
```

#### Dataset `late_arrivals_by_arrival_day`

```sql
SELECT
  CAST(arrival_date AS STRING) AS arrival_day,
  SUM(late_events_count) AS late_events,
  ROUND(SUM(net_revenue), 2) AS total_revenue,
  SUM(events_count) AS total_events
FROM main.sdp_dev_gold.gold_arrival_vs_business_date
GROUP BY CAST(arrival_date AS STRING)
ORDER BY arrival_day DESC
```

#### Dataset `correction_type_summary`

```sql
SELECT
  event_type,
  SUM(correction_events_count) AS total_correction_events,
  SUM(net_quantity_impact) AS total_quantity_impact,
  ROUND(SUM(net_revenue_impact), 2) AS total_revenue_impact
FROM main.sdp_dev_gold.gold_correction_impact
GROUP BY event_type
ORDER BY total_correction_events DESC, total_revenue_impact DESC
```

#### Dataset `late_days_detail`

```sql
SELECT
  CAST(arrival_date AS STRING) AS arrival_day,
  CAST(sales_date AS STRING) AS sales_day,
  late_events_count,
  events_count,
  net_quantity,
  net_revenue
FROM main.sdp_dev_gold.gold_arrival_vs_business_date
WHERE late_events_count > 0
ORDER BY arrival_date DESC, sales_date DESC
```

## Quando preferir cada caminho

- **Importar arquivo**: melhor para aula, rapidez e menor chance de erro
- **Copiar e colar SQL**: melhor para explicar como a dashboard é montada dataset por dataset
