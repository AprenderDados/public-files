# Lakehouse Federation Setup

Este projeto não deve armazenar credenciais de origem no Git nem em YAML versionado.

## Abordagem recomendada

- Coloque no projeto apenas metadados não sensíveis:
  - nome da conexão
  - host
  - port
  - nome do banco
  - modo de autenticação
  - nomes do secret scope e das secret keys
- Grave usuario, senha, client id e client secret apenas em `Databricks secrets`.
- Crie a `connection` e o `foreign catalog` em um passo de bootstrap separado do bundle principal.

## Fluxo para ambiente novo

1. Criar um secret scope por projeto ou por ambiente.
2. Gravar os secrets manualmente via UI ou CLI.
3. Executar um notebook ou SQL de bootstrap que lê apenas os nomes do scope e das keys.
4. Criar a conexão com `CREATE CONNECTION ... OPTIONS (...)` usando `secret('<scope>', '<key>')`.
5. Criar o `FOREIGN CATALOG`.
6. Conceder apenas os privilégios necessários:
   - `USE CONNECTION`
   - `CREATE FOREIGN CATALOG` quando aplicável
   - grants no catálogo federado

## Recomendação de autenticação

- Melhor opção para automação: `OAuth Machine to Machine (M2M)` com service principal.
- Opção mais simples para demo/lab: `username/password` com secrets.
- Não usar senha literal em notebook, SQL, bundle ou arquivo de configuração versionado.

## Exemplo SQL

```sql
CREATE CONNECTION IF NOT EXISTS aw_oltp_conn
TYPE sqlserver
OPTIONS (
  host 'example.database.windows.net',
  port '1433',
  user secret('ad-sdp-dev', 'sql-user'),
  password secret('ad-sdp-dev', 'sql-password')
);

CREATE FOREIGN CATALOG IF NOT EXISTS aw_oltp
USING CONNECTION aw_oltp_conn
OPTIONS (database 'AdventureWorksLT');
```

## O que entra no bundle

- nomes de conexão e catálogo federado
- paths e variáveis não sensíveis
- notebooks/jobs de bootstrap

## O que não entra no bundle

- senha
- client secret
- tokens
- qualquer secret value
