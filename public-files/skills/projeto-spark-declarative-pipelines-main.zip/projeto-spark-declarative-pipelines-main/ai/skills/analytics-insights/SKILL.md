# Skill: Análise de Dados Processados

## Nome
`analytics-insights`

## Objetivo
Orientar análise dos dados processados nas tabelas gold do projeto, geração de insights, identificação de padrões e suporte a perguntas de negócio sobre os dados de vendas.

## Quando usar
- Ao analisar dados nas tabelas gold
- Ao gerar resumos executivos ou relatórios
- Ao identificar anomalias, tendências ou picos
- Ao responder perguntas sobre o comportamento dos dados

## Quando não usar
- Quando a tarefa é sobre a pipeline em si (use `pipeline-ops`)
- Quando a tarefa é sobre geração de novos dados (use `data-generator`)
- Quando o problema é de infraestrutura ou deploy (use `databricks-bundles`)

## Arquivos a ler primeiro

```
docs/data_model.md
config/tables/gold/sales_analytics_obt.yml
config/tables/gold/daily_sales.yml
config/tables/gold/daily_sales_by_product.yml
config/tables/gold/arrival_vs_business_date.yml
config/tables/gold/correction_impact.yml
src/course_lakeflow/gold/aggregation_service.py
notebooks/05_validate_dashboard_queries.py
```

---

## Tabelas disponíveis para análise

### gold_sales_analytics_obt
**Grão:** evento individual de venda
**Uso:** análise exploratória, queries ad-hoc, drill-down por produto e cliente
**Colunas principais:** `sales_event_id`, `event_type`, `sales_date`, `arrival_date`, `product_name`, `category_name`, `customer_name`, `territory_name`, `quantity_delta`, `amount_delta`

### gold_daily_sales
**Grão:** data de negócio
**Uso:** série temporal de vendas, identificar dias fortes e fracos
**Colunas:** `sales_date`, `net_quantity`, `net_revenue`, `event_count`, `correction_event_count`

### gold_daily_sales_by_product
**Grão:** data × produto
**Uso:** ranking de produtos, análise de mix diário
**Colunas:** `sales_date`, `product_id`, `product_name`, `category_name`, `net_quantity`, `net_revenue`, `event_count`, `correction_event_count`

### gold_arrival_vs_business_date
**Grão:** data de chegada × data de negócio
**Uso:** análise de latência, eventos tardios
**Colunas:** `arrival_date`, `sales_date`, `event_count`, `net_quantity`, `net_revenue`, `late_events_count`

### gold_correction_impact
**Grão:** arrival_date × sales_date × event_type
**Uso:** impacto de ajustes e cancelamentos sobre receita
**Colunas:** `arrival_date`, `sales_date`, `event_type`, `correction_count`, `quantity_impact`, `revenue_impact`

---

## Regras de interpretação dos dados

### Receita líquida vs. receita bruta
`net_revenue` soma `amount_delta` de todos os tipos de evento (SALE, ADJUSTMENT, CANCEL). Cancelamentos têm `amount_delta` negativo, portanto a receita líquida já desconta cancelamentos. Isso é correto por design.

### Eventos tardios
Um evento é "tardio" quando `arrival_date > sales_date`. Isso significa que o dado chegou depois da data de negócio. É normal neste modelo — representa atraso de integração ou correção retroativa.

### Ajustes vs. cancelamentos
- `ADJUSTMENT`: modifica valor ou quantidade de uma venda anterior (pode ser + ou -)
- `CANCEL`: reverte completamente uma venda (sempre negativo)
- Ambos têm `reference_event_id` apontando para o SALE original

### Efeito de dados sintéticos
Os dados são gerados sinteticamente. Padrões "artificiais" são esperados:
- Volume uniforme entre produtos do mesmo batch
- Distribuição de dias da semana baseada em perfis históricos, mas sem sazonalidade real
- Ajustes e cancelamentos gerados com seed fixo — podem parecer mecânicos

---

## Queries de análise úteis

### Visão geral das vendas
```sql
SELECT
  sales_date,
  SUM(CASE WHEN event_type = 'SALE' THEN amount_delta ELSE 0 END) AS gross_revenue,
  SUM(amount_delta) AS net_revenue,
  COUNT(CASE WHEN event_type = 'SALE' THEN 1 END) AS sale_count,
  COUNT(CASE WHEN event_type IN ('ADJUSTMENT', 'CANCEL') THEN 1 END) AS correction_count
FROM gold_sales_analytics_obt
GROUP BY sales_date
ORDER BY sales_date DESC
```

### Top produtos por receita
```sql
SELECT
  product_name,
  category_name,
  SUM(amount_delta) AS net_revenue,
  COUNT(*) AS event_count
FROM gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY product_name, category_name
ORDER BY net_revenue DESC
LIMIT 20
```

### Taxa de cancelamento por período
```sql
SELECT
  DATE_TRUNC('week', sales_date) AS week,
  COUNT(CASE WHEN event_type = 'CANCEL' THEN 1 END) AS cancels,
  COUNT(CASE WHEN event_type = 'SALE' THEN 1 END) AS sales,
  ROUND(COUNT(CASE WHEN event_type = 'CANCEL' THEN 1 END) * 100.0 /
    NULLIF(COUNT(CASE WHEN event_type = 'SALE' THEN 1 END), 0), 2) AS cancel_rate_pct
FROM gold_sales_analytics_obt
GROUP BY week
ORDER BY week DESC
```

### Latência de chegada de dados
```sql
SELECT
  arrival_date,
  sales_date,
  DATEDIFF(arrival_date, sales_date) AS days_late,
  late_events_count,
  event_count
FROM gold_arrival_vs_business_date
WHERE arrival_date > sales_date
ORDER BY arrival_date DESC, days_late DESC
```

---

## O que sinalizar como possível anomalia

| Padrão observado | Interpretação provável |
|---|---|
| Receita negativa em um dia | Alta taxa de cancelamentos ou ajustes |
| Pico abrupto de volume | Batch gerado com `target_rows` alto |
| Muitos eventos com mesmo `product_id` | Mix de produtos muito concentrado |
| `arrival_date` muito atrasado em relação a `sales_date` | Geração com parâmetros de latência propositais |
| Ausência de eventos em um dia | Batch não gerado para esse dia |
| Taxa de cancelamento > 5% | `cancel_rate` ajustado acima do padrão |

---

## Conexão com o dashboard

As queries do dashboard estão em `notebooks/05_validate_dashboard_queries.py`. O dashboard AI/BI consome tabelas da camada gold diretamente.

Para verificar se o dashboard está consistente com os dados:
```bash
# Validar queries do dashboard (não modifica dados)
# Rodar notebook 05 no Databricks manualmente
```

---

## Exemplos de tarefas que esta skill ajuda

- "Quais foram os produtos mais vendidos na última semana?"
- "Existe alguma anomalia no volume de cancelamentos?"
- "Quanto da receita foi perdida por ajustes tardios?"
- "Por que a receita de sexta-feira é maior que segunda?"
- "Gere um resumo executivo dos dados de vendas"
- "Identifique os territórios com maior volume"
