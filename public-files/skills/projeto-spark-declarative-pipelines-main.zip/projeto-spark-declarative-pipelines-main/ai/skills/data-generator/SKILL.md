# Skill: Gerador Incremental de Vendas

## Nome
`data-generator`

## Objetivo
Orientar trabalho com o gerador auxiliar de dados sintéticos (`src/incremental_sales_generator/`), incluindo: como configurar batches, entender o estado do gerador, calibrar perfis estatísticos e invocar o gerador com segurança.

## Quando usar
- Ao gerar novos batches de dados de venda
- Ao entender como os dados sintéticos são produzidos
- Ao calibrar parâmetros (volume, taxa de cancelamento, mix de produtos)
- Ao diagnosticar problemas com dados gerados

## Quando não usar
- Quando a tarefa é sobre processamento dos dados gerados (use `pipeline-ops`)
- Quando a tarefa é sobre análise de resultados (use `analytics-insights`)

## Arquivos a ler primeiro

```
src/incremental_sales_generator/config.py
src/incremental_sales_generator/sales_batch_planner.py
src/incremental_sales_generator/sales_event_generator.py
src/incremental_sales_generator/sales_profile_service.py
src/incremental_sales_generator/state_repository.py
config/generator/sales_generator.yml
config/generator/facts.yml
config/generator/dimensions.yml
config/environments/base.yml
config/environments/dev.yml
notebooks/02_generate_sales_batch.py
notebooks/04_bootstrap_sales_profiles.py
```

---

## Arquitetura do gerador

### Dois tipos de saída

1. **Dimensões (full extracts)** — exportadas do AdventureWorks via SQL federado
   - Notebook: `01_generate_dimension_full.py`
   - Cada dimensão gera um CSV com `extract_batch_id` embutido no nome
   - Formato: `coalesce(1)` — sempre um único arquivo por batch

2. **Fatos de venda (incremental)** — gerados sinteticamente
   - Notebook: `02_generate_sales_batch.py`
   - Um CSV por batch com os três tipos de evento: SALE, ADJUSTMENT, CANCEL
   - Naming: `{env}_fact_sales_events_arrival_{yyyymmdd}_sales_{yyyymmdd}_{hhmmss}`

### Três tipos de evento de venda

| Tipo | quantity_delta | amount_delta | reference_event_id |
|---|---|---|---|
| `SALE` | positivo | positivo | NULL |
| `ADJUSTMENT` | +1 ou -1 | valor unitário ±1 | aponta para SALE original |
| `CANCEL` | negativo | negativo | aponta para SALE original |

---

## Parâmetros do gerador (notebook 02)

| Widget | Default | Significado |
|---|---|---|
| `environment` | `dev` | Target de execução |
| `business_date` | próximo dia após último | Data de negócio da venda |
| `arrival_date` | igual a business_date | Data de chegada do dado |
| `target_rows` | 600 (dev) | Número de eventos SALE do batch |
| `random_seed` | 42 | Seed para reprodutibilidade |
| `late_adjustment_rate` | 0.03 | Fração de eventos que viram ADJUSTMENT |
| `cancel_rate` | 0.01 | Fração de eventos que viram CANCEL |

---

## Parâmetros em `config/environments/dev.yml`

```yaml
generator:
  target_daily_rows: 600        # base para target_sale_rows
  late_adjustment_rate: 0.03
  cancel_rate: 0.01
```

O `SalesBatchPlanner` aplica o fator de dia da semana sobre `target_daily_rows`:
- Sábados e domingos têm fator menor (menos vendas)
- Dias úteis têm fator próximo de 1.0

---

## Estado do gerador

O gerador mantém estado em tabelas Delta. **Essas tabelas não devem ser apagadas.**

| Tabela | Conteúdo | Por que é crítica |
|---|---|---|
| `generation_state` | próximos IDs + última business_date | garante IDs únicos entre batches |
| `generation_manifest` | log de todos os batches | rastreabilidade completa |
| `generated_sales_events` | registry de todos os eventos | base para ADJUSTMENT e CANCEL |
| `sales_profile_weekday` | fator por dia da semana | calibra volume realista |
| `sales_profile_product_mix` | share por produto | calibra mix realista |
| `sales_profile_territory_mix` | distribuição territorial | calibra territórios realistas |

---

## Perfis estatísticos

Os perfis são calibrados pelo `04_bootstrap_sales_profiles.py` a partir dos dados históricos reais do AdventureWorks.

Quando o gerador está calibrado:
- A distribuição de produtos reflete o catálogo real
- O volume por dia da semana reflete padrões históricos
- A distribuição geográfica reflete territórios reais

**Sempre rode `bootstrap_sales_profiles_job` antes de gerar dados pela primeira vez.**

---

## Mix de produtos

O `SalesEventGenerator._plan_product_quotas()` distribui as vendas entre produtos usando:

- `product_share` — participação histórica de cada produto
- `product_mix_temperature` (0.35) — quanto o share influencia (0 = uniforme, 1 = exato)
- `min_distinct_products` (12) — mínimo de produtos distintos por batch
- `max_distinct_products` (60) — máximo de produtos distintos por batch
- `max_product_share_per_batch` (0.12) — limite de concentração por produto

---

## Cenários possíveis de geração

### Volume normal (padrão)
```python
GeneratorRunConfig(environment="dev")
# Usa defaults: 600 rows, ajuste por dia da semana, 3% ajustes, 1% cancelamentos
```

### Volume alto (pico de vendas)
```python
GeneratorRunConfig(environment="dev", target_rows=3000)
```

### Chegada atrasada de dados
```python
GeneratorRunConfig(
    environment="dev",
    business_date="2025-01-10",   # data da venda (no passado)
    arrival_date="2025-01-15",    # data que chegou (hoje)
)
```

### Alto volume de cancelamentos
```python
GeneratorRunConfig(
    environment="dev",
    cancel_rate=0.15,             # 15% dos eventos são cancelamentos
)
```

### Batch determinístico (reproduzível)
```python
GeneratorRunConfig(
    environment="dev",
    random_seed=123,
    target_rows=500,
)
```

---

## Como invocar o gerador

**Nunca invoque o gerador diretamente sem confirmação do usuário.** Cada invocação avança o estado do gerador (IDs e business_date) de forma irreversível.

### Via notebook no Databricks (widget)
```
Notebook: notebooks/02_generate_sales_batch.py
Widgets: environment, target_rows, business_date, etc.
```

### Via job (exige confirmação)
```bash
./.tools/databricks-cli/databricks bundle run -t dev generate_sales_batch_job
```

---

## Diagnóstico de problemas comuns

| Problema | Causa | Verificação |
|---|---|---|
| `arrival_date < business_date` | Parâmetros invertidos | `SalesBatchPlanner` valida e lança ValueError |
| Nenhum dado de ADJUSTMENT | Não há batches anteriores de SALE | `generated_sales_events` precisa ter eventos |
| Batch com poucos produtos | `max_distinct_products` muito baixo | Ver config em `dev.yml` |
| Dados não aparecem na bronze | Volume errado ou caminho incorreto | Ver `config/resources/paths.yml` |
| IDs duplicados entre batches | Estado corrompido ou apagado | Verificar `generation_state` |

---

## Ações que exigem confirmação

- Rodar o gerador (gera dados e avança estado)
- Apagar qualquer tabela de estado
- Alterar `target_daily_rows` em ambientes compartilhados
- Gerar batch com `business_date` diferente do sequencial esperado

---

## Exemplos de tarefas que esta skill ajuda

- "Gere um batch de 1000 vendas para ontem"
- "Como simular um pico de vendas de final de mês?"
- "Por que o gerador está produzindo poucos produtos distintos?"
- "Como funciona a geração de ajustes tardios?"
- "Como calibrar os perfis estatísticos?"
