# Mapa de Progresso do Aluno

Use este arquivo para acompanhar seu progresso no projeto. Marque cada checkpoint quando concluir.

---

## Como usar

- Marque `[x]` quando concluir um checkpoint
- Anote observações relevantes (erros encontrados, decisões tomadas)
- Compartilhe com o assistente quando pedir revisão

---

## Etapa 0 — Entender o projeto

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 0.1 | Li o `README.md` e entendo o objetivo do projeto | `[ ]` | |
| 0.2 | Li `docs/architecture.md` e consigo descrever o fluxo de dados | `[ ]` | |
| 0.3 | Sei a diferença entre o gerador auxiliar e a pipeline Lakeflow | `[ ]` | |
| 0.4 | Sei quantas camadas tem a pipeline e o que cada uma faz | `[ ]` | |
| 0.5 | Li `docs/data_model.md` e sei o que é um evento SALE, ADJUSTMENT e CANCEL | `[ ]` | |

**Evidência esperada:** Consegue descrever o fluxo em 3 frases.

---

## Etapa 1 — Preparar o ambiente

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 1.1 | Escolhi meu modo de trabalho: `[ ]` Workspace Files ou `[ ]` Asset Bundles | `[ ]` | |
| 1.2 | O projeto está acessível no workspace do Databricks | `[ ]` | |
| 1.3 | Consigo abrir `notebooks/06_workspace_manual_runbook.py` no Databricks | `[ ]` | |
| 1.4 | (Modo Bundle) `bundle validate -t dev` retorna sem erros | `[ ]` | |
| 1.5 | (Modo Bundle) `bundle deploy -t dev` executado com sucesso | `[ ]` | |

**Evidência esperada:** Notebook acessível no workspace / bundle deployado.

---

## Etapa 2 — Setup do workspace

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 2.1 | `notebooks/00_setup_workspace.py` executado sem erro | `[ ]` | |
| 2.2 | Schema criado no Unity Catalog | `[ ]` | |
| 2.3 | Volumes criados no Unity Catalog | `[ ]` | |
| 2.4 | Entendi por que o setup precisa ser feito antes de gerar dados | `[ ]` | |

**Evidência esperada:** Schema e volumes visíveis no Unity Catalog.

---

## Etapa 3 — Calibrar perfis estatísticos

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 3.1 | `notebooks/04_bootstrap_sales_profiles.py` executado sem erro | `[ ]` | |
| 3.2 | Tabela `sales_profile_weekday` criada com dados | `[ ]` | |
| 3.3 | Tabela `sales_profile_product_mix` criada com dados | `[ ]` | |
| 3.4 | Tabela `sales_profile_territory_mix` criada com dados | `[ ]` | |
| 3.5 | Entendi por que calibrar perfis torna os dados mais realistas | `[ ]` | |

**Evidência esperada:** `SELECT * FROM sales_profile_weekday LIMIT 5` retorna linhas com `weekday_factor`.

---

## Etapa 4 — Exportar dimensões

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 4.1 | `notebooks/01_generate_dimension_full.py` executado sem erro | `[ ]` | |
| 4.2 | Arquivos CSV de dimensão presentes no Volume de input | `[ ]` | |
| 4.3 | Entendi por que dimensões chegam como full extract | `[ ]` | |

**Evidência esperada:** Listagem de arquivos no Volume mostra CSVs de dimensão.

---

## Etapa 5 — Gerar primeiro batch de vendas

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 5.1 | `notebooks/02_generate_sales_batch.py` executado sem erro | `[ ]` | |
| 5.2 | Resultado mostra `sale_rows`, `adjustment_rows`, `cancel_rows` | `[ ]` | Anotar valores: SALE=___ ADJUSTMENT=___ CANCEL=___ |
| 5.3 | Arquivo CSV de fatos presente no Volume de input | `[ ]` | |
| 5.4 | Entendi por que cada execução avança o estado do gerador | `[ ]` | |
| 5.5 | Entendi a diferença entre `business_date` e `arrival_date` | `[ ]` | |

**Evidência esperada:** Notebook retorna resultado com totais de linhas geradas.

---

## Etapa 6 — Executar a pipeline Lakeflow

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 6.1 | Pipeline configurada (via UI ou bundle) | `[ ]` | |
| 6.2 | Pipeline executada sem falhas | `[ ]` | |
| 6.3 | `bronze_fact_sales_events_raw` tem linhas | `[ ]` | Quantidade: ___ |
| 6.4 | `silver_fact_sales_events_clean` tem linhas | `[ ]` | Quantidade: ___ |
| 6.5 | `gold_sales_analytics_obt` tem linhas | `[ ]` | Quantidade: ___ |
| 6.6 | Total processado bate com o total gerado na Etapa 5 | `[ ]` | |
| 6.7 | Entendi o que faz cada camada (bronze / silver / gold) | `[ ]` | |
| 6.8 | Entendi o que é uma expectation e para que serve | `[ ]` | |

**Evidência esperada:** Todas as tabelas gold com dados consistentes com o batch gerado.

---

## Etapa 7 — Validar o dashboard

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 7.1 | Dashboard acessível no workspace | `[ ]` | |
| 7.2 | Dashboard mostra dados de vendas | `[ ]` | |
| 7.3 | `notebooks/05_validate_dashboard_queries.py` executado sem erro | `[ ]` | |
| 7.4 | Consigo responder: qual foi a receita líquida total? | `[ ]` | Valor: ___ |
| 7.5 | Entendi por que o dashboard não precisa de joins adicionais | `[ ]` | |

**Evidência esperada:** Dashboard com dados visíveis e resposta à pergunta de receita.

---

## Etapa 8 — Consolidar conceitos técnicos

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 8.1 | Li `curso/guias_estudo/pt_br/01_delta_tables_fundamentos.md` | `[ ]` | |
| 8.2 | Li `curso/guias_estudo/pt_br/02_auto_loader_ingestao_incremental.md` | `[ ]` | |
| 8.3 | Li `curso/guias_estudo/pt_br/03_spark_declarative_pipelines_modelo_mental.md` | `[ ]` | |
| 8.4 | Li `curso/guias_estudo/pt_br/04_expectations_qualidade_declarativa.md` | `[ ]` | |
| 8.5 | Li `curso/guias_estudo/pt_br/08_configuracao_declarativa_yaml_e_pydantic.md` | `[ ]` | |
| 8.6 | Consigo explicar por que o projeto usa configuração YAML e não hardcode | `[ ]` | |
| 8.7 | Consigo explicar por que os módulos são independentes | `[ ]` | |

**Evidência esperada:** Resposta correta à pergunta de arquitetura: "Por que separar gerador e pipeline?"

---

## Etapa 9 (Bônus) — AI Engineering

| # | Checkpoint | Concluído | Observação |
|---|---|---|---|
| 9.1 | Li `ai/bonus/ai-engineering/README.md` | `[ ]` | |
| 9.2 | Li `ai/bonus/ai-engineering/aula_ai_engineering.md` | `[ ]` | |
| 9.3 | Li skill `smart-data-generator` e entendo o fluxo análise → plano → confirmação | `[ ]` | |
| 9.4 | Li skill `smart-sales-analyst` e entendo como contextualizar dados sintéticos | `[ ]` | |
| 9.5 | Rodei `ai_01_smart_data_generator.py` com `EXECUTAR_GERACAO = False` | `[ ]` | |
| 9.6 | Rodei `ai_02_smart_sales_analyst.py` e li o resumo executivo | `[ ]` | |
| 9.7 | Consigo explicar por que uma IA com contexto do projeto é mais útil | `[ ]` | |

**Evidência esperada:** Consegue descrever um cenário onde usaria o agente gerador vs. o agente analista.

---

## Resumo de progresso

```
Etapa 0: [ ] Entender o projeto
Etapa 1: [ ] Preparar ambiente
Etapa 2: [ ] Setup workspace
Etapa 3: [ ] Calibrar perfis
Etapa 4: [ ] Exportar dimensões
Etapa 5: [ ] Gerar vendas
Etapa 6: [ ] Pipeline Lakeflow
Etapa 7: [ ] Dashboard
Etapa 8: [ ] Conceitos técnicos
Etapa 9: [ ] AI Engineering (bônus)
```

---

## Notas do aluno

Use este espaço para anotar dificuldades, decisões tomadas ou insights do projeto:

```
[Anote aqui]
```
