# Skill: Operações em Pipelines

## Nome
`pipeline-ops`

## Objetivo
Orientar criação, modificação e diagnóstico de Spark Declarative Pipelines (Lakeflow) neste projeto, respeitando os padrões arquiteturais e a configuração declarativa em YAML.

## Quando usar
- Ao adicionar novas tabelas à pipeline
- Ao modificar lógica de transformação em bronze, silver ou gold
- Ao adicionar ou modificar regras de qualidade (expectations)
- Ao diagnosticar falhas ou comportamentos inesperados na pipeline

## Quando não usar
- Quando a tarefa é só sobre configuração de deploy (use `databricks-bundles`)
- Quando a tarefa é sobre geração de dados de entrada (use `data-generator`)

## Arquivos a ler primeiro

```
resources/pipelines/lakeflow_sales.pipeline.yml
src/course_lakeflow/pipelines/            (todos os arquivos)
src/course_lakeflow/bronze/bronze_ingestion_service.py
src/course_lakeflow/silver/quality_decorator.py
src/course_lakeflow/silver/sales_event_builder.py
src/course_lakeflow/silver/source_current_builders.py
src/course_lakeflow/gold/aggregation_service.py
src/course_lakeflow/gold/conformed_dimension_service.py
src/course_lakeflow/common/config_loader.py
src/course_lakeflow/common/runtime_context.py
config/tables/bronze/<tabela>.yml           (spec da tabela de interesse)
config/tables/silver/<tabela>.yml
config/tables/gold/<tabela>.yml
```

---

## Arquitetura da pipeline

A pipeline Lakeflow tem cinco arquivos de entry point em `src/course_lakeflow/pipelines/`:

| Arquivo | Responsabilidade |
|---|---|
| `bronze_facts.py` | Ingere `fact_sales_events` via Auto Loader |
| `bronze_dimensions.py` | Ingere todas as 14 dimensões via Auto Loader |
| `silver_facts.py` | Limpa, normaliza e deduplica o fato de vendas |
| `silver_dimensions.py` | Publica estado corrente de cada dimensão |
| `gold_metrics.py` | Dimensões conformadas, OBT e métricas agregadas |

A pipeline usa `@dp.table()` para streaming tables e `@dp.materialized_view()` para views gold.

---

## Padrão de uma tabela de pipeline

### Bronze (fact — streaming table)
```python
from pyspark import pipelines as dp

@dp.table(
    name=runtime_context.table_fqn(fact_spec),   # catálogo.schema.nome_físico
    comment=fact_spec.comment,
)
def bronze_fact_sales_events_raw():
    return bronze_service.read_autoloader_source(fact_spec, fact_input_path)
```

### Silver (streaming table com qualidade declarativa)
```python
@dp.table(
    name=runtime_context.table_fqn(silver_spec),
    comment=silver_spec.comment,
    spark_conf={"pipelines.trigger.interval": "1 minute"},
)
@quality_decorator.apply_expectations(silver_spec)     # injeta expectations do YAML
def silver_fact_sales_events_clean():
    return sales_event_builder.build(
        dp.read_stream(runtime_context.table_fqn(bronze_fact_spec))
    )
```

### Gold (materialized view)
```python
@dp.materialized_view(
    name=runtime_context.table_fqn(gold_spec),
    comment=gold_spec.comment,
)
def gold_daily_sales():
    return aggregation_service.build_daily_sales(
        dp.read(runtime_context.table_fqn(gold_obt_spec))
    )
```

---

## Como adicionar uma nova tabela bronze

1. Crie o spec YAML em `config/tables/bronze/<nome>.yml`:
```yaml
logical_name: <nome_logico>
physical_name: bronze_<nome_fisico>
layer: bronze
asset_type: streaming_table
comment: "Descrição da tabela"
path_ref: <chave_de_volume>   # deve existir em config/resources/paths.yml
source_format: csv
schema:
  - name: campo1
    type: string
    nullable: false
```

2. Adicione o entry point no arquivo de pipeline correspondente em `src/course_lakeflow/pipelines/`
3. Confirme o caminho do Volume em `config/resources/paths.yml`
4. Valide o bundle antes de fazer deploy

---

## Como adicionar uma nova regra de qualidade (expectation)

Edite o spec YAML da tabela silver correspondente em `config/tables/silver/<tabela>.yml`:

```yaml
quality_rules:
  - name: <nome_descritivo>
    expression: "<expressão SQL que retorna booleano>"
    action: warn   # ou: drop, fail
```

**Ações disponíveis:**
- `warn` — registra a violação e passa o dado
- `drop` — descarta a linha que viola a regra
- `fail` — para toda a pipeline quando violada

**Nunca use `fail` sem ter certeza do impacto.** Um `fail` em dados gerados incorretamente pode parar o processamento inteiro.

---

## Como ler tabelas dentro da pipeline

Use `dp.read()` para batch (materialized views) e `dp.read_stream()` para streaming:

```python
# Dentro de uma @dp.materialized_view
silver_df = dp.read(runtime_context.table_fqn(silver_spec))

# Dentro de uma @dp.table (streaming)
bronze_df = dp.read_stream(runtime_context.table_fqn(bronze_spec))
```

---

## Como a pipeline resolve nomes de tabelas

```python
runtime_context.table_fqn(spec)
# Retorna: "catalogo.schema.physical_name"
# Ex: "main.default.bronze_fact_sales_events_raw"
```

O `RuntimeContext` é criado em cada arquivo de pipeline:
```python
environment = spark.conf.get("course_sdp.environment", "dev")
project_root = resolve_pipeline_project_root(spark)
runtime_context = ProjectContextResolver(spark, project_root).resolve(environment)
```

---

## Regras de design da pipeline deste projeto

1. **Sem SCD2** — dimensões publicam apenas estado corrente na silver
2. **Left joins na gold** — eventos de venda com dimensões ausentes ainda aparecem
3. **Fatos como ledger** — eventos SALE, ADJUSTMENT e CANCEL são todos válidos
4. **Schema explícito** — nunca use `inferSchema` — o schema vem do YAML
5. **Notebooks finos** — lógica de negócio vai nos serviços Python, não nos entry points

---

## Diagnóstico de falhas comuns

| Sintoma | Causa provável | Verificação |
|---|---|---|
| Pipeline não encontra arquivos | Volume errado ou caminho incorreto | Ver `config/resources/paths.yml` |
| `_rescued_data` com valores | Schema diverge da fonte | Comparar YAML com CSV real |
| Expectation `fail` disparada | Dado inválido na source | Ver logs da pipeline + qual regra falhou |
| Tabela gold vazia | Silver vazia ou join com dimensão falhou | Verificar silver antes |
| Deduplicação gerando duplicatas | Chave de deduplicação incorreta | Ver `business_keys` no YAML |

---

## Ações que exigem confirmação

- Alterar uma expectation de `warn` para `fail`
- Alterar `asset_type` de uma tabela (streaming table vs materialized view)
- Remover uma tabela da pipeline (afeta downstream)
- Fazer deploy da pipeline após mudanças estruturais

---

## Exemplos de tarefas que esta skill ajuda

- "Adicione uma nova regra de qualidade que descarta vendas com valor zero"
- "Explique por que a tabela silver está vazia"
- "Como adicionar uma nova coluna calculada na camada gold?"
- "Qual é a diferença entre streaming table e materialized view nesta pipeline?"
- "Como a deduplicação funciona nos fatos de venda?"
