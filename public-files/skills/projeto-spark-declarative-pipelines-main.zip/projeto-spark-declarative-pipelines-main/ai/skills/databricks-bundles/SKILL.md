# Skill: Databricks Asset Bundles

## Nome
`databricks-bundles`

## Objetivo
Orientar trabalho com Databricks Asset Bundles (DABs) neste projeto: validação, deploy, execução de jobs e promoção entre ambientes.

## Quando usar
- Ao trabalhar com `databricks.yml` ou arquivos em `resources/`
- Ao fazer deploy ou validar o bundle
- Ao criar novos jobs ou pipelines
- Ao ajudar o aluno a configurar o bundle pela primeira vez

## Quando não usar
- Quando a tarefa é sobre código Python das pipelines (use `pipeline-ops`)
- Quando a tarefa é sobre geração de dados (use `data-generator`)
- Quando o aluno está no modo "workspace files" sem CLI (use runbook manual)

## Arquivos a ler primeiro

```
databricks.yml
resources/jobs/end_to_end_demo.job.yml
resources/jobs/generate_sales_batch.job.yml
resources/pipelines/lakeflow_sales.pipeline.yml
.env.example
config/environments/dev.yml
```

---

## Estrutura do bundle

```yaml
# databricks.yml — raiz do bundle
bundle:
  name: projeto-spark-declarative-pipelines

include:
  - resources/**/*.yml          # inclui todos os jobs, pipelines e dashboards

variables:
  pipeline_catalog: main
  pipeline_schema: default
  dashboard_warehouse_id:        # obrigatório — ID do SQL Warehouse para dashboard

targets:
  dev:   mode: development, catálogo main
  acc:   mode: development, catálogo lakehouse_dev
  prd:   mode: production,  catálogo lakehouse_prd
```

---

## CLI local disponível

O projeto inclui a CLI do Databricks em `.tools/databricks-cli/databricks`.

**Não use a CLI do sistema** — use sempre o binário local para garantir a versão correta.

```bash
# Versão recomendada
./.tools/databricks-cli/databricks --version   # deve ser >= 0.283.0
```

---

## Comandos seguros (somente leitura)

```bash
# Validar bundle sem fazer deploy
./.tools/databricks-cli/databricks bundle validate -t dev

# Ver recursos que seriam deployados
./.tools/databricks-cli/databricks bundle summary -t dev

# Listar jobs deployados no workspace
./.tools/databricks-cli/databricks jobs list

# Ver status de um run
./.tools/databricks-cli/databricks runs get --run-id <ID>
```

---

## Comandos que exigem confirmação

```bash
# REQUER CONFIRMAÇÃO — faz deploy e cria/atualiza recursos no workspace
./.tools/databricks-cli/databricks bundle deploy -t dev

# REQUER CONFIRMAÇÃO — dispara um job (gera custos de compute)
./.tools/databricks-cli/databricks bundle run -t dev <nome_do_job>

# REQUER CONFIRMAÇÃO EM acc E prd
./.tools/databricks-cli/databricks bundle deploy -t acc
./.tools/databricks-cli/databricks bundle deploy -t prd
```

---

## Configuração da variável obrigatória

O único ID externo necessário é o `warehouse_id` do SQL Warehouse para o dashboard.

```bash
# Método recomendado: via arquivo .env
cp .env.example .env
# Editar .env e preencher BUNDLE_VAR_dashboard_warehouse_id

# Carregar no shell
set -a && source .env && set +a

# Depois rodar normalmente
./.tools/databricks-cli/databricks bundle validate -t dev
./.tools/databricks-cli/databricks bundle deploy -t dev
```

> Atenção: variáveis de bundle são resolvidas no `deploy`, não no `run`. Se mudar o `warehouse_id`, refaça o deploy.

---

## Estrutura de recursos

### Jobs
Cada job vive em `resources/jobs/<nome>.job.yml`.

Padrão de job com notebook task:
```yaml
resources:
  jobs:
    <nome>_job:
      name: "Nome do Job [${bundle.target}]"
      max_concurrent_runs: 1
      tasks:
        - task_key: <chave>
          notebook_task:
            notebook_path: ../../notebooks/<notebook>.py
            base_parameters:
              environment: ${bundle.target}
          job_cluster_key: main_cluster
      job_clusters:
        - job_cluster_key: main_cluster
          new_cluster:
            spark_version: "..."
            num_workers: 0
            spark_conf:
              spark.databricks.cluster.profile: singleNode
```

Padrão de job que chama outro job:
```yaml
tasks:
  - task_key: <chave>
    run_job_task:
      job_id: ${resources.jobs.<outro_job>.id}
```

### Pipeline
A pipeline Lakeflow fica em `resources/pipelines/lakeflow_sales.pipeline.yml`.

```yaml
resources:
  pipelines:
    sales_pipeline:
      name: "Didactic Sales Pipeline [${bundle.target}]"
      catalog: ${var.pipeline_catalog}
      schema: ${var.pipeline_schema}
      root_path: ${workspace.file_path}
      libraries:
        - glob:
            include: ../../src/course_lakeflow/pipelines/**
      configuration:
        course_sdp.environment: ${bundle.target}
        course_sdp.project_root: ${workspace.file_path}
      serverless: true
```

### Dashboard
O dashboard usa o arquivo JSON versionado em `dashboards/` e é referenciado em `resources/dashboards/`.

---

## Como criar um novo job

1. Crie o arquivo `resources/jobs/<nome>.job.yml`
2. Siga o padrão de job existente (notebook_task ou run_job_task)
3. Referencie o notebook em `../../notebooks/<nome>.py`
4. Passe `environment: ${bundle.target}` como parâmetro base
5. Valide: `./.tools/databricks-cli/databricks bundle validate -t dev`
6. **Confirme com o usuário antes de fazer deploy**

---

## Presets por target

No target `dev` e `acc`, o bundle adiciona prefixo ao nome:
```
${workspace.current_user.short_name} | Nome do Job
```

No target `prd`, o nome fica sem prefixo — exatamente como declarado no YAML.

---

## Restrições de concorrência

Estes jobs têm `max_concurrent_runs: 1` intencionalmente:
- `generate_sales_batch_job` — evita conflito de escrita no estado
- `refresh_pipeline_job` — evita updates simultâneos na pipeline
- `end_to_end_demo_job` — evita conflito em ambas as operações

**Nunca altere `max_concurrent_runs` sem entender o impacto.**

---

## Exemplos de tarefas que esta skill ajuda

- "Como validar o bundle antes de fazer deploy?"
- "Preciso criar um novo job que rode o notebook X"
- "Como configurar o warehouse_id?"
- "Qual é a diferença entre deploy em dev e prd?"
- "Como rodar o job de geração de dados?"
