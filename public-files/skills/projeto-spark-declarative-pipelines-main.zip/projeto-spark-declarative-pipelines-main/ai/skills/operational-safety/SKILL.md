# Skill: Segurança Operacional

## Nome
`operational-safety`

## Objetivo
Estabelecer as regras inegociáveis de segurança que qualquer IA deve seguir ao trabalhar neste repositório. Esta skill deve ser carregada antes de qualquer outra.

## Quando usar
Sempre. Esta skill não é opcional — ela define o comportamento base de qualquer agente.

## Quando não usar
Nunca descarte esta skill.

---

## Regras de ouro

### 1. Nunca execute jobs no Databricks sem confirmação explícita

Jobs no Databricks consomem compute real, geram dados reais e podem ter efeitos irreversíveis.

Exemplos de ações que exigem confirmação antes de executar:
- `databricks bundle run`
- `databricks jobs run-now`
- Qualquer notebook que escreva em tabelas Delta
- `02_generate_sales_batch.py` — gera dados e avança o estado do gerador
- `07_delete_sales_source_batches.py` — apaga arquivos CSV de source

### 2. Nunca apague dados ou tabelas sem confirmação explícita

Tabelas que não devem ser apagadas sem confirmação:
- `generation_state` — estado do gerador (IDs únicos)
- `generation_manifest` — log de batches gerados
- `generated_sales_events` — registry completo de eventos
- `sales_profile_*` — perfis estatísticos calibrados

Se um usuário pedir para "limpar", "resetar" ou "apagar" dados, pergunte exatamente o que deve ser apagado e confirme antes de agir.

### 3. Nunca faça deploy em `acc` ou `prd` sem confirmação explícita

O bundle tem três targets: `dev`, `acc` e `prd`.

- `dev` → seguro para deploy e experimentos
- `acc` → exige confirmação antes de deploy
- `prd` → exige confirmação explícita e revisão de mudanças

### 4. Nunca altere configurações de ambiente sem revisão

Arquivos que exigem revisão antes de alterar:
- `config/environments/acc.yml`
- `config/environments/prd.yml`
- `databricks.yml` (estrutura principal do bundle)
- `resources/pipelines/lakeflow_sales.pipeline.yml`

### 5. Nunca refatore código sem pedido explícito

Esta skill bloqueia refatorações não solicitadas. Se perceber uma melhoria técnica, mencione-a separadamente, mas não implemente sem aprovação.

### 6. Nunca invente arquivos ou APIs que não existem

Antes de referenciar um arquivo, verifique se ele existe. Antes de sugerir um comando, verifique se o binário está disponível.

Binários disponíveis neste projeto:
- `./.tools/databricks-cli/databricks` — CLI local do Databricks

---

## Checklist antes de qualquer ação destrutiva

```
[ ] O usuário pediu explicitamente esta ação?
[ ] A ação é reversível?
[ ] Qual ambiente será afetado (dev / acc / prd)?
[ ] Existem dados que serão perdidos?
[ ] O usuário confirmou ciente dos riscos?
```

Se qualquer item for "não" ou "incerto", pause e pergunte antes de agir.

---

## Comandos sempre seguros (somente leitura)

```bash
# Ver status do bundle
./.tools/databricks-cli/databricks bundle validate -t dev

# Listar jobs deployados
./.tools/databricks-cli/databricks jobs list

# Ver estrutura de arquivos
find . -type f -name "*.yml" | grep -v .git | grep -v .databricks

# Ver configuração de um job
cat resources/jobs/<nome>.job.yml

# Ver spec de uma tabela
cat config/tables/<camada>/<tabela>.yml
```

---

## Riscos conhecidos deste projeto

| Ação | Risco | Severidade |
|---|---|---|
| `generate_sales_batch_job` sem plano | Avança business_date e consome IDs sem recuperação | Alta |
| Apagar `generation_state` | Perde controle de IDs únicos, gera duplicatas | Crítica |
| Deploy em `prd` errado | Sobrescreve tabelas analíticas de produção | Crítica |
| Modificar pipeline sem entender dependências | Quebra DAG e impede refresh | Alta |
| Rodar `07_delete_sales_source_batches.py` | Apaga arquivos CSV fonte — a pipeline não vai encontrá-los | Alta |
