# Skill: Visão Geral do Projeto

## Nome
`project-overview`

## Objetivo
Orientar qualquer IA que vá trabalhar neste repositório sobre a arquitetura geral, convenções e intenção do projeto. Esta skill deve ser carregada no início de qualquer sessão de trabalho.

## Quando usar
- No início de qualquer sessão de trabalho neste repositório
- Antes de propor mudanças estruturais
- Quando o usuário pede contexto geral do projeto
- Quando a tarefa envolve múltiplos componentes do projeto

## Quando não usar
- Quando a tarefa é pontual e você já leu os arquivos relevantes
- Quando o usuário pede algo muito localizado (ex: mudar um campo em um YAML específico)

## Arquivos a ler primeiro

```
README.md
docs/architecture.md
docs/data_model.md
databricks.yml
config/environments/base.yml
config/environments/dev.yml
```

---

## Arquitetura resumida

### Objetivo do projeto
Demonstrar uma arquitetura de dados em camadas (Medallion) usando Spark Declarative Pipelines (Lakeflow) no Databricks. O domínio é vendas de artigos esportivos baseado no conjunto AdventureWorks, com dados sintéticos gerados incrementalmente para simular um fluxo real de produção.

O projeto é **didático** — cada componente existe para ensinar um conceito específico de engenharia de dados no Databricks.

### Dois módulos independentes

```
Módulo 1: incremental_sales_generator   (src/incremental_sales_generator/)
Módulo 2: course_lakeflow               (src/course_lakeflow/)
```

Os módulos se comunicam **apenas por arquivos CSV em Unity Catalog Volumes**. A pipeline não conhece o gerador em tempo de execução.

### Fluxo completo de dados

```
AdventureWorks (Lakehouse Federation)
        ↓ (consulta SQL federada)
Gerador Auxiliar (incremental_sales_generator)
        ↓ (escreve CSV em Volumes)
Camada Bronze (Auto Loader + schema explícito)
        ↓
Camada Silver (qualidade declarativa + deduplicação + estado corrente)
        ↓
Camada Gold (dimensões conformadas + OBT + métricas)
        ↓
Dashboard AI/BI
```

### Como os dados entram

- **Dimensões** chegam como full extracts periódicos exportados do AdventureWorks via SQL federado
- **Fatos de venda** são gerados sinteticamente com base em padrões extraídos do AdventureWorks

### Como os dados são processados

1. Auto Loader lê CSV dos Volumes com schema explícito → tabelas Bronze append-only
2. Silver filtra (rescue), normaliza e deduplica; dimensões publicam apenas estado corrente
3. Gold une dimensões conformadas e fatos → One Big Table e métricas agregadas

---

## Estrutura de diretórios

```
config/
  environments/       herança base → dev/acc/prd
  generator/          parâmetros do gerador (SQL de source, defaults)
  resources/          catálogos, schemas, volumes, caminhos
  tables/             specs de tabelas por camada (bronze/silver/gold)

src/
  course_lakeflow/
    common/           ConfigLoader, Pydantic models, path resolver, runtime context
    bronze/           BronzeIngestionService (Auto Loader)
    silver/           qualidade, deduplicação, builders de dimensão e fatos
    gold/             dimensões conformadas, métricas, OBT
    pipelines/        entry points DLT (bronze_facts, bronze_dimensions,
                      silver_facts, silver_dimensions, gold_metrics)
    bootstrap/        provisionamento de schemas e volumes

  incremental_sales_generator/
    config.py                    GeneratorRunConfig, GeneratorConfigLoader
    sales_batch_planner.py       SalesBatchPlanner — monta o plano do batch
    sales_event_generator.py     SalesEventGenerator — gera o CSV
    sales_profile_service.py     perfis estatísticos (weekday, product mix, territory)
    state_repository.py          lê/escreve tabelas de estado do gerador
    dimension_exporter.py        exporta dimensões do AdventureWorks

notebooks/             entry points operacionais
  00_setup_workspace   provisiona schemas e volumes
  01_generate_dimension_full   exporta dimensões full
  02_generate_sales_batch      gera batch de vendas (aceita widgets)
  03_refresh_pipeline          scaffold — não executa refresh real
  04_bootstrap_sales_profiles  calibra perfis estatísticos
  05_validate_dashboard_queries valida queries do dashboard
  06_workspace_manual_runbook  guia passo a passo para alunos
  07_delete_sales_source_batches apaga arquivos CSV (CUIDADO)

resources/
  jobs/               definições de jobs para DABs
  pipelines/          definição da pipeline Lakeflow
  dashboards/         definição do dashboard AI/BI

dashboards/            JSONs do dashboard por ambiente (dev/acc/prd)
docs/                  arquitetura, modelo de dados, guias de setup
curso/                 material didático (guias, notebooks, simulados, slides)
tests/unit/            testes unitários
```

---

## Tabelas existentes

### Bronze (streaming tables, append-only)
- `bronze_fact_sales_events_raw`
- `bronze_{14 tabelas de dimensão}_full_raw`

### Silver
- `silver_fact_sales_events_clean` (streaming table, deduplicated ledger)
- `silver_{14 tabelas de dimensão}_current` (streaming tables, current state)

### Gold (materialized views)
- `gold_dim_product` — dimensão conformada de produto (12 colunas)
- `gold_dim_customer` — dimensão conformada de cliente (17 colunas)
- `gold_sales_analytics_obt` — One Big Table no grão do evento
- `gold_daily_sales` — métricas diárias totais
- `gold_daily_sales_by_product` — métricas diárias por produto
- `gold_arrival_vs_business_date` — análise de latência
- `gold_correction_impact` — impacto de ajustes e cancelamentos

### Tabelas de estado do gerador (Delta fora da pipeline)
- `generation_state` — próximos IDs e última data de negócio
- `generation_manifest` — log de batches gerados
- `generated_sales_events` — registry completo de eventos
- `sales_profile_weekday` — fator de volume por dia da semana
- `sales_profile_product_mix` — participação por produto
- `sales_profile_territory_mix` — distribuição por território

---

## Ambientes

| Target | Catálogo | Propósito |
|---|---|---|
| `dev` | `main` | desenvolvimento e testes |
| `acc` | `lakehouse_dev` | homologação |
| `prd` | `lakehouse_prd` | produção |

Nome do schema: `default` em todos os ambientes.
As tabelas do gerador ficam no catálogo `main` em todos os ambientes.

---

## Padrões do projeto

### Configuração declarativa
Todo schema, regra de qualidade e parâmetro fica em YAML. O código lê; não embute.

### Notebooks finos
A lógica de negócio vive nas classes Python de `src/`. Os notebooks são entry points que instanciam serviços e chamam métodos.

### Parâmetros via widgets
Notebooks aceitam parâmetros via `dbutils.widgets.get()`. Exemplo em `02_generate_sales_batch.py`:
- `environment`, `business_date`, `arrival_date`, `target_rows`, `random_seed`, `late_adjustment_rate`, `cancel_rate`

### Como notebooks resolvem o project_root
```python
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
notebook_path = context.notebookPath().get()
workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
PROJECT_ROOT = workspace_path.parent.parent
```

### Como a pipeline resolve o project_root
Via `spark.conf.get("course_sdp.project_root")` — configurado no YAML da pipeline.

---

## Jobs e seu propósito

| Job | Arquivo | Propósito |
|---|---|---|
| `end_to_end_demo_job` | `end_to_end_demo.job.yml` | Roda todo o fluxo: setup → profiles → dimensions → batch → pipeline |
| `setup_workspace_job` | `setup_workspace.job.yml` | Provisiona schemas e volumes |
| `bootstrap_sales_profiles_job` | `bootstrap_sales_profiles.job.yml` | Calibra perfis estatísticos com dados reais |
| `export_dimensions_job` | `export_dimensions.job.yml` | Exporta dimensões full do AdventureWorks |
| `generate_sales_batch_job` | `generate_sales_batch.job.yml` | Gera um batch de vendas (avança o estado) |
| `refresh_pipeline_job` | `refresh_pipeline.job.yml` | Executa refresh da pipeline Lakeflow |

---

## Exemplos de tarefas que esta skill ajuda

- "Explique como funciona o projeto"
- "Onde estão os arquivos de configuração?"
- "Qual job devo rodar para gerar dados?"
- "Quais tabelas existem na camada gold?"
- "Como o projeto trata ambientes diferentes?"
- "O que é o gerador auxiliar?"
