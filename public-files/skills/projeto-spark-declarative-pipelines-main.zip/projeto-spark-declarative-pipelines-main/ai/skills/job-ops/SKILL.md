# Skill: Operações em Jobs

## Nome
`job-ops`

## Objetivo
Orientar criação e modificação de jobs Databricks neste projeto, seguindo os padrões estabelecidos e garantindo configuração correta de parâmetros, clusters e dependências.

## Quando usar
- Ao criar novos jobs
- Ao modificar parâmetros de jobs existentes
- Ao orquestrar sequências de notebooks
- Ao diagnosticar falhas de execução de jobs

## Quando não usar
- Quando a tarefa é sobre a lógica interna da pipeline (use `pipeline-ops`)
- Quando a tarefa é sobre geração de dados (use `data-generator`)

## Arquivos a ler primeiro

```
resources/jobs/end_to_end_demo.job.yml
resources/jobs/generate_sales_batch.job.yml
resources/jobs/refresh_pipeline.job.yml
databricks.yml
```

---

## Jobs existentes e suas responsabilidades

| Job | Notebook chamado | Parâmetros aceitos |
|---|---|---|
| `setup_workspace_job` | `notebooks/00_setup_workspace.py` | `environment` |
| `bootstrap_sales_profiles_job` | `notebooks/04_bootstrap_sales_profiles.py` | `environment` |
| `export_dimensions_job` | `notebooks/01_generate_dimension_full.py` | `environment` |
| `generate_sales_batch_job` | `notebooks/02_generate_sales_batch.py` | `environment`, `business_date`, `arrival_date`, `target_rows`, `random_seed`, `late_adjustment_rate`, `cancel_rate` |
| `refresh_pipeline_job` | `notebooks/03_refresh_pipeline.py` | `environment` |
| `end_to_end_demo_job` | (chama os jobs acima em sequência) | — |

---

## Padrão de job com notebook task

```yaml
resources:
  jobs:
    <nome>_job:
      name: "Descrição do Job [${bundle.target}]"
      max_concurrent_runs: 1
      tasks:
        - task_key: main_task
          notebook_task:
            notebook_path: ../../notebooks/<nome>.py
            base_parameters:
              environment: ${bundle.target}
              # outros parâmetros opcionais aqui
          job_cluster_key: main_cluster

      job_clusters:
        - job_cluster_key: main_cluster
          new_cluster:
            spark_version: "16.4.x-scala2.12"
            node_type_id: "Standard_DS3_v2"    # verificar disponibilidade no workspace
            num_workers: 0
            spark_conf:
              spark.databricks.cluster.profile: singleNode
              spark.master: local[*, 4]
```

> **Atenção:** configurações de cluster variam por workspace. Sempre confirme com o usuário qual `node_type_id` está disponível no workspace dele.

---

## Padrão de job orquestrador (run_job_task)

```yaml
tasks:
  - task_key: etapa_1
    run_job_task:
      job_id: ${resources.jobs.<nome_job_1>.id}

  - task_key: etapa_2
    depends_on:
      - task_key: etapa_1
    run_job_task:
      job_id: ${resources.jobs.<nome_job_2>.id}
```

Use `run_job_task` para compor jobs sem duplicar lógica de configuração de cluster.

---

## Parâmetros e widgets

Os notebooks recebem parâmetros via `dbutils.widgets.get()`. No job, esses parâmetros são definidos em `base_parameters` (fixos) ou sobrescritos via `run-now` com `notebook_params`.

```python
# Dentro do notebook
environment = _get_widget("environment", "dev")
target_rows = _get_widget("target_rows", "")
```

Parâmetro vazio (`""`) é tratado como "usar default" no código Python.

---

## Restrições de concorrência

Estes jobs têm `max_concurrent_runs: 1` por design:
- `generate_sales_batch_job` — conflito de escrita no estado do gerador
- `refresh_pipeline_job` — conflito de updates na pipeline
- `end_to_end_demo_job` — ambos os riscos acima

**Nunca altere `max_concurrent_runs` nestes jobs sem confirmar com o usuário.**

---

## Comandos de execução (exigem confirmação)

```bash
# Rodar job via bundle (recomendado)
./.tools/databricks-cli/databricks bundle run -t dev <nome_do_job>

# Rodar com parâmetros override
./.tools/databricks-cli/databricks bundle run -t dev generate_sales_batch_job \
  --python-named-params "environment=dev,target_rows=100"

# Listar runs de um job
./.tools/databricks-cli/databricks runs list --job-id <ID>
```

---

## Ordem correta de execução (primeira vez)

```
setup_workspace_job
  → bootstrap_sales_profiles_job
    → export_dimensions_job
      → generate_sales_batch_job
        → refresh_pipeline_job
```

Esta sequência é exatamente o que `end_to_end_demo_job` faz.

Para reruns:
- Para novo dia de dados: somente `generate_sales_batch_job` → `refresh_pipeline_job`
- Para reparar dimensões: somente `export_dimensions_job` → `refresh_pipeline_job`
- Para reprovisionar: `setup_workspace_job` (idempotente)

---

## Ações que exigem confirmação

- Executar qualquer job (consome compute)
- Criar ou remover jobs em `acc` ou `prd`
- Alterar `max_concurrent_runs`
- Alterar configurações de cluster em produção

---

## Exemplos de tarefas que esta skill ajuda

- "Crie um job que rode o notebook X com parâmetro Y"
- "Como rodar só a etapa de geração de dados?"
- "Qual é a ordem correta de execução dos jobs?"
- "Como verificar se o job de geração falhou?"
- "Preciso orquestrar dois notebooks em sequência"
