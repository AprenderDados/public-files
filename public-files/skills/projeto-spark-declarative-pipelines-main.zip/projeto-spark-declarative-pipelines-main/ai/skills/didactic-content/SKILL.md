# Skill: Conteúdo Didático

## Nome
`didactic-content`

## Objetivo
Orientar criação e manutenção de material didático para o curso: guias de estudo, notebooks educacionais, simulados, slides e documentação para alunos.

## Quando usar
- Ao criar ou atualizar guias de estudo
- Ao criar notebooks didáticos para os alunos
- Ao criar simulados e exercícios
- Ao documentar conceitos para iniciantes no Databricks
- Ao criar roteiros de aula

## Quando não usar
- Quando a tarefa é técnica de produção (use as skills específicas)
- Quando o usuário quer análise de dados reais (use `analytics-insights`)

## Arquivos a ler primeiro

```
curso/README.md
curso/guias_estudo/pt_br/   (todos os arquivos)
curso/notebooks/pt_br/      (todos os arquivos)
docs/architecture.md
docs/data_model.md
```

---

## Estrutura do material didático

```
curso/
  guias_estudo/pt_br/    textos explicativos por tópico
  notebooks/pt_br/       notebooks interativos por tópico
  simulados/pt_br/       questões de fixação por tópico
  slides/pt_br/          roteiros de apresentação
```

### Tópicos cobertos (numerados para sequência de aula)

| # | Tópico | Arquivo |
|---|---|---|
| 01 | Delta Tables: Fundamentos | `01_delta_tables_fundamentos` |
| 02 | Auto Loader: Ingestão Incremental | `02_auto_loader_ingestao_incremental` |
| 03 | Spark Declarative Pipelines: Modelo Mental | `03_spark_declarative_pipelines_modelo_mental` |
| 04 | Expectations: Qualidade Declarativa | `04_expectations_qualidade_declarativa` |
| 05 | Camada Bronze: Ingestão Tipada | `05_camada_bronze_ingestao_tipada` |
| 06 | Camada Silver: Qualidade e Estado Corrente | `06_camada_silver_qualidade_e_estado_corrente` |
| 07 | Camada Gold: Dimensões e Métricas | `07_camada_gold_dimensoes_e_metricas` |
| 08 | Configuração Declarativa: YAML e Pydantic | `08_configuracao_declarativa_yaml_e_pydantic` |
| 09 | Unity Catalog: Volumes e Schemas | `09_unity_catalog_volumes_e_schemas` |

---

## Padrão de notebook didático

Os notebooks em `curso/notebooks/pt_br/` são escritos em formato `.py` com comentários como `# COMMAND ----------` para separação de cells no Databricks.

```python
# Databricks notebook source
# MAGIC %md
# MAGIC # Título do Tópico
# MAGIC
# MAGIC Introdução ao conceito em 2-3 parágrafos.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conceito 1
# MAGIC Explicação com exemplo.

# COMMAND ----------

# Código de exemplo comentado
df = spark.read.format("delta").load("/caminho/exemplo")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercício
# MAGIC Instrução para o aluno fazer.
```

---

## Padrão de guia de estudo

Os guias em `curso/guias_estudo/pt_br/` são documentos Markdown com:

1. **Contexto** — por que este tópico importa
2. **Conceito central** — explicação objetiva
3. **Como funciona no projeto** — conexão com o código real
4. **Tradeoffs** — decisões de design e suas consequências
5. **Referências** — links para arquivos do projeto

---

## Princípios didáticos do projeto

1. **Conexão com o projeto real** — todo conceito deve ter um exemplo no código do projeto
2. **Pragmatismo antes de perfeição** — mostre o que funciona, depois os tradeoffs
3. **Progressão de complexidade** — tópicos 01-04 são base, 05-09 são aplicação
4. **Foco em Databricks Free Tier** — soluções devem funcionar no tier gratuito
5. **Linguagem acessível** — evite jargão sem explicação prévia

---

## Conexão entre material e código

| Conceito ensinado | Arquivo de código de referência |
|---|---|
| Delta Tables | `src/course_lakeflow/bronze/bronze_ingestion_service.py` |
| Auto Loader | `src/course_lakeflow/bronze/bronze_ingestion_service.py` |
| Declarative Pipelines | `src/course_lakeflow/pipelines/*.py` |
| Expectations | `config/tables/silver/fact_sales_events_clean.yml` |
| Camada Bronze | `src/course_lakeflow/pipelines/bronze_facts.py` |
| Camada Silver | `src/course_lakeflow/pipelines/silver_facts.py` |
| Camada Gold | `src/course_lakeflow/pipelines/gold_metrics.py` |
| Configuração YAML | `config/environments/base.yml`, `config/tables/` |
| Unity Catalog | `config/resources/catalogs.yml`, `config/resources/schemas.yml` |

---

## O que evitar no material didático

- Não use exemplos que não funcionem no Free Tier
- Não use APIs pagas ou recursos premium sem avisar o aluno
- Não misture conceitos de tópicos diferentes no mesmo módulo
- Não crie notebooks que dependam de configurações externas sem explicar como configurar
- Não explique apenas o "como" sem o "por quê"

---

## Exemplos de tarefas que esta skill ajuda

- "Crie um guia de estudo sobre Spark Declarative Pipelines"
- "Escreva um simulado com 5 questões sobre camada silver"
- "Atualize o notebook 05 para incluir um exemplo de rescue data"
- "Crie um slide explicando o fluxo de dados do projeto"
- "Como devo explicar a diferença entre streaming table e materialized view?"
