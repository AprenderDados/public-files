# AI Skills — Projeto Spark Declarative Pipelines

Este diretório contém instruções reutilizáveis para qualquer IA que vá trabalhar neste repositório.

## O que são skills de projeto?

São arquivos Markdown que descrevem como um agente de IA deve se comportar ao trabalhar em uma parte específica do projeto. Cada skill define: arquivos a ler primeiro, ações seguras, ações que exigem confirmação humana, e riscos a evitar.

## Skill para Alunos

| Skill | Propósito |
|---|---|
| [student-project-assistant](skills/student-project-assistant/SKILL.md) | Assistente do projeto — guia o aluno do zero à conclusão |

Mapa de progresso do aluno: [CHECKPOINTS.md](skills/student-project-assistant/CHECKPOINTS.md)

## Skills Base (para IAs que trabalham no repositório)

| Skill | Propósito |
|---|---|
| [operational-safety](skills/operational-safety/SKILL.md) | Regras de segurança operacional — leia sempre primeiro |
| [project-overview](skills/project-overview/SKILL.md) | Visão geral da arquitetura e convenções do projeto |
| [databricks-bundles](skills/databricks-bundles/SKILL.md) | Trabalhar com Databricks Asset Bundles |
| [job-ops](skills/job-ops/SKILL.md) | Criar e modificar jobs |
| [pipeline-ops](skills/pipeline-ops/SKILL.md) | Criar e modificar Spark Declarative Pipelines |
| [data-generator](skills/data-generator/SKILL.md) | Trabalhar com o gerador incremental de vendas |
| [analytics-insights](skills/analytics-insights/SKILL.md) | Analisar dados processados nas tabelas gold |
| [didactic-content](skills/didactic-content/SKILL.md) | Criar e manter material didático |

## Bônus: AI Engineering

| Skill | Propósito |
|---|---|
| [smart-data-generator](bonus/ai-engineering/skills/smart-data-generator/SKILL.md) | Agente que analisa padrões e gera dados sintéticos inteligentes |
| [smart-sales-analyst](bonus/ai-engineering/skills/smart-sales-analyst/SKILL.md) | Agente que interpreta dados processados e gera insights executivos |

Guia didático do bônus: [aula_ai_engineering.md](bonus/ai-engineering/aula_ai_engineering.md)

## Convenção de uso

Ao iniciar qualquer sessão de trabalho neste repositório:
1. Carregue `operational-safety` primeiro
2. Carregue `project-overview` para contexto geral
3. Carregue a skill específica para a tarefa em mãos
