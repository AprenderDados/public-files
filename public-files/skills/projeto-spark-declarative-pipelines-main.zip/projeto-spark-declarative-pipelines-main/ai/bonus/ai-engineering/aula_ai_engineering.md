# Aula: AI Engineering sobre um Lakehouse Real

## Visão geral

Esta aula demonstra como criar agentes de IA especializados para trabalhar sobre um pipeline de dados real no Databricks. Não é sobre "chatbots" genéricos — é sobre como uma IA que conhece o contexto do repositório se torna genuinamente útil.

**Duração estimada:** 90 minutos  
**Nível:** Intermediário (aluno que já completou os módulos 01–09 do curso)  
**Pré-requisito:** Projeto rodando com dados nas tabelas gold

---

## Parte 1: O que é uma Skill em AI Engineering?

### Definição pragmática

Uma **skill** (ou instrução de sistema) é um conjunto de instruções que ensina a uma IA:
- Qual é o contexto em que ela opera
- Quais arquivos deve ler antes de agir
- Quais ações são seguras
- Quais ações exigem confirmação humana
- Quais riscos deve evitar

Pense como um manual de integração para um novo desenvolvedor — só que o "desenvolvedor" é um agente de IA.

### Por que criar skills específicas de projeto?

Uma IA genérica sabe sobre Databricks, Spark e Python. Mas ela **não sabe**:
- Que o gerador de dados avança o estado e os IDs são irreversíveis
- Que `generation_state` não deve ser apagada
- Que jobs em `prd` exigem revisão humana
- Que os dados são sintéticos e "anomalias" podem ser artefatos de geração
- Que o schema de cada tabela está declarado em YAML em `config/tables/`

Sem esse contexto, a IA vai fazer perguntas desnecessárias, sugerir ações perigosas ou dar respostas genéricas que não funcionam neste projeto.

**Com uma skill bem escrita**, a IA age como se já conhecesse o repositório.

### O que uma skill típica contém

```markdown
# Nome e objetivo
# Quando usar / quando não usar
# Arquivos a ler primeiro
# Comandos seguros
# Ações que exigem confirmação
# Riscos específicos deste projeto
# Exemplos de tarefas
```

---

## Parte 2: Skills Base do Projeto

O projeto tem oito skills base em `ai/skills/`:

| Skill | Propósito |
|---|---|
| `operational-safety` | Regras de segurança — carregue sempre primeiro |
| `project-overview` | Arquitetura e convenções gerais |
| `databricks-bundles` | Como trabalhar com DABs |
| `job-ops` | Como criar e modificar jobs |
| `pipeline-ops` | Como trabalhar com pipelines declarativas |
| `data-generator` | Como usar o gerador incremental |
| `analytics-insights` | Como analisar os dados processados |
| `didactic-content` | Como criar material didático |

**Demonstração ao vivo:**
```
Abra uma sessão com um agente de IA
Carregue operational-safety + project-overview
Pergunte: "Quais tabelas existem na camada gold?"
Compare com uma pergunta sem skill carregada
```

**Ponto de reflexão para o aluno:**
> Com a skill carregada, a IA conhece o catálogo, o schema e o nome físico de cada tabela. Sem a skill, ela vai perguntar ou inventar.

---

## Parte 3: Por que criar uma skill geradora de dados?

### O problema sem IA

Rodar o gerador com defaults é simples. Mas o aluno não sabe:
- Qual é o volume "realista" para este conjunto de dados?
- Qual taxa de cancelamento faz sentido com base nos dados históricos?
- Como simular um pico de vendas com parâmetros credivelmente calibrados?

Para saber isso, ele teria que analisar as tabelas gold manualmente, calcular médias e converter em parâmetros — um trabalho analítico que pode ser delegado.

### O que a skill faz

A skill `smart-data-generator` instrui o agente a:

1. **Consultar** as tabelas gold para extrair padrões reais
2. **Calcular** os parâmetros corretos para o cenário desejado
3. **Apresentar o plano** ao usuário antes de executar
4. **Aguardar confirmação** e somente então disparar o gerador

Isso é AI Engineering aplicado: a IA conhece o sistema, extrai contexto dos dados e usa esse contexto para agir com inteligência.

### Demonstração ao vivo

```
Pergunte ao agente (com smart-data-generator carregado):
"Quero simular um pico de vendas de terça-feira. Analise os dados históricos
e me diga quais parâmetros usar."

O agente deve:
1. Executar a query de volume por dia da semana
2. Calcular a média e o desvio de terças-feiras
3. Propor target_rows = média × fator_de_pico
4. Mostrar o plano completo antes de qualquer execução
```

**Ponto de reflexão:**
> A IA não inventou um número. Ela extraiu o padrão dos dados reais e calculou um parâmetro baseado em evidência.

---

## Parte 4: Por que criar uma skill analista?

### O problema sem IA

Depois que a pipeline roda, o aluno tem tabelas gold cheias de dados. Para extrair valor, ele precisa:
- Escrever queries SQL para cada análise
- Interpretar os resultados em contexto
- Comunicar os achados em linguagem de negócio
- Saber quando um padrão é "normal para dados sintéticos" vs "anomalia real"

### O que a skill faz

A skill `smart-sales-analyst` instrui o agente a:

1. **Consultar** as tabelas gold com um conjunto pré-definido de queries analíticas
2. **Calcular** métricas de resumo, tendências e anomalias
3. **Contextualizar** os dados (sintéticos vs. comportamento real)
4. **Produzir** um resumo executivo em linguagem de negócio
5. **Sinalizar** pontos de atenção com clareza

### O diferencial: contextualização

Diferente de uma query SQL simples, o agente sabe que os dados são sintéticos. Isso permite que ele explique:
- "O volume uniforme entre produtos é esperado — o gerador usa mix calibrado"
- "A taxa de cancelamento de 1% é o padrão configurado, não uma anomalia"
- "O pico de terça-feira pode ter sido gerado intencionalmente"

Esse nível de contextualização só é possível porque a skill descreve como o sistema funciona.

### Demonstração ao vivo

```
Pergunte ao agente (com smart-sales-analyst carregado):
"Gere um resumo executivo dos dados de vendas desta semana."

O agente deve:
1. Consultar gold_daily_sales para a última semana
2. Calcular receita bruta, líquida, taxa de correção
3. Identificar o dia de maior volume
4. Explicar o que é comportamento esperado vs. anomalia
5. Produzir um relatório no formato Markdown
```

---

## Parte 5: Como isso se conecta com Spark Declarative Pipelines

### A IA como camada sobre o Lakehouse

```
[AdventureWorks] → [Gerador] → [Bronze] → [Silver] → [Gold] → [Dashboard]
                                                                     ↑
                                                         [Agente Analista]
                        ↑
              [Agente Gerador]
```

Os agentes **não substituem** nenhuma parte da pipeline. Eles se posicionam:
- O agente gerador atua **antes** da ingestão (parametriza o gerador)
- O agente analista atua **após** o processamento (interpreta o gold)

A pipeline Spark Declarative continua sendo o coração do sistema. Os agentes são uma camada de inteligência sobre ela.

### O que permanece em Spark

- Ingestão incremental com Auto Loader
- Qualidade declarativa com expectations
- Deduplicação e estado corrente de dimensões
- Dimensões conformadas e métricas gold

**Nada disso é substituído.** O Spark faz o que o Spark faz de melhor: processar dados em escala com garantias de qualidade.

---

## Parte 6: Cuidados ao permitir que uma IA rode jobs ou altere dados

### A regra fundamental

> **Uma IA que pode rodar jobs sem confirmação humana é um risco operacional.**

Por quê?

1. Jobs no Databricks geram custos de compute reais
2. Alguns jobs avançam estado de forma irreversível (gerador de dados)
3. Jobs em produção podem afetar dados que outros usuários dependem
4. Erros de parâmetro podem gerar dados inválidos que contaminam a pipeline

### O padrão seguro: Human-in-the-Loop

```
IA analisa → IA propõe plano → Humano aprova → IA executa
```

Todas as skills deste projeto seguem este padrão. A IA **nunca executa** ações destrutivas ou custosas sem confirmação explícita.

### O que a IA pode fazer sem confirmação

- Ler qualquer arquivo do repositório
- Consultar tabelas gold (SELECT)
- Analisar configurações YAML
- Propor planos e parâmetros

### O que a IA só faz após confirmação

- Executar jobs no Databricks
- Fazer deploy do bundle
- Gerar dados (avança estado do gerador)
- Modificar arquivos de configuração de produção
- Apagar qualquer arquivo ou tabela

---

## Exercícios para os alunos

### Exercício 1: Crie sua própria skill
Escolha um componente do projeto que você conhece bem e escreva uma skill para ele. A skill deve ter: objetivo, quando usar, arquivos a ler, ações seguras e ações que exigem confirmação.

### Exercício 2: Calibre o agente gerador
Use o agente `smart-data-generator` para:
1. Analisar os padrões dos dados históricos disponíveis
2. Propor parâmetros para um cenário de "segunda-feira típica"
3. Comparar os parâmetros sugeridos com os defaults do gerador

### Exercício 3: Gere um relatório executivo
Use o agente `smart-sales-analyst` para gerar um resumo executivo dos dados disponíveis. Depois responda:
- Que padrões você identificaria como "artefato de geração"?
- Que padrões você investigaria como "possível anomalia real"?
- Como você explicaria esse relatório para alguém sem contexto técnico?

### Exercício 4 (avançado): Critique a skill
Leia a skill `smart-data-generator` e identifique:
- Que cenário a skill não cobre?
- Que risco ela poderia endereçar melhor?
- Que informação adicional tornaria a skill mais útil?

---

## Conceitos apresentados nesta aula

| Conceito | O que é | Como aparece nesta aula |
|---|---|---|
| Skill / System Prompt | Instruções de contexto para um agente | `SKILL.md` de cada agente |
| Human-in-the-Loop | Confirmação humana antes de ações destrutivas | Fluxo de confirmação do gerador |
| Contextual AI | IA que conhece o sistema onde opera | Skill com arquivos, riscos e padrões |
| Agentic workflow | Agente que executa múltiplos passos | Fluxo de análise → plano → execução |
| Lakehouse Analytics | Análise sobre Delta Tables no Unity Catalog | Agente analista consultando tabelas gold |
| Synthetic Data Intelligence | IA que gera dados com base em padrões reais | Agente gerador calibrando parâmetros |

---

## Referências deste projeto

- Skills base: `ai/skills/`
- Skills de bônus: `ai/bonus/ai-engineering/skills/`
- Arquitetura: `docs/architecture.md`
- Modelo de dados: `docs/data_model.md`
- Gerador: `src/incremental_sales_generator/`
- Pipeline: `src/course_lakeflow/pipelines/`
