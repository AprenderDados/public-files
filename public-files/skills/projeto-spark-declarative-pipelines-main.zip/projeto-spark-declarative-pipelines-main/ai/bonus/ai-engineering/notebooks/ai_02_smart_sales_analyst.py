# Databricks notebook source
# COMMAND ----------

# MAGIC %md
# MAGIC # AI Engineering — Analista Inteligente de Vendas
# MAGIC
# MAGIC Este notebook consulta as tabelas gold do projeto, aplica modelos analíticos
# MAGIC (tendência, anomalia, concentração, SLA) e gera um relatório executivo interpretado por LLM.
# MAGIC
# MAGIC **Escala:** Projetado para tabelas gold com 1B+ linhas no OBT.
# MAGIC O relatório usa exclusivamente as tabelas pré-agregadas (`gold_daily_sales`,
# MAGIC `gold_daily_sales_by_product`, `gold_arrival_vs_business_date`, `gold_correction_impact`).
# MAGIC
# MAGIC **Modo:** Somente leitura — nenhum dado é modificado.
# MAGIC
# MAGIC **Como usar:**
# MAGIC 1. Ajuste `CATALOG`, `SCHEMA` e `PERIODO_DIAS` na célula de configuração
# MAGIC 2. Execute todas as células em sequência
# MAGIC 3. Leia o relatório gerado pela IA
# MAGIC 4. Use `ask("sua pergunta")` para análises de acompanhamento

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuração

# COMMAND ----------

from datetime import date, timedelta

MODEL        = "databricks-llama-4-maverick"
MAX_TOKENS   = 3000
PERIODO_DIAS = 30         # janela de análise padrão

data_fim    = date.today()
data_inicio = data_fim - timedelta(days=PERIODO_DIAS)

# Catálogo e schema — ajuste para seu ambiente
CATALOG = "main"
SCHEMA  = "lakeflow_dev"  # ajuste para o schema criado pelo 00_setup_workspace.py

# Tabelas gold (fully qualified names)
DAILY      = f"{CATALOG}.{SCHEMA}.gold_daily_sales"
BY_PRODUCT = f"{CATALOG}.{SCHEMA}.gold_daily_sales_by_product"
OBT        = f"{CATALOG}.{SCHEMA}.gold_sales_analytics_obt"
ARRIVAL    = f"{CATALOG}.{SCHEMA}.gold_arrival_vs_business_date"
CORRECTION = f"{CATALOG}.{SCHEMA}.gold_correction_impact"

print(f"Período:  {data_inicio} → {data_fim}  ({PERIODO_DIAS} dias)")
print(f"Catálogo: {CATALOG}.{SCHEMA}")
print(f"Modelo:   {MODEL}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Coleta de Dados — Tabelas Agregadas
# MAGIC
# MAGIC Todas as queries usam tabelas pré-agregadas — seguras para qualquer volume no OBT.

# COMMAND ----------

# Resumo do período (gold_daily_sales)
df_diario = spark.sql(f"""
SELECT
  MIN(sales_date)              AS primeira_venda,
  MAX(sales_date)              AS ultima_venda,
  COUNT(DISTINCT sales_date)   AS dias_com_dados,
  SUM(events_count)            AS total_eventos,
  SUM(correction_events_count) AS total_correcoes,
  ROUND(SUM(net_revenue), 2)   AS receita_liquida,
  SUM(net_quantity)            AS quantidade_total
FROM {DAILY}
WHERE sales_date BETWEEN '{data_inicio}' AND '{data_fim}'
""")

print("=== RESUMO DO PERÍODO ===")
display(df_diario)

# COMMAND ----------

# Série temporal com lag e média móvel de 7 dias (gold_daily_sales)
df_serie = spark.sql(f"""
SELECT
  sales_date,
  net_revenue,
  net_quantity,
  events_count,
  correction_events_count,
  LAG(net_revenue) OVER (ORDER BY sales_date)   AS receita_anterior,
  ROUND(
    (net_revenue - LAG(net_revenue) OVER (ORDER BY sales_date)) * 100.0
    / NULLIF(LAG(net_revenue) OVER (ORDER BY sales_date), 0), 1
  )                                              AS variacao_pct,
  ROUND(AVG(net_revenue) OVER (
    ORDER BY sales_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
  ), 2)                                          AS media_7d
FROM {DAILY}
WHERE sales_date BETWEEN '{data_inicio}' AND '{data_fim}'
ORDER BY sales_date
""")

print("=== SÉRIE TEMPORAL DIÁRIA ===")
display(df_serie)

# COMMAND ----------

# Top 10 produtos por receita líquida (gold_daily_sales_by_product)
df_produtos = spark.sql(f"""
SELECT
  product_name,
  COALESCE(product_category_name, 'Sem categoria')  AS categoria,
  COALESCE(product_subcategory_name, 'N/A')         AS subcategoria,
  ROUND(SUM(net_revenue), 2)   AS receita_total,
  SUM(net_quantity)            AS quantidade_total,
  SUM(events_count)            AS total_eventos
FROM {BY_PRODUCT}
WHERE sales_date BETWEEN '{data_inicio}' AND '{data_fim}'
GROUP BY product_name, product_category_name, product_subcategory_name
ORDER BY receita_total DESC
LIMIT 10
""")

print("=== TOP 10 PRODUTOS ===")
display(df_produtos)

# COMMAND ----------

# Mix por categoria com share de receita (gold_daily_sales_by_product)
df_categorias = spark.sql(f"""
SELECT
  COALESCE(product_category_name, 'Sem categoria') AS categoria,
  ROUND(SUM(net_revenue), 2)  AS receita_total,
  SUM(net_quantity)           AS quantidade_total,
  ROUND(
    SUM(net_revenue) * 100.0 / SUM(SUM(net_revenue)) OVER (), 2
  )                           AS share_pct
FROM {BY_PRODUCT}
WHERE sales_date BETWEEN '{data_inicio}' AND '{data_fim}'
GROUP BY product_category_name
ORDER BY receita_total DESC
""")

print("=== MIX POR CATEGORIA ===")
display(df_categorias)

# COMMAND ----------

# Distribuição de latência de dados (gold_arrival_vs_business_date)
df_latencia = spark.sql(f"""
SELECT
  DATEDIFF(arrival_date, sales_date)  AS dias_atraso,
  SUM(events_count)                   AS total_eventos,
  SUM(late_events_count)              AS eventos_tardios,
  ROUND(SUM(net_revenue), 2)          AS receita_afetada
FROM {ARRIVAL}
WHERE arrival_date BETWEEN '{data_inicio}' AND '{data_fim}'
GROUP BY DATEDIFF(arrival_date, sales_date)
ORDER BY dias_atraso
""")

print("=== LATÊNCIA DE DADOS ===")
display(df_latencia)

# COMMAND ----------

# Impacto financeiro de ajustes e cancelamentos (gold_correction_impact)
df_correcoes = spark.sql(f"""
SELECT
  event_type,
  SUM(correction_events_count)       AS total_correcoes,
  SUM(net_quantity_impact)           AS impacto_quantidade,
  ROUND(SUM(net_revenue_impact), 2)  AS impacto_receita
FROM {CORRECTION}
WHERE arrival_date BETWEEN '{data_inicio}' AND '{data_fim}'
GROUP BY event_type
ORDER BY event_type
""")

print("=== IMPACTO DE CORREÇÕES ===")
display(df_correcoes)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Modelos Analíticos
# MAGIC
# MAGIC Coleta os resultados em memória e calcula: tendência, anomalias (Z-score),
# MAGIC concentração de receita (Pareto) e SLA de latência.

# COMMAND ----------

# Coletar todos os resultados uma única vez
resumo_row      = df_diario.collect()[0]
serie_rows      = df_serie.collect()
produtos_rows   = df_produtos.collect()
categorias_rows = df_categorias.collect()
latencia_rows   = df_latencia.collect()
correcao_rows   = df_correcoes.collect()

total_eventos   = int(resumo_row["total_eventos"] or 0)
total_correcoes = int(resumo_row["total_correcoes"] or 0)
receita_total   = float(resumo_row["receita_liquida"] or 0)
dias_com_dados  = int(resumo_row["dias_com_dados"] or 0)

# --- Tendência e volatilidade ---
receitas = [float(r["net_revenue"] or 0) for r in serie_rows]
datas    = [str(r["sales_date"])         for r in serie_rows]

if receitas:
    media  = sum(receitas) / len(receitas)
    desvio = (sum((x - media) ** 2 for x in receitas) / len(receitas)) ** 0.5
    cv     = desvio / media if media > 0 else 0
else:
    media = desvio = cv = 0.0

if len(receitas) >= 14:
    media_recente  = sum(receitas[-7:])  / 7
    media_anterior = sum(receitas[-14:-7]) / 7
    tendencia_pct  = (media_recente - media_anterior) / media_anterior * 100 if media_anterior > 0 else 0
    tendencia_dir  = "crescimento" if tendencia_pct > 2 else ("queda" if tendencia_pct < -2 else "estável")
else:
    tendencia_pct = 0.0
    tendencia_dir = "dados insuficientes para calcular tendência"

# --- Anomalias por Z-score (|z| > 2.0) ---
anomalias = []
if desvio > 0:
    for d, r in zip(datas, receitas):
        z = (r - media) / desvio
        if abs(z) > 2.0:
            anomalias.append({"data": d, "receita": r, "z": z})

# --- Concentração de receita (Pareto top-3 produtos) ---
if produtos_rows and receita_total > 0:
    receita_top3 = sum(float(r["receita_total"] or 0) for r in produtos_rows[:3])
    share_top3   = receita_top3 / receita_total * 100
else:
    share_top3 = 0.0

top3_txt = "\n".join(
    f"  {i+1}. {r['product_name']} ({r['categoria']}) — USD {float(r['receita_total'] or 0):,.2f}"
    f" ({float(r['receita_total'] or 0) / receita_total * 100:.1f}%)" if receita_total > 0 else ""
    for i, r in enumerate(produtos_rows[:3])
)
mix_txt = "\n".join(
    f"  {r['categoria']}: {r['share_pct']}%"
    for r in categorias_rows
)

# --- SLA de latência ---
eventos_tardios = sum(int(r["eventos_tardios"] or 0) for r in latencia_rows if (r["dias_atraso"] or 0) > 0)
sla_atraso      = eventos_tardios / total_eventos * 100 if total_eventos > 0 else 0.0

# --- Taxa e impacto de correções ---
taxa_correcao   = total_correcoes / total_eventos * 100 if total_eventos > 0 else 0.0
impacto_cancel  = sum(float(r["impacto_receita"] or 0) for r in correcao_rows if r["event_type"] == "CANCEL")
impacto_adjust  = sum(float(r["impacto_receita"] or 0) for r in correcao_rows if r["event_type"] == "ADJUSTMENT")

# Imprimir resumo analítico
print("=== MODELOS ANALÍTICOS ===")
print(f"Receita média diária : USD {media:,.2f}")
print(f"Volatilidade (CV)    : {cv:.1%}")
print(f"Tendência (7d vs 7d) : {tendencia_dir} ({tendencia_pct:+.1f}%)")
print(f"Anomalias (|z|>2)    : {len(anomalias)} dia(s)")
for a in anomalias:
    sinal = "▲" if a["z"] > 0 else "▼"
    print(f"  {sinal} {a['data']} — USD {a['receita']:,.2f}  (z={a['z']:.1f}σ)")

print(f"\nConcentração top-3 produtos: {share_top3:.1f}%  {'⚠️ alta concentração' if share_top3 > 50 else '✓ distribuição saudável'}")
print(f"SLA de latência     : {sla_atraso:.2f}%  {'⚠️ acima do SLA de 5%' if sla_atraso > 5 else '✓ dentro do SLA'}")
print(f"Taxa de correção    : {taxa_correcao:.2f}%  {'⚠️ acima do padrão' if taxa_correcao > 10 else '✓ dentro do padrão'}")
print(f"Impacto cancelamentos: USD {impacto_cancel:,.2f}")
print(f"Impacto ajustes     : USD {impacto_adjust:,.2f}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Relatório Executivo — Gerado por IA

# COMMAND ----------

import mlflow.deployments

client = mlflow.deployments.get_deploy_client("databricks")

dados_para_analise = f"""
PERÍODO: {data_inicio} a {data_fim} ({PERIODO_DIAS} dias solicitados, {dias_com_dados} dias com dados)

=== VISÃO GERAL ===
Receita líquida:     USD {receita_total:,.2f}
Total de eventos:    {total_eventos:,}
Total de correções:  {total_correcoes:,}
Taxa de correção:    {taxa_correcao:.2f}%

=== MODELOS ANALÍTICOS ===
Receita média diária:  USD {media:,.2f}
Volatilidade (CV):     {cv:.1%}
Tendência (7d vs 7d):  {tendencia_dir} ({tendencia_pct:+.1f}%)
Anomalias detectadas:  {len(anomalias)} {'— nenhuma' if not anomalias else ''}
{chr(10).join(f"  {a['data']}: USD {a['receita']:,.2f} (z={a['z']:.1f}σ)" for a in anomalias)}
=== CONCENTRAÇÃO DE RECEITA ===
Top 3 produtos = {share_top3:.1f}% da receita total:
{top3_txt}

Mix por categoria:
{mix_txt}

=== QUALIDADE OPERACIONAL ===
Eventos tardios:        {sla_atraso:.2f}%  {'⚠️ acima do SLA' if sla_atraso > 5 else '✓ dentro do SLA de 5%'}
Impacto cancelamentos:  USD {impacto_cancel:,.2f}
Impacto ajustes:        USD {impacto_adjust:,.2f}
"""

_messages = [
    {
        "role": "system",
        "content": (
            "Você é o Analista Inteligente de Vendas deste projeto Databricks.\n\n"
            "Interprete os dados de vendas abaixo e produza um relatório executivo em Markdown.\n\n"
            "Contexto técnico importante:\n"
            "- Dados são SINTÉTICOS, gerados pelo incremental_sales_generator\n"
            "- Baseado em padrões históricos do AdventureWorks\n"
            "- Padrões artificiais (volume uniforme, cancelamentos ~1%) são esperados\n"
            "- Anomalias reais: cancelamento >10%, receita negativa, concentração >60% em top-3\n\n"
            "Produza o relatório com exatamente estas seções:\n"
            "1. Visão Geral (tabela de métricas)\n"
            "2. Tendências (série temporal, volatilidade, direção)\n"
            "3. Produtos e Categorias em Destaque\n"
            "4. Qualidade Operacional (latência + correções)\n"
            "5. Anomalias Detectadas (ou 'Nenhuma anomalia significativa')\n"
            "6. Próximas Ações Sugeridas (máximo 3, concretas e baseadas nos dados)\n\n"
            "Use dados concretos, diferencie comportamento esperado de alerta real. "
            "Formato: Markdown limpo, sem código."
        ),
    },
    {
        "role": "user",
        "content": f"Analise os dados a seguir e gere o relatório executivo:\n\n{dados_para_analise}",
    },
]

response = client.predict(
    endpoint=MODEL,
    inputs={"messages": _messages, "max_tokens": MAX_TOKENS, "temperature": 0.3},
)
relatorio_ia = response["choices"][0]["message"]["content"]
_messages.append({"role": "assistant", "content": relatorio_ia})

# COMMAND ----------

import re
import html as _html
from datetime import datetime


def _md_to_html(text: str) -> str:
    t = _html.escape(text)
    t = re.sub(
        r"```[^\n]*\n(.*?)```",
        r'<pre style="background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;overflow-x:auto;font-size:13px;">\1</pre>',
        t, flags=re.DOTALL,
    )
    t = re.sub(r"^#### (.+)$", r"<h4>\1</h4>", t, flags=re.MULTILINE)
    t = re.sub(r"^### (.+)$",  r"<h3>\1</h3>", t, flags=re.MULTILINE)
    t = re.sub(r"^## (.+)$",
               r"<h2 style='margin-top:20px;border-bottom:1px solid #e0e0e0;padding-bottom:6px;'>\1</h2>",
               t, flags=re.MULTILINE)
    t = re.sub(r"^# (.+)$",   r"<h1>\1</h1>", t, flags=re.MULTILINE)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\*(.+?)\*",     r"<em>\1</em>",         t)
    t = re.sub(r"`([^`]+)`",
               r'<code style="background:#f0f0f0;padding:1px 5px;border-radius:3px;font-family:monospace;">\1</code>', t)

    def _table(m):
        rows = [r.strip() for r in m.group(0).strip().split("\n") if r.strip()]
        html_rows = []
        is_first = True
        for row in rows:
            if re.match(r"^\|[-| :]+\|$", row):
                continue
            cols = [c.strip() for c in row.strip("|").split("|")]
            if is_first:
                html_rows.append(
                    "<tr>" + "".join(f'<th style="background:#f0f4f8;padding:6px 10px;text-align:left;border:1px solid #ddd;">{c}</th>' for c in cols) + "</tr>"
                )
                is_first = False
            else:
                html_rows.append(
                    "<tr>" + "".join(f'<td style="padding:5px 10px;border:1px solid #eee;">{c}</td>' for c in cols) + "</tr>"
                )
        return '<table style="border-collapse:collapse;width:100%;margin:10px 0;">' + "".join(html_rows) + "</table>"

    t = re.sub(r"(\|.+\|\n)+", _table, t)

    def _list_block(m):
        items = re.findall(r"^[-*] (.+)$", m.group(0), re.MULTILINE)
        return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"
    t = re.sub(r"(^[-*] .+\n?)+", _list_block, t, flags=re.MULTILINE)

    def _ol_block(m):
        items = re.findall(r"^\d+\. (.+)$", m.group(0), re.MULTILINE)
        return "<ol>" + "".join(f"<li>{i}</li>" for i in items) + "</ol>"
    t = re.sub(r"(^\d+\. .+\n?)+", _ol_block, t, flags=re.MULTILINE)

    t = re.sub(r"\n{2,}", "</p><p>", t)
    t = f"<p>{t}</p>"
    t = t.replace("\n", "<br>")
    return t


timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
displayHTML(f"""
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
            max-width:900px;margin:0 auto;line-height:1.7;">
  <div style="background:#0d2137;color:#fff;padding:14px 24px;
              border-radius:8px 8px 0 0;display:flex;justify-content:space-between;align-items:center;">
    <span style="font-size:18px;font-weight:700;">📊 Relatório Executivo de Vendas</span>
    <span style="font-size:11px;color:#aaa;">Gerado em {timestamp} · {MODEL}</span>
  </div>
  <div style="background:#fff;border:1px solid #ddd;border-top:none;
              padding:24px 32px;border-radius:0 0 8px 8px;color:#222;">
    {_md_to_html(relatorio_ia)}
  </div>
  <div style="color:#999;font-size:11px;padding:6px 4px;">
    💬 Perguntas de acompanhamento: <code>ask('sua pergunta')</code>
    &nbsp;·&nbsp; <code>reset_report()</code> para reiniciar a sessão
  </div>
</div>
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Análise Interativa — Perguntas de Acompanhamento
# MAGIC
# MAGIC Use `ask("sua pergunta")` para aprofundar qualquer ponto do relatório.
# MAGIC O agente mantém o contexto de toda a conversa.

# COMMAND ----------


def _display_user_q(msg: str) -> None:
    displayHTML(f"""
    <div style="font-family:sans-serif;max-width:900px;margin:4px 0;">
      <div style="background:#e8f4fd;border-left:4px solid #0066cc;
                  padding:10px 14px;border-radius:4px;color:#003366;">
        <span style="font-size:11px;font-weight:600;color:#0066cc;">VOCÊ</span><br>
        {_html.escape(msg)}
      </div>
    </div>
    """)


def _display_analyst(msg: str) -> None:
    displayHTML(f"""
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
                max-width:900px;margin:4px 0 16px 0;line-height:1.6;">
      <div style="background:#0d2137;color:#7ec8e3;
                  padding:6px 16px;border-radius:6px 6px 0 0;font-size:12px;font-weight:600;">
        📊 ANALISTA INTELIGENTE
      </div>
      <div style="background:#f9f9f9;border:1px solid #ddd;border-top:none;
                  padding:16px 24px;border-radius:0 0 6px 6px;color:#222;">
        {_md_to_html(msg)}
      </div>
    </div>
    """)


def ask(pergunta: str) -> None:
    """Faz uma pergunta de acompanhamento. O agente mantém o contexto do relatório."""
    _display_user_q(pergunta)
    _messages.append({"role": "user", "content": pergunta})
    response = client.predict(
        endpoint=MODEL,
        inputs={"messages": _messages, "max_tokens": 1500, "temperature": 0.3},
    )
    resposta = response["choices"][0]["message"]["content"]
    _messages.append({"role": "assistant", "content": resposta})
    _display_analyst(resposta)


def reset_report() -> None:
    """Reinicia a sessão de análise interativa (mantém o relatório inicial)."""
    global _messages
    _messages = _messages[:2]  # mantém system + primeiro relatório
    displayHTML("<div style='font-family:sans-serif;color:green;'>✅ Sessão reiniciada. Use <code>ask('sua pergunta')</code> para continuar.</div>")


# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Exemplos de perguntas de acompanhamento
# MAGIC
# MAGIC Execute uma célula por vez — o agente mantém o contexto entre elas.

# COMMAND ----------

ask("Qual produto ou categoria teve o maior crescimento nos últimos 7 dias?")

# COMMAND ----------

ask("Os cancelamentos estão dentro do esperado para dados sintéticos? Tem algum sinal de alerta?")

# COMMAND ----------

ask("Com base nessa análise, quais ações eu deveria tomar no pipeline ou na geração de dados?")
