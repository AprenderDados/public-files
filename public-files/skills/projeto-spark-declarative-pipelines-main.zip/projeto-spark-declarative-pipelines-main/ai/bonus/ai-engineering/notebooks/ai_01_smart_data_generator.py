# Databricks notebook source
# MAGIC %md
# MAGIC # AI Engineering — Gerador Inteligente de Dados
# MAGIC
# MAGIC Este notebook demonstra o agente `smart-data-generator`: uma IA que analisa
# MAGIC os padrões históricos das tabelas gold e propõe parâmetros calibrados para o gerador incremental.
# MAGIC
# MAGIC **Status:** Proposta didática — requer adaptação ao workspace do aluno
# MAGIC **Pré-requisito:** Tabelas gold populadas; `sales_profile_*` calibradas
# MAGIC **Modo:** Somente leitura até confirmação explícita do usuário

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 1: Resolver contexto do projeto

# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    # notebooks/ai_01... -> projeto_root é 3 níveis acima (ai/bonus/ai-engineering/notebooks)
    return workspace_path.parent.parent.parent.parent.parent


def _get_widget(name: str, default: str = "") -> str:
    if "dbutils" not in globals():
        return default
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

print(f"PROJECT_ROOT: {PROJECT_ROOT}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 2: Configuração

# COMMAND ----------

environment = _get_widget("environment", "dev")
cenario = _get_widget("cenario", "normal")  # normal, pico, anomalia, tardio

print(f"Ambiente: {environment}")
print(f"Cenário: {cenario}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 3: Análise de padrões históricos (somente leitura)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3.1 — Volume por dia da semana

# COMMAND ----------

df_weekday = spark.sql(f"""
SELECT
  DAYOFWEEK(sales_date) AS spark_day_of_week,
  CASE DAYOFWEEK(sales_date)
    WHEN 1 THEN 'Domingo'
    WHEN 2 THEN 'Segunda'
    WHEN 3 THEN 'Terça'
    WHEN 4 THEN 'Quarta'
    WHEN 5 THEN 'Quinta'
    WHEN 6 THEN 'Sexta'
    WHEN 7 THEN 'Sábado'
  END AS dia_semana,
  AVG(event_count) AS media_eventos,
  AVG(net_revenue) AS media_receita,
  COUNT(*) AS amostras
FROM gold_daily_sales
WHERE event_count > 0
GROUP BY spark_day_of_week
ORDER BY spark_day_of_week
""")

print("=== Volume por Dia da Semana ===")
display(df_weekday)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3.2 — Taxas históricas de ajuste e cancelamento

# COMMAND ----------

df_rates = spark.sql("""
SELECT
  event_type,
  COUNT(*) AS total_eventos,
  ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_do_total
FROM gold_sales_analytics_obt
GROUP BY event_type
""")

print("=== Distribuição de Tipos de Evento ===")
display(df_rates)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3.3 — Mix de produtos por categoria

# COMMAND ----------

df_product_mix = spark.sql("""
SELECT
  category_name,
  COUNT(*) AS total_eventos,
  ROUND(SUM(amount_delta), 2) AS receita_total,
  ROUND(SUM(amount_delta) * 100.0 / SUM(SUM(amount_delta)) OVER (), 2) AS share_receita_pct
FROM gold_sales_analytics_obt
WHERE event_type = 'SALE'
  AND category_name IS NOT NULL
GROUP BY category_name
ORDER BY share_receita_pct DESC
""")

print("=== Mix de Produtos por Categoria ===")
display(df_product_mix)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3.4 — Estatísticas de volume diário

# COMMAND ----------

df_daily_stats = spark.sql("""
SELECT
  MIN(event_count) AS min_eventos_dia,
  MAX(event_count) AS max_eventos_dia,
  ROUND(AVG(event_count), 0) AS media_eventos_dia,
  PERCENTILE_APPROX(event_count, 0.5) AS mediana_eventos_dia,
  PERCENTILE_APPROX(event_count, 0.95) AS p95_eventos_dia
FROM gold_daily_sales
WHERE event_count > 0
""")

print("=== Estatísticas de Volume Diário ===")
display(df_daily_stats)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 4: Calcular parâmetros para o cenário escolhido

# COMMAND ----------

from pyspark.sql import functions as F

# Coletar estatísticas para cálculo
stats = df_daily_stats.collect()[0]
media_diaria = int(stats["media_eventos_dia"])
p95_diario = int(stats["p95_eventos_dia"])

rates = {row["event_type"]: float(row["pct_do_total"]) / 100.0 for row in df_rates.collect()}
adjustment_rate = rates.get("ADJUSTMENT", 0.03)
cancel_rate = rates.get("CANCEL", 0.01)

# Definir target_rows baseado no cenário
cenario_params = {
    "normal": {
        "target_rows": media_diaria,
        "late_adjustment_rate": round(adjustment_rate, 3),
        "cancel_rate": round(cancel_rate, 3),
        "descricao": f"Volume normal — média histórica ({media_diaria} eventos/dia)",
    },
    "pico": {
        "target_rows": min(p95_diario * 3, 5000),
        "late_adjustment_rate": round(min(adjustment_rate * 2, 0.15), 3),
        "cancel_rate": round(min(cancel_rate * 3, 0.08), 3),
        "descricao": f"Pico de vendas — 3× percentil 95 ({p95_diario * 3} eventos/dia)",
    },
    "anomalia": {
        "target_rows": media_diaria,
        "late_adjustment_rate": round(adjustment_rate, 3),
        "cancel_rate": 0.40,
        "descricao": "Anomalia de qualidade — 40% cancelamentos (intencional para teste)",
    },
    "tardio": {
        "target_rows": media_diaria,
        "late_adjustment_rate": round(adjustment_rate, 3),
        "cancel_rate": round(cancel_rate, 3),
        "descricao": f"Dado tardio — business_date 5 dias no passado, arrival_date = hoje",
    },
}

params = cenario_params.get(cenario, cenario_params["normal"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 5: Apresentar o plano (aguarda confirmação humana)

# COMMAND ----------

from datetime import date, timedelta

today = date.today()
business_date_proposta = today - timedelta(days=5) if cenario == "tardio" else today

plano = f"""
╔══════════════════════════════════════════════════════════════════╗
║          PLANO DE GERAÇÃO DE DADOS — AGUARDA CONFIRMAÇÃO        ║
╠══════════════════════════════════════════════════════════════════╣
║ Cenário:              {cenario:<42} ║
║ Descrição:            {params['descricao'][:42]:<42} ║
╠══════════════════════════════════════════════════════════════════╣
║ ANÁLISE DOS DADOS HISTÓRICOS                                    ║
║   Média diária histórica:    {media_diaria:<35} ║
║   Percentil 95 diário:       {p95_diario:<35} ║
║   Taxa de ajuste histórica:  {adjustment_rate:.1%}{"":<32} ║
║   Taxa de cancelamento hist: {cancel_rate:.1%}{"":<32} ║
╠══════════════════════════════════════════════════════════════════╣
║ PARÂMETROS CALCULADOS                                           ║
║   target_rows:           {params['target_rows']:<38} ║
║   late_adjustment_rate:  {params['late_adjustment_rate']:<38} ║
║   cancel_rate:           {params['cancel_rate']:<38} ║
║   business_date:         {str(business_date_proposta):<38} ║
║   arrival_date:          {str(today):<38} ║
║   environment:           {environment:<38} ║
╠══════════════════════════════════════════════════════════════════╣
║ IMPACTO ESTIMADO                                                ║
║   SALE:        ~{params['target_rows']:<47} ║
║   ADJUSTMENT:  ~{int(params['target_rows'] * params['late_adjustment_rate']):<47} ║
║   CANCEL:      ~{int(params['target_rows'] * params['cancel_rate']):<47} ║
║   TOTAL:       ~{int(params['target_rows'] * (1 + params['late_adjustment_rate'] + params['cancel_rate'])):<47} ║
╠══════════════════════════════════════════════════════════════════╣
║ ⚠️  Esta ação avança o estado do gerador de forma irreversível.  ║
║ ⚠️  Execute apenas se confirmar os parâmetros acima.             ║
╚══════════════════════════════════════════════════════════════════╝

Para executar, rode a próxima célula com EXECUTAR_GERACAO = True
"""

print(plano)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Passo 6: Execução (somente após confirmação explícita)
# MAGIC
# MAGIC ⚠️ **ATENÇÃO:** Mude `EXECUTAR_GERACAO = True` somente se revisar e aprovar o plano acima.

# COMMAND ----------

# Mude para True somente após revisar e aprovar o plano acima
EXECUTAR_GERACAO = False

if EXECUTAR_GERACAO:
    from incremental_sales_generator.config import GeneratorRunConfig
    from incremental_sales_generator.sales_event_generator import SalesEventGenerator

    run_config = GeneratorRunConfig(
        environment=environment,
        business_date=str(business_date_proposta),
        arrival_date=str(today) if cenario == "tardio" else None,
        target_rows=params["target_rows"],
        late_adjustment_rate=params["late_adjustment_rate"],
        cancel_rate=params["cancel_rate"],
        random_seed=42,
    )

    generator = SalesEventGenerator(spark, PROJECT_ROOT)
    result = generator.generate_batch(run_config)

    print("✅ Geração concluída:")
    print(generator.as_dict(result))
else:
    print("⏸️  Execução pausada. Defina EXECUTAR_GERACAO = True para gerar os dados.")
    print("   Revise o plano na célula anterior antes de continuar.")
