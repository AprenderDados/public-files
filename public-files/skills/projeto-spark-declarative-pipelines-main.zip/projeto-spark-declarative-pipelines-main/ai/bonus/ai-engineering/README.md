# Bônus: AI Engineering — Agentes sobre o Lakehouse

## O que é este bônus?

Este bônus adiciona uma camada de **AI Engineering** ao projeto Spark Declarative Pipelines. Não reescreve o projeto existente — apenas adiciona dois agentes didáticos que usam o projeto como base de dados real.

## Objetivo

Demonstrar como um agente de IA pode:
1. **Entender e instrumentalizar** um pipeline de dados existente
2. **Gerar dados sintéticos inteligentes** com base em padrões reais
3. **Interpretar resultados analíticos** e comunicar insights em linguagem de negócio

## Os dois agentes

### Agente 1: Gerador Inteligente de Dados
**Skill:** [smart-data-generator](skills/smart-data-generator/SKILL.md)

Analisa as tabelas gold para extrair padrões reais (volume por dia da semana, mix de produtos, taxas de cancelamento) e usa esse conhecimento para parametrizar o gerador existente de forma inteligente. Permite simular cenários específicos: volume normal, pico de vendas, anomalia de qualidade, dados tardios.

**O que não faz:** não gera dados sem confirmação humana. Sempre apresenta o plano antes de executar.

### Agente 2: Analista Inteligente de Vendas
**Skill:** [smart-sales-analyst](skills/smart-sales-analyst/SKILL.md)

Consulta as tabelas gold e produz resumos executivos, identifica tendências, picos e anomalias. Sabe distinguir comportamento esperado de dados sintéticos versus anomalias reais.

**O que não faz:** não executa jobs nem modifica dados. Somente leitura.

---

## Arquitetura do bônus

```
[Projeto existente — sem mudanças]
  gold_sales_analytics_obt
  gold_daily_sales
  gold_daily_sales_by_product
  gold_arrival_vs_business_date
  gold_correction_impact
         ↓ (leitura apenas)
[Agente 1: smart-data-generator]     [Agente 2: smart-sales-analyst]
  Analisa padrões                      Consulta resultados
  Parametriza gerador                  Gera resumo executivo
  Apresenta plano                      Identifica anomalias
  Aguarda confirmação                  Sugere próximas ações
         ↓ (com confirmação)
[Gerador existente — sem mudanças]
  02_generate_sales_batch.py
```

---

## O que foi adicionado ao projeto

```
ai/
  bonus/
    ai-engineering/
      README.md                          (este arquivo)
      aula_ai_engineering.md            (roteiro didático da aula)
      skills/
        smart-data-generator/SKILL.md   (skill do agente gerador)
        smart-sales-analyst/SKILL.md    (skill do agente analista)
      notebooks/                        (proposto — ver aula)
        ai_01_smart_data_generator.py   (PROPOSTO — não criado ainda)
        ai_02_smart_sales_analyst.py    (PROPOSTO — não criado ainda)
```

## O que NÃO foi alterado

- Nenhum arquivo existente foi modificado
- Nenhum job ou pipeline foi alterado
- Nenhum dado foi gerado ou apagado
- Nenhuma dependência nova foi adicionada

---

## Como usar este bônus em aula

1. **Fase 1** — Mostre o projeto funcionando sem a IA (fluxo normal)
2. **Fase 2** — Carregue a skill `smart-data-generator` e mostre a análise de padrões
3. **Fase 3** — Mostre como a IA parametriza o gerador com base nos dados
4. **Fase 4** — Gere um batch com os parâmetros calculados (com confirmação ao vivo)
5. **Fase 5** — Carregue a skill `smart-sales-analyst` e gere um resumo executivo
6. **Fase 6** — Discussão: o que muda quando a IA conhece o contexto do projeto?

Roteiro completo: [aula_ai_engineering.md](aula_ai_engineering.md)

---

## Pré-requisitos para usar o bônus

- Pipeline executada ao menos uma vez com dados
- Tabelas gold populadas no workspace
- Tabelas de perfil do gerador calibradas (`sales_profile_*`)
