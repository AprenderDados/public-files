# Skill: Analista Inteligente de Vendas

## Nome
`smart-sales-analyst`

## Objetivo
Agente de AI Engineering que consulta as tabelas gold do projeto, aplica modelos analíticos
(tendência, anomalia, concentração, SLA) e produz relatórios executivos diários interpretados
por LLM — funcionando como um analista sênior que conhece tanto os dados quanto o processo
de geração.

## Quando usar
- Quando o usuário quer um relatório executivo diário ou semanal automatizado
- Quando quer identificar tendências, anomalias ou comportamentos inesperados
- Quando quer análise além de SQL puro (trend, anomaly detection, Pareto)
- Como demonstração de IA aplicada em analytics no Lakehouse

## Quando não usar
- Para análises técnicas de pipeline (use `analytics-insights`)
- Para gerar novos dados (use `smart-data-generator`)
- Quando o usuário quer uma query específica sem interpretação

## Pré-requisitos
- Tabelas gold disponíveis e populadas no workspace
- Pipeline executada ao menos uma vez com dados

## Arquivos a ler primeiro

```
ai/skills/analytics-insights/SKILL.md    (skill base — ler primeiro)
docs/data_model.md
config/tables/gold/*.yml
```

---

## Fluxo de trabalho do agente

```
[1] COLETAR
    Queries nas tabelas gold agregadas (somente leitura, scale-safe)
         ↓
[2] CALCULAR
    Modelos analíticos: tendência, anomalia, concentração, SLA de latência
         ↓
[3] INTERPRETAR
    Identificar padrões, separar sinal do ruído, anomalias reais vs. esperadas
         ↓
[4] CONTEXTUALIZAR
    Distinguir: comportamento do gerador × comportamento real × anomalia técnica
         ↓
[5] COMUNICAR
    Relatório executivo em linguagem de negócio, gerado via LLM
```

---

## Estratégia de escala

A tabela `gold_sales_analytics_obt` (OBT) pode ter bilhões de linhas.
O agente deve evitar full scans nela para relatórios.

| Necessidade | Tabela a usar | Motivo |
|---|---|---|
| Totais diários de receita e volume | `gold_daily_sales` | Pré-agregada por dia — sempre pequena |
| Top produtos por receita | `gold_daily_sales_by_product` | Pré-agregada por dia+produto |
| Latência de dados | `gold_arrival_vs_business_date` | Pré-agregada por arrival+sales date |
| Impacto de correções | `gold_correction_impact` | Pré-agregada por arrival+sales+event_type |
| Territórios e segmentos | OBT com `GROUP BY` + filtro de data obrigatório | Agregação empurrada para Spark |
| Análise exploratória de evento individual | OBT com `TABLESAMPLE` ou `LIMIT 1000000` | Scan limitado |

**Regra:** Para o relatório diário, use exclusivamente as tabelas agregadas.
Consulte a OBT diretamente somente com filtro explícito de data.

---

## Schemas das tabelas gold

### gold_daily_sales
`sales_date`, `net_quantity`, `net_revenue`, `events_count`, `correction_events_count`

### gold_daily_sales_by_product
`sales_date`, `product_id`, `product_name`, `product_category_name`, `product_subcategory_name`,
`net_quantity`, `net_revenue`, `events_count`

### gold_arrival_vs_business_date
`arrival_date`, `sales_date`, `events_count`, `net_quantity`, `net_revenue`, `late_events_count`

### gold_correction_impact
`arrival_date`, `sales_date`, `event_type`, `correction_events_count`,
`net_quantity_impact`, `net_revenue_impact`

### gold_sales_analytics_obt (OBT — bilhões de linhas em produção)
`sales_event_id`, `event_type`, `sales_date`, `arrival_date`, `product_id`, `product_name`,
`product_category_name`, `product_subcategory_name`, `customer_id`, `customer_name`,
`customer_segment`, `territory_name`, `country_region_name`, `quantity_delta`, `amount_delta`

---

## Queries — relatório diário (todas scale-safe)

### 1. Resumo do período

```sql
SELECT
  MIN(sales_date)              AS primeira_venda,
  MAX(sales_date)              AS ultima_venda,
  COUNT(DISTINCT sales_date)   AS dias_com_dados,
  SUM(events_count)            AS total_eventos,
  SUM(correction_events_count) AS total_correcoes,
  ROUND(SUM(net_revenue), 2)   AS receita_liquida,
  SUM(net_quantity)            AS quantidade_total
FROM gold_daily_sales
WHERE sales_date BETWEEN :data_inicio AND :data_fim
```

### 2. Série temporal com lag e média móvel

```sql
SELECT
  sales_date,
  net_revenue,
  net_quantity,
  events_count,
  correction_events_count,
  LAG(net_revenue) OVER (ORDER BY sales_date)  AS receita_anterior,
  ROUND(
    (net_revenue - LAG(net_revenue) OVER (ORDER BY sales_date)) * 100.0
    / NULLIF(LAG(net_revenue) OVER (ORDER BY sales_date), 0), 1
  )                                             AS variacao_pct,
  AVG(net_revenue) OVER (
    ORDER BY sales_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
  )                                             AS media_7d
FROM gold_daily_sales
WHERE sales_date BETWEEN :data_inicio AND :data_fim
ORDER BY sales_date
```

### 3. Top produtos por receita

```sql
SELECT
  product_name,
  COALESCE(product_category_name, 'Sem categoria')  AS categoria,
  COALESCE(product_subcategory_name, 'N/A')         AS subcategoria,
  ROUND(SUM(net_revenue), 2)  AS receita_total,
  SUM(net_quantity)           AS quantidade_total,
  SUM(events_count)           AS total_eventos
FROM gold_daily_sales_by_product
WHERE sales_date BETWEEN :data_inicio AND :data_fim
GROUP BY product_name, product_category_name, product_subcategory_name
ORDER BY receita_total DESC
LIMIT 10
```

### 4. Mix por categoria

```sql
SELECT
  COALESCE(product_category_name, 'Sem categoria') AS categoria,
  ROUND(SUM(net_revenue), 2)  AS receita_total,
  SUM(net_quantity)           AS quantidade_total,
  ROUND(
    SUM(net_revenue) * 100.0 / SUM(SUM(net_revenue)) OVER (), 2
  )                           AS share_pct
FROM gold_daily_sales_by_product
WHERE sales_date BETWEEN :data_inicio AND :data_fim
GROUP BY product_category_name
ORDER BY receita_total DESC
```

### 5. Latência de dados

```sql
SELECT
  DATEDIFF(arrival_date, sales_date)  AS dias_atraso,
  SUM(events_count)                   AS total_eventos,
  SUM(late_events_count)              AS eventos_tardios,
  ROUND(SUM(net_revenue), 2)          AS receita_afetada
FROM gold_arrival_vs_business_date
WHERE arrival_date BETWEEN :data_inicio AND :data_fim
GROUP BY DATEDIFF(arrival_date, sales_date)
ORDER BY dias_atraso
```

### 6. Impacto de correções

```sql
SELECT
  event_type,
  SUM(correction_events_count)       AS total_correcoes,
  SUM(net_quantity_impact)           AS impacto_quantidade,
  ROUND(SUM(net_revenue_impact), 2)  AS impacto_receita
FROM gold_correction_impact
WHERE arrival_date BETWEEN :data_inicio AND :data_fim
GROUP BY event_type
ORDER BY event_type
```

---

## Modelos analíticos aplicados

Após coletar os dados, o agente calcula antes de chamar o LLM:

### 1. Tendência e volatilidade
- **Média 7 dias vs. 7 dias anteriores:** identifica direção (crescimento / queda / estável)
- **Coeficiente de variação (std/mean):** mede volatilidade da receita diária

### 2. Detecção de anomalias (Z-score)
- Calcula média e desvio padrão da série de receita diária
- Dias com `|z| > 2.0` são marcados como anômalos (pico ou queda)
- Reporta data, valor e magnitude em sigmas

### 3. Concentração de receita (Pareto)
- % da receita total nos top-3 produtos
- % da receita total por categoria
- Alerta se top-3 produtos > 50% do total

### 4. SLA de latência
- % de eventos com `arrival_date > sales_date`
- SLA esperado: ≤ 5% de eventos tardios
- Alerta se > 5%

### 5. Taxa de correção
- `(total_correcoes / total_eventos) * 100`
- Padrão do gerador: ~1–2%
- Alerta se > 10%

---

## Regras de interpretação e contextualização

| Observação | Interpretação provável |
|---|---|
| Volume uniforme entre produtos | Distribuição uniforme do gerador (esperado em dev) |
| Cancelamentos ~1% | `cancel_rate` padrão do gerador |
| Sem sazonalidade de longo prazo | Gerador gera dia a dia sem tendência histórica real |
| Pico abrupto em um dia | `target_rows` foi elevado naquele batch |
| Dados com 5+ dias de atraso | `business_date` != `arrival_date` na geração |

### Quando reportar como anomalia real
- Cancelamento > 10% em múltiplos dias consecutivos
- `net_revenue` negativo em um dia
- Top-3 produtos acima de 60% da receita total
- > 15% dos eventos chegando com atraso

---

## Formato de saída — Relatório Executivo Diário

```markdown
# Relatório de Vendas — [data_inicio] a [data_fim]
Gerado em: [timestamp]

## Visão Geral

| Métrica | Valor |
|---|---|
| Período analisado | X dias |
| Receita líquida | USD X.XXX,XX |
| Total de eventos | X.XXX |
| Taxa de correção | X,X% |
| Eventos tardios | X,X% |

## Tendências

[2–3 parágrafos: série temporal, dias de pico, direção da tendência, volatilidade]

## Produtos e Categorias em Destaque

**Top contribuintes de receita:**
1. Produto A (Categoria X) — USD X.XXX (XX% da receita)

**Mix por categoria:** [tabela resumida]

## Qualidade Operacional

[Análise de latência e correções — SLA, impactos financeiros]

## Anomalias Detectadas

- [Dia X: receita Z% acima da média — z=X.Xσ]
- [Ou: nenhuma anomalia significativa detectada]

## Contexto de Dados Sintéticos

[O que é esperado do gerador vs. o que pode ser real]

## Próximas Ações Sugeridas

1. [Ação concreta baseada nos dados]
2. [Ação concreta baseada nos dados]
```

---

## Template de prompt interno

```
Você é o Analista Inteligente de Vendas deste projeto Databricks.

Interprete os dados abaixo e produza um relatório executivo em Markdown.

Contexto técnico:
- Dados são SINTÉTICOS, gerados pelo incremental_sales_generator
- Baseado em padrões históricos do AdventureWorks
- Padrões artificiais (volume uniforme, cancelamentos ~1%) são esperados
- Anomalias reais: cancelamento >10%, receita negativa, concentração >60% em top-3

Os dados fornecidos incluem:
1. Resumo agregado do período (gold_daily_sales)
2. Top produtos e mix por categoria (gold_daily_sales_by_product)
3. Latência de dados (gold_arrival_vs_business_date)
4. Impacto de correções (gold_correction_impact)
5. Modelos analíticos: tendência (7d vs 7d), anomalias (Z-score), concentração Pareto, SLA

Produza o relatório com as seções: Visão Geral, Tendências, Produtos e Categorias,
Qualidade Operacional, Anomalias, Próximas Ações (máximo 3).

Restrições:
- Nunca modifique dados nem execute jobs
- Informe quando não houver dados suficientes
- Diferencie sempre: dados sintéticos vs. possível problema real
```

---

## Tipos de análise disponíveis

| Análise | Quando usar |
|---|---|
| Relatório executivo diário | Visão geral automática do período disponível |
| Análise de período específico | "Analise a última semana" |
| Diagnóstico de anomalia | "Por que a receita caiu na quinta?" |
| Concentração de produtos | "Quais categorias estão dominando?" |
| Análise de qualidade de dados | "Os dados estão chegando dentro do SLA?" |
| Impacto de correções | "Quanto os cancelamentos custaram esta semana?" |
| Análise por território | "Quais regiões cresceram mais nos últimos 14 dias?" |

---

## Exemplos de tarefas

- "Gere o relatório diário de vendas"
- "Identifique anomalias no último mês"
- "Compare Bikes vs. Accessories por receita"
- "Qual o impacto financeiro dos cancelamentos desta semana?"
- "Os dados estão chegando dentro do SLA?"
- "Qual região cresceu mais nos últimos 14 dias?"
- "Explique para um diretor o que está acontecendo com as vendas"
