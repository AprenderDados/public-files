# Skill: Gerador Inteligente de Dados

## Nome
`smart-data-generator`

## Objetivo
Agente de AI Engineering que analisa padrões dos dados históricos do projeto (AdventureWorks e tabelas gold) e orquestra o gerador existente com parâmetros calibrados de forma inteligente — produzindo dados sintéticos mais realistas e permitindo cenários didáticos específicos.

## Quando usar
- Quando o usuário quer gerar dados que reflitam padrões reais (não apenas defaults)
- Quando quer simular um cenário específico (pico de vendas, anomalia, sazonalidade)
- Quando quer entender os padrões dos dados antes de gerar
- Como demonstração didática de como uma IA pode instrumentalizar um pipeline existente

## Quando não usar
- Para geração simples com defaults (use o job `generate_sales_batch_job` diretamente)
- Para análise de resultados após geração (use `smart-sales-analyst`)
- Em ambientes de produção sem supervisão humana

## Pré-requisitos
- Skill `operational-safety` carregada
- Tabelas gold disponíveis no workspace (`gold_daily_sales`, `gold_sales_analytics_obt`)
- Tabelas de perfil do gerador calibradas (`sales_profile_*`)

## Arquivos a ler primeiro

```
ai/skills/data-generator/SKILL.md        (skill base — ler primeiro)
src/incremental_sales_generator/config.py
src/incremental_sales_generator/sales_batch_planner.py
config/generator/sales_generator.yml
config/environments/base.yml
notebooks/02_generate_sales_batch.py
```

---

## Fluxo de trabalho do agente

```
[1] EXPLORAR
    Ler tabelas gold para extrair padrões
         ↓
[2] INTERPRETAR
    Identificar: volume médio, distribuição semanal, mix de produtos,
    territórios dominantes, taxa real de cancelamentos
         ↓
[3] PARAMETRIZAR
    Traduzir os padrões em parâmetros do GeneratorRunConfig
         ↓
[4] CONFIRMAR COM USUÁRIO
    Apresentar o plano antes de qualquer execução
         ↓
[5] ORQUESTRAR (somente após confirmação)
    Chamar o notebook/job com os parâmetros calculados
```

---

## Análise que o agente deve realizar

### Fase 1: Volume e distribuição temporal

```sql
-- Volume médio por dia da semana
SELECT
  DAYOFWEEK(sales_date) AS day_of_week,
  AVG(net_revenue) AS avg_daily_revenue,
  AVG(event_count) AS avg_daily_events
FROM gold_daily_sales
GROUP BY day_of_week
ORDER BY day_of_week
```

Resultado esperado: identificar dias com maior e menor volume.

```sql
-- Volume por semana (tendência)
SELECT
  DATE_TRUNC('week', sales_date) AS week,
  SUM(net_revenue) AS weekly_revenue,
  SUM(event_count) AS weekly_events
FROM gold_daily_sales
GROUP BY week
ORDER BY week
```

### Fase 2: Mix de produtos

```sql
-- Top categorias por participação
SELECT
  category_name,
  COUNT(*) AS event_count,
  SUM(amount_delta) AS total_revenue,
  ROUND(SUM(amount_delta) * 100.0 / SUM(SUM(amount_delta)) OVER (), 2) AS revenue_share_pct
FROM gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY category_name
ORDER BY revenue_share_pct DESC
```

### Fase 3: Taxas de correção

```sql
-- Taxas reais de ajuste e cancelamento
SELECT
  event_type,
  COUNT(*) AS event_count,
  ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_of_total
FROM gold_sales_analytics_obt
GROUP BY event_type
```

### Fase 4: Valores médios

```sql
-- Ticket médio por categoria
SELECT
  category_name,
  AVG(amount_delta) AS avg_ticket,
  PERCENTILE_APPROX(amount_delta, 0.5) AS median_ticket,
  PERCENTILE_APPROX(amount_delta, 0.95) AS p95_ticket
FROM gold_sales_analytics_obt
WHERE event_type = 'SALE'
GROUP BY category_name
ORDER BY avg_ticket DESC
```

---

## Tradução de padrões em parâmetros

Após a análise, o agente monta o `GeneratorRunConfig`:

```python
# Exemplo: pico de segunda-feira baseado em dados históricos
GeneratorRunConfig(
    environment="dev",
    business_date="2025-02-03",   # próxima segunda-feira
    target_rows=850,              # 42% acima da média (padrão identificado)
    late_adjustment_rate=0.04,   # 4% de ajustes (padrão identificado)
    cancel_rate=0.008,            # 0.8% de cancelamentos (padrão identificado)
    random_seed=42,
)
```

---

## Cenários pré-definidos

### Volume normal
```
target_rows = média histórica diária
late_adjustment_rate = taxa histórica
cancel_rate = taxa histórica
```

### Pico de vendas (ex: Black Friday)
```
target_rows = 3× a 5× a média histórica
late_adjustment_rate = 0.08   (mais ajustes em volume alto)
cancel_rate = 0.05            (mais cancelamentos em pico)
```

### Anomalia de qualidade
```
target_rows = volume normal
cancel_rate = 0.40            (40% cancelamentos — anomalia intencional)
```

### Atraso de dados (dado chegando tarde)
```
business_date = D-5
arrival_date  = D (hoje)
target_rows = volume daquele dia
```

### Múltiplos dias em sequência
```
Rodar N vezes com business_date = D+1, D+2, ... D+N
Apresentar o plano completo antes de rodar
```

---

## Template de prompt interno do agente

```
Você é o Gerador Inteligente de Dados deste projeto Databricks.

Seu objetivo é analisar os dados históricos disponíveis nas tabelas gold e
propor parâmetros realistas para o gerador incremental de vendas.

Fluxo obrigatório:
1. Consulte as tabelas gold (somente leitura).
2. Extraia: volume médio por dia da semana, taxa de cancelamento, taxa de ajuste,
   top categorias de produto, ticket médio.
3. Pergunte ao usuário qual cenário deseja simular:
   - Volume normal
   - Pico de vendas
   - Anomalia de qualidade
   - Chegada atrasada
   - Período customizado
4. Monte os parâmetros do GeneratorRunConfig com base nos dados históricos
   e no cenário escolhido.
5. APRESENTE O PLANO ao usuário antes de qualquer execução.
6. Somente execute após confirmação explícita.
7. Não execute jobs em acc ou prd sem confirmação adicional.

Restrições inegociáveis:
- Nunca execute o gerador sem confirmação do usuário.
- Nunca apague tabelas de estado.
- Nunca gere dados em prd sem revisão humana.
```

---

## Formato de apresentação do plano

Antes de executar, apresente ao usuário:

```markdown
## Plano de Geração de Dados

### Análise dos dados históricos
- Volume médio diário: 587 eventos
- Taxa de cancelamento histórica: 1.2%
- Taxa de ajuste histórica: 3.1%
- Categorias dominantes: Bikes (62%), Components (24%), Accessories (14%)

### Parâmetros calculados para o cenário solicitado
- Cenário: Pico de vendas (3ª semana do mês)
- business_date: 2025-02-17 (segunda-feira)
- target_rows: 1.800 (3× a média)
- late_adjustment_rate: 0.08
- cancel_rate: 0.04
- random_seed: 42

### Impacto esperado
- ~1.800 eventos SALE
- ~144 eventos ADJUSTMENT
- ~72 eventos CANCEL
- Total: ~2.016 linhas no arquivo CSV

Confirma a execução? (sim/não)
```

---

## Ações que exigem confirmação do usuário

- Executar o gerador (qualquer execução)
- Gerar múltiplos batches em sequência
- Usar cenário de anomalia (dados intencionalmente inválidos)
- Gerar dados em `arrival_date != business_date` (dado tardio)

---

## Riscos específicos desta skill

| Risco | Mitigação |
|---|---|
| Avançar business_date acidentalmente | Mostrar business_date no plano antes de executar |
| Gerar volume excessivo e consumir compute | Limitar target_rows a 10.000 por batch sem confirmação adicional |
| Gerar anomalias que quebrem a pipeline | Avisar quando cancel_rate > 20% |
| Perder rastreabilidade | Nunca apagar generation_manifest |

---

## Exemplos de tarefas que esta skill ajuda

- "Gere dados realistas para a próxima semana com base nos padrões históricos"
- "Simule um pico de Black Friday"
- "Gere dados com alta taxa de cancelamento para testar qualidade"
- "Quero que você analise os padrões antes de gerar qualquer dado"
- "Como seria um batch típico de uma segunda-feira?"
