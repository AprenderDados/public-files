# Databricks notebook source
# COMMAND ----------

# MAGIC %md
# MAGIC # Assistente do Projeto — AI
# MAGIC
# MAGIC Este notebook baixa automaticamente a skill do assistente do GitHub e abre
# MAGIC uma sessão de assistência com a IA do Databricks. Não é preciso copiar ou colar nada.
# MAGIC
# MAGIC **Skill pública:** `AprenderDados/public-files` → `skills/student-project-assistant/SKILL.md`
# MAGIC
# MAGIC **Como usar:**
# MAGIC 1. Execute todas as células de setup (até "Assistente pronto")
# MAGIC 2. Execute as células de exemplo para ver a conversa funcionando
# MAGIC 3. Adicione novas células com `chat("""sua mensagem""")` para continuar
# MAGIC 4. Use `reset_session()` no final para reiniciar
# MAGIC
# MAGIC **Dica:** use aspas triplas para mensagens de múltiplas linhas:
# MAGIC ```python
# MAGIC chat("""
# MAGIC Executei o notebook 00 sem erros.
# MAGIC O schema aparece no Unity Catalog.
# MAGIC O que faço agora?
# MAGIC """)
# MAGIC ```

# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


PROJECT_ROOT = _resolve_project_root()
SKILL_PATH = PROJECT_ROOT / "ai/skills/student-project-assistant/SKILL.md"
SKILL_URL = "https://raw.githubusercontent.com/AprenderDados/public-files/main/public-files/skills/student-project-assistant/SKILL.md"

print(f"Projeto: {PROJECT_ROOT}")
print(f"Skill local: {SKILL_PATH}")
print(f"Skill URL: {SKILL_URL}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuração do modelo
# MAGIC
# MAGIC Modelos disponíveis neste workspace:
# MAGIC - `databricks-llama-4-maverick` — alta capacidade, bom para raciocínio (padrão)
# MAGIC - `databricks-meta-llama-3-3-70b-instruct` — mais rápido, boa qualidade
# MAGIC - `databricks-meta-llama-3.1-405b-instruct` — máxima capacidade

# COMMAND ----------

MODEL = "databricks-llama-4-maverick"
MAX_TOKENS = 2000

# COMMAND ----------

# Carrega a skill — tenta GitHub primeiro, cai para arquivo local
import urllib.request

try:
    with urllib.request.urlopen(SKILL_URL, timeout=10) as r:
        skill_content = r.read().decode("utf-8")
    print(f"✅ Skill carregada do GitHub — {len(skill_content)} caracteres")
except Exception as _e:
    print(f"⚠️  GitHub indisponível ({_e}), usando arquivo local...")
    with open(SKILL_PATH, "r", encoding="utf-8") as f:
        skill_content = f.read()
    print(f"✅ Skill carregada localmente — {len(skill_content)} caracteres")

# COMMAND ----------

import mlflow.deployments
import re
import html as _html

client = mlflow.deployments.get_deploy_client("databricks")

# Histórico da conversa — mantém o contexto entre células
_messages = [
    {"role": "system", "content": skill_content}
]


def _md_to_html(text: str) -> str:
    """Converte markdown básico para HTML para exibição no displayHTML."""
    # Escapa HTML primeiro para evitar injeção
    t = _html.escape(text)

    # Blocos de código (``` ... ```)
    t = re.sub(
        r"```[^\n]*\n(.*?)```",
        r'<pre style="background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:6px;overflow-x:auto;font-size:13px;">\1</pre>',
        t,
        flags=re.DOTALL,
    )

    # Headers
    t = re.sub(r"^#### (.+)$", r"<h4>\1</h4>", t, flags=re.MULTILINE)
    t = re.sub(r"^### (.+)$",  r"<h3>\1</h3>", t, flags=re.MULTILINE)
    t = re.sub(r"^## (.+)$",   r"<h2>\1</h2>", t, flags=re.MULTILINE)
    t = re.sub(r"^# (.+)$",    r"<h1>\1</h1>", t, flags=re.MULTILINE)

    # Negrito e itálico
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\*(.+?)\*",     r"<em>\1</em>",         t)

    # Inline code
    t = re.sub(r"`([^`]+)`", r'<code style="background:#f0f0f0;padding:1px 5px;border-radius:3px;font-family:monospace;">\1</code>', t)

    # Tabelas markdown simples (linha com |)
    def _table(m):
        rows = [r.strip() for r in m.group(0).strip().split("\n") if r.strip()]
        html_rows = []
        for i, row in enumerate(rows):
            if re.match(r"^\|[-| :]+\|$", row):
                continue
            cols = [c.strip() for c in row.strip("|").split("|")]
            tag = "th" if i == 0 else "td"
            html_rows.append("<tr>" + "".join(f"<{tag}>{c}</{tag}>" for c in cols) + "</tr>")
        return '<table style="border-collapse:collapse;width:100%;margin:8px 0;">' + "".join(html_rows) + "</table>"

    t = re.sub(r"(\|.+\|\n)+", _table, t)

    # Listas com bullet (- item)
    def _list_block(m):
        items = re.findall(r"^[-*] (.+)$", m.group(0), re.MULTILINE)
        return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"

    t = re.sub(r"(^[-*] .+\n?)+", _list_block, t, flags=re.MULTILINE)

    # Listas numeradas
    def _ol_block(m):
        items = re.findall(r"^\d+\. (.+)$", m.group(0), re.MULTILINE)
        return "<ol>" + "".join(f"<li>{i}</li>" for i in items) + "</ol>"

    t = re.sub(r"(^\d+\. .+\n?)+", _ol_block, t, flags=re.MULTILINE)

    # Parágrafos (dupla quebra de linha)
    t = re.sub(r"\n{2,}", "</p><p>", t)
    t = f"<p>{t}</p>"

    # Quebras simples de linha dentro de parágrafo
    t = t.replace("\n", "<br>")

    return t


def _display_user(message: str) -> None:
    displayHTML(f"""
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
                max-width:820px;margin:4px 0;">
        <div style="background:#e8f4fd;border-left:4px solid #0066cc;
                    padding:10px 14px;border-radius:4px;color:#003366;">
            <span style="font-size:11px;color:#0066cc;font-weight:600;">VOCÊ</span><br>
            {_html.escape(message)}
        </div>
    </div>
    """)


def _display_assistant(message: str) -> None:
    displayHTML(f"""
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
                max-width:820px;margin:4px 0 16px 0;line-height:1.6;">
        <div style="background:#1a3a1a;color:#90ee90;
                    padding:6px 14px;border-radius:6px 6px 0 0;font-size:12px;
                    font-weight:600;letter-spacing:0.5px;">
            🎓 ASSISTENTE DO PROJETO
        </div>
        <div style="background:#f9f9f9;border:1px solid #ddd;border-top:none;
                    padding:16px 20px;border-radius:0 0 6px 6px;color:#222;">
            {_md_to_html(message)}
        </div>
        <div style="color:#888;font-size:11px;padding:4px 2px;">
            💬 Responda com: <code>chat('sua mensagem')</code>
            &nbsp;·&nbsp; <code>reset_session()</code> para reiniciar
        </div>
    </div>
    """)


def chat(user_message: str) -> None:
    """
    Envia uma mensagem ao assistente e exibe a resposta renderizada.

    Use aspas triplas para mensagens de múltiplas linhas:

        chat(\"\"\"
        Executei o notebook 00 sem erros.
        O schema aparece no Unity Catalog.
        O que faço agora?
        \"\"\")
    """
    _display_user(user_message)

    _messages.append({"role": "user", "content": user_message})
    response = client.predict(
        endpoint=MODEL,
        inputs={"messages": _messages, "max_tokens": MAX_TOKENS, "temperature": 0.4},
    )
    assistant_message = response["choices"][0]["message"]["content"]
    _messages.append({"role": "assistant", "content": assistant_message})

    _display_assistant(assistant_message)


def reset_session() -> None:
    """Reinicia a conversa mantendo a skill carregada."""
    global _messages
    _messages = [{"role": "system", "content": skill_content}]
    displayHTML("<div style='color:green;font-family:sans-serif;'>✅ Sessão reiniciada. Chame <code>chat('Quero começar o projeto.')</code> para começar.</div>")


displayHTML("""
<div style="font-family:sans-serif;background:#f0f7f0;border:1px solid #4caf50;
            border-radius:6px;padding:12px 16px;max-width:500px;">
    <strong>✅ Assistente pronto</strong><br><br>
    <code>chat('sua mensagem')</code> — conversa com o assistente<br>
    <code>reset_session()</code> — reinicia a conversa
</div>
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Demonstração — conversa completa
# MAGIC
# MAGIC As células abaixo mostram uma sessão real de assistência do início ao fim.
# MAGIC Execute uma célula por vez e leia a resposta antes de avançar.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 1 — Apresentação

# COMMAND ----------

chat("""
Olá! Quero começar o projeto.
Tenho experiência com Python e SQL, mas nunca usei Databricks antes.
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 2 — Escolha do modo de trabalho

# COMMAND ----------

chat("""
Prefiro o modo prático — me diz o que fazer e o que observar.
Não tenho CLI configurada, então vou usar workspace files.
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 3 — Confirmação do ambiente

# COMMAND ----------

chat("""
Subi a pasta do projeto no workspace como workspace files.
Consigo abrir o notebook 06_workspace_manual_runbook.py sem erro.
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 4 — Setup do workspace concluído

# COMMAND ----------

chat("""
Executei o notebook 00_setup_workspace.py sem erros.
No Unity Catalog consigo ver um schema e um volume criados.
Qual é o próximo passo?
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 5 — Erro ao gerar dimensões

# COMMAND ----------

chat("""
Ao rodar o notebook 01_generate_dimension_full.py apareceu esse erro:

AnalysisException: Table or view not found:
adventureworks_federated.sales.salesorderheader

O que pode ser?
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 6 — Pergunta de arquitetura

# COMMAND ----------

chat("""
Entendi o problema da federation.
Enquanto resolvo, quero entender: por que o projeto separa o gerador
da pipeline em dois módulos completamente independentes?
Parece mais trabalhoso do que colocar tudo junto.
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 💬 Célula 7 — Dados gerados, pipeline a executar

# COMMAND ----------

chat("""
Consegui rodar o gerador. O resultado foi:
  sale_rows: 587
  adjustment_rows: 17
  cancel_rows: 5
  total_rows: 609

Os arquivos aparecem no volume. Agora preciso rodar a pipeline.
Como faço isso no modo workspace files?
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 🔄 Fim da demonstração — reiniciando a sessão
# MAGIC
# MAGIC A célula abaixo reinicia o histórico da conversa.
# MAGIC A partir daqui você pode iniciar sua própria sessão com `chat("""...""")`.

# COMMAND ----------

reset_session()
