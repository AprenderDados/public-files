# Databricks notebook source
# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


def _get_widget(name: str, default: str = "") -> str:
    if "dbutils" not in globals():
        return default
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from incremental_sales_generator.dimension_exporter import DimensionFullExporter


environment = _get_widget("environment", "dev")
dimension_name = _get_widget("dimension_name", "")
extract_ts = _get_widget("extract_ts", "")

exporter = DimensionFullExporter(spark, PROJECT_ROOT)

if dimension_name:
    result = exporter.export_dimension(
        logical_name=dimension_name,
        environment=environment,
        extract_ts=extract_ts or None,
    )
    print(exporter.as_dict(result))
else:
    results = exporter.export_all(
        environment=environment,
        extract_ts=extract_ts or None,
    )
    for result in results:
        print(exporter.as_dict(result))
