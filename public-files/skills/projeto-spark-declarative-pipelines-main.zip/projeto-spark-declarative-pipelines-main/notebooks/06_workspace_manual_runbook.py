# Databricks notebook source
# COMMAND ----------

from pathlib import Path, PurePosixPath
import sys


def _notebook_project_root() -> Path:
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

    def option_get(option_like):
        try:
            return option_like.get()
        except Exception:
            return option_like.getOrElse(None)

    notebook_path = option_get(ctx.notebookPath())
    notebook_dir_workspace = PurePosixPath(notebook_path).parent
    notebook_dir_local = Path("/Workspace") / str(notebook_dir_workspace).lstrip("/")
    return notebook_dir_local.parent


def _workspace_root_path(project_root: Path) -> str:
    return f"/Workspace/{str(project_root).replace('/Workspace/', '', 1)}"


def _workspace_notebook_path(project_root: Path, relative_path: str) -> str:
    notebook_path = project_root / relative_path
    return f"/Workspace/{str(notebook_path).replace('/Workspace/', '', 1)}".removesuffix(".py")


def _path_exists(project_root: Path, relative_path: str) -> bool:
    return (project_root / relative_path).exists()


PROJECT_ROOT = _notebook_project_root()
WORKSPACE_PROJECT_ROOT = _workspace_root_path(PROJECT_ROOT)
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.runtime_context import ProjectContextResolver


environment = dbutils.widgets.get("environment") if "dbutils" in globals() else "dev"
config_loader = ConfigLoader(PROJECT_ROOT)
runtime_context = ProjectContextResolver(spark, PROJECT_ROOT).resolve(environment)

required_paths = [
    "src/course_lakeflow/__init__.py",
    "src/incremental_sales_generator/__init__.py",
    "config/environments/base.yml",
    "config/generator/sales_generator.yml",
    "dashboards/sales_incremental_monitoring_v1.lvdash.json",
]

preflight_rows = [
    {
        "path": relative_path,
        "exists": "yes" if _path_exists(PROJECT_ROOT, relative_path) else "no",
    }
    for relative_path in required_paths
]

job_rows = [
    {
        "step": "1",
        "job_name": "Setup Course Workspace",
        "type": "notebook",
        "target": _workspace_notebook_path(PROJECT_ROOT, "notebooks/00_setup_workspace.py"),
        "parameters": "environment=dev",
    },
    {
        "step": "2",
        "job_name": "Bootstrap Sales Profiles",
        "type": "notebook",
        "target": _workspace_notebook_path(PROJECT_ROOT, "notebooks/04_bootstrap_sales_profiles.py"),
        "parameters": "environment=dev",
    },
    {
        "step": "3",
        "job_name": "Export Full Dimensions",
        "type": "notebook",
        "target": _workspace_notebook_path(PROJECT_ROOT, "notebooks/01_generate_dimension_full.py"),
        "parameters": "environment=dev",
    },
    {
        "step": "4",
        "job_name": "Generate Incremental Sales Batch",
        "type": "notebook",
        "target": _workspace_notebook_path(PROJECT_ROOT, "notebooks/02_generate_sales_batch.py"),
        "parameters": "environment=dev",
    },
    {
        "step": "5",
        "job_name": "Refresh Sales Pipeline",
        "type": "pipeline",
        "target": "Use the pipeline created manually in the UI",
        "parameters": "",
    },
]

pipeline_rows = [
    {
        "field": "Project root",
        "value": WORKSPACE_PROJECT_ROOT,
    },
    {
        "field": "Python pipeline source folder",
        "value": f"{WORKSPACE_PROJECT_ROOT}/src/course_lakeflow/pipelines",
    },
    {
        "field": "Python pipeline dependency",
        "value": f"--editable {WORKSPACE_PROJECT_ROOT}",
    },
    {
        "field": "Pipeline config",
        "value": f"course_sdp.environment={environment}",
    },
    {
        "field": "Pipeline config",
        "value": f"course_sdp.project_root={WORKSPACE_PROJECT_ROOT}",
    },
    {
        "field": "SQL pipeline source folder",
        "value": f"{WORKSPACE_PROJECT_ROOT}/sql_pipeline",
    },
    {
        "field": "SQL pipeline config",
        "value": f"course_sdp.sql_fact_source_path=/Volumes/{runtime_context.lakeflow_catalog}/{runtime_context.schemas['landing']}/facts_ingest/sales_events",
    },
    {
        "field": "SQL pipeline config",
        "value": f"course_sdp.sql_dimensions_source_root=/Volumes/{runtime_context.lakeflow_catalog}/{runtime_context.schemas['landing']}/dimensions_ingest",
    },
    {
        "field": "Resolved SQL schema",
        "value": runtime_context.schemas["sql"],
    },
    {
        "field": "Resolved lakeflow catalog",
        "value": runtime_context.lakeflow_catalog,
    },
    {
        "field": "Resolved Python bronze schema",
        "value": runtime_context.schemas["bronze"],
    },
    {
        "field": "Resolved Python silver schema",
        "value": runtime_context.schemas["silver"],
    },
    {
        "field": "Resolved Python gold schema",
        "value": runtime_context.schemas["gold"],
    },
    {
        "field": "Resolved ops schema",
        "value": runtime_context.schemas["ops"],
    },
]

print("Workspace direct runbook")
print("environment =", environment)
print("project_root =", WORKSPACE_PROJECT_ROOT)
print("")
print("If one of the critical files below is missing, the project was likely imported as notebooks only.")
print("In that case, re-import the full folder as workspace files or clone the repo as a Git folder.")

display(spark.createDataFrame(preflight_rows))

print("")
print("Manual pipeline settings")
display(spark.createDataFrame(pipeline_rows))

print("")
print("Recommended execution order")
display(spark.createDataFrame(job_rows))

print("")
print("Notebook-only minimum path:")
print("1. Run 00_setup_workspace")
print("2. Run 04_bootstrap_sales_profiles (recommended)")
print("3. Run 01_generate_dimension_full")
print("4. Run 02_generate_sales_batch")
print("5. Refresh the Lakeflow pipeline in the UI")
print("6. Run 05_validate_dashboard_queries")
