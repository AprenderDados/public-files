# Databricks notebook source
# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


def _get_widget(name: str, default: str = "") -> str:
    if "dbutils" not in globals():
        return default
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from incremental_sales_generator.config import GeneratorRunConfig
from incremental_sales_generator.sales_event_generator import SalesEventGenerator


environment = _get_widget("environment", "dev")
business_date = _get_widget("business_date", "")
arrival_date = _get_widget("arrival_date", "")
target_rows = _get_widget("target_rows", "")
random_seed = _get_widget("random_seed", "")
late_adjustment_rate = _get_widget("late_adjustment_rate", "")
cancel_rate = _get_widget("cancel_rate", "")

generator = SalesEventGenerator(spark, PROJECT_ROOT)
result = generator.generate_batch(
    GeneratorRunConfig(
        environment=environment,
        business_date=business_date or None,
        arrival_date=arrival_date or None,
        target_rows=int(target_rows) if target_rows else None,
        late_adjustment_rate=float(late_adjustment_rate) if late_adjustment_rate else None,
        cancel_rate=float(cancel_rate) if cancel_rate else None,
        random_seed=int(random_seed) if random_seed else None,
    )
)

print(generator.as_dict(result))
