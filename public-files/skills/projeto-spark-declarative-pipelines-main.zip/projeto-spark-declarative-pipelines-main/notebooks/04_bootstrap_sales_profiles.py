# Databricks notebook source
# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


def _get_widget(name: str, default: str = "") -> str:
    if "dbutils" not in globals():
        return default
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from incremental_sales_generator.sales_profile_service import SalesProfileService


environment = _get_widget("environment", "dev")
profile_service = SalesProfileService(spark, PROJECT_ROOT)
result = profile_service.build_profiles(environment)

print(result)
