# Databricks notebook source
# COMMAND ----------

from pathlib import Path, PurePosixPath
import sys


def _notebook_project_root():
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

    def option_get(option_like):
        try:
            return option_like.get()
        except Exception:
            return option_like.getOrElse(None)

    notebook_path = option_get(ctx.notebookPath())
    notebook_dir_workspace = PurePosixPath(notebook_path).parent
    notebook_dir_local = Path("/Workspace") / str(notebook_dir_workspace).lstrip("/")
    return notebook_dir_local.parent


PROJECT_ROOT = _notebook_project_root()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from course_lakeflow.bootstrap.workspace_setup import WorkspaceBootstrapService
from course_lakeflow.common.runtime_context import ProjectContextResolver


environment = dbutils.widgets.get("environment") if "dbutils" in globals() else "dev"

resolver = ProjectContextResolver(spark, PROJECT_ROOT)
context = resolver.resolve(environment)
service = WorkspaceBootstrapService(spark)
provisioning_result = service.provision_project_resources(context)

print("Workspace setup result")
print("context =", context)
print("provisioned =", provisioning_result)
