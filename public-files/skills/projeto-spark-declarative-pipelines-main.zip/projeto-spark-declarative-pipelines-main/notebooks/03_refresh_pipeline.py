# Databricks notebook source
# COMMAND ----------

environment = dbutils.widgets.get("environment") if "dbutils" in globals() else "dev"
print(f"Pipeline refresh helper scaffold for environment={environment}")
print("")
print("This notebook does not execute a pipeline update by itself.")
print("Use one of the following paths instead:")
print("1. Bundle mode: run the refresh_pipeline job created by the bundle.")
print("2. Workspace-direct mode: refresh the Lakeflow pipeline from the UI after creating it manually.")
