# Databricks notebook source
# COMMAND ----------

import json
import re
import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


def _get_widget(name: str, default: str = "") -> str:
    if "dbutils" not in globals():
        return default
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from course_lakeflow.common.config_loader import ConfigLoader
from course_lakeflow.common.runtime_context import ProjectContextResolver


environment = _get_widget("environment", "dev")
rendered_dashboard_file = (
    PROJECT_ROOT / "dashboards" / "rendered" / environment / "sales_incremental_monitoring_v1.lvdash.json"
)
dashboard_file = rendered_dashboard_file
if not rendered_dashboard_file.exists():
    dashboard_file = PROJECT_ROOT / "dashboards" / "sales_incremental_monitoring_v1.lvdash.json"

config_loader = ConfigLoader(PROJECT_ROOT)
context_resolver = ProjectContextResolver(spark, PROJECT_ROOT)
runtime_context = context_resolver.resolve(environment)

dashboard_payload = json.loads(dashboard_file.read_text(encoding="utf-8"))


def _gold_table_fqn(file_name: str) -> str:
    return runtime_context.table_fqn(config_loader.load_table_spec("gold", file_name))


gold_tables = {
    "gold_daily_sales": _gold_table_fqn("daily_sales.yml"),
    "gold_daily_sales_by_product": _gold_table_fqn("daily_sales_by_product.yml"),
    "gold_arrival_vs_business_date": _gold_table_fqn("arrival_vs_business_date.yml"),
    "gold_correction_impact": _gold_table_fqn("correction_impact.yml"),
    "gold_sales_analytics_obt": _gold_table_fqn("sales_analytics_obt.yml"),
}


def _qualify_dashboard_sql(sql_text: str) -> str:
    qualified_sql = sql_text
    for physical_name, fqn in gold_tables.items():
        qualified_sql = re.sub(rf"\\b{physical_name}\\b", fqn, qualified_sql)
    return qualified_sql


rendered_dashboard_uses_fqn = dashboard_file.parent.name == environment


datasets = dashboard_payload.get("datasets", [])
validation_results: list[dict[str, str]] = []

print(f"Environment: {environment}")
print(f"Dashboard file: {dashboard_file}")
print("Resolved gold tables:")
for physical_name, fqn in gold_tables.items():
    print(f"  - {physical_name} -> {fqn}")


for dataset in datasets:
    dataset_name = dataset["name"]
    original_sql = "".join(dataset.get("queryLines", [])).strip()
    qualified_sql = original_sql if rendered_dashboard_uses_fqn else _qualify_dashboard_sql(original_sql)

    print("")
    print(f"=== Dataset: {dataset_name} ===")
    print(qualified_sql)

    row_count = spark.sql(f"SELECT COUNT(*) AS row_count FROM ({qualified_sql}) dashboard_dataset").first()["row_count"]
    preview_df = spark.sql(qualified_sql).limit(20)
    display(preview_df)

    validation_results.append(
        {
            "dataset_name": dataset_name,
            "status": "ok",
            "rows": str(row_count),
        }
    )


display(spark.createDataFrame(validation_results))
