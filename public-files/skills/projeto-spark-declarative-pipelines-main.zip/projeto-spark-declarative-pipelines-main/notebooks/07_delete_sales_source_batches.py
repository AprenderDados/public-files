# Databricks notebook source
# MAGIC %md
# MAGIC # Remover batches de vendas da fonte
# MAGIC
# MAGIC Use este caderno para remover arquivos de origem da landing zone por `business_date` ou por `batch_id`.
# MAGIC
# MAGIC Ele começa em `dry_run=true`, então primeiro apenas mostra o que seria removido.

# COMMAND ----------

import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = context.notebookPath().get()
    workspace_path = Path("/Workspace") / notebook_path.lstrip("/")
    return workspace_path.parent.parent


PROJECT_ROOT = _resolve_project_root() if "dbutils" in globals() else Path.cwd()
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from incremental_sales_generator.config import GeneratorConfigLoader
from course_lakeflow.common.runtime_context import ProjectContextResolver


dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("business_date", "")
dbutils.widgets.text("batch_id", "")
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"])

environment = dbutils.widgets.get("environment")
business_date = dbutils.widgets.get("business_date").strip()
batch_id = dbutils.widgets.get("batch_id").strip()
dry_run = dbutils.widgets.get("dry_run").lower() == "true"

if not business_date and not batch_id:
    raise ValueError("Informe business_date ou batch_id.")

context = ProjectContextResolver(spark, PROJECT_ROOT).resolve(environment)
generator_config = GeneratorConfigLoader(PROJECT_ROOT).load()
manifest_table = context.ops_table_fqn(generator_config.state_tables["generation_manifest"])

print(f"Environment: {environment}")
print(f"Manifest table: {manifest_table}")
print(f"Dry run: {dry_run}")

# COMMAND ----------

where_parts = [f"environment = '{environment}'"]
if batch_id:
    where_parts.append(f"batch_id = '{batch_id}'")
if business_date:
    where_parts.append(f"business_date = DATE('{business_date}')")

where_clause = " AND ".join(where_parts)

candidates_df = spark.sql(
    f"""
    SELECT
      environment,
      batch_id,
      business_date,
      arrival_date,
      sale_rows,
      adjustment_rows,
      cancel_rows,
      sale_rows + adjustment_rows + cancel_rows AS total_rows,
      output_path,
      created_at
    FROM {manifest_table}
    WHERE {where_clause}
    ORDER BY created_at DESC
    """
)

display(candidates_df)

# COMMAND ----------

candidates = candidates_df.collect()

if not candidates:
    print("Nenhum batch encontrado para os filtros informados.")
elif dry_run:
    print("Dry run ativo. Nenhum arquivo foi removido.")
    for row in candidates:
        print(f"Removeria: {row['output_path']} ({row['total_rows']} linhas no manifesto)")
else:
    print("Dry run desativado. Removendo diretórios da fonte...")
    for row in candidates:
        path = row["output_path"]
        print(f"Removendo: {path}")
        dbutils.fs.rm(path, recurse=True)
    print("Remoção concluída.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Próximo passo
# MAGIC
# MAGIC Depois de remover a fonte, rode um **full refresh** da pipeline para reconstruir as tabelas a partir dos arquivos restantes.
# MAGIC
# MAGIC Pela CLI:
# MAGIC
# MAGIC ```bash
# MAGIC databricks pipelines start-update \
# MAGIC   80cdfd00-7162-42dd-a1a1-6b80e1699434 \
# MAGIC   --full-refresh \
# MAGIC   --output json
# MAGIC ```
