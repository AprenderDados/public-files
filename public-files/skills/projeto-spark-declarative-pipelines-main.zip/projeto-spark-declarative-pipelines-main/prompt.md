sim, mas vamos fazer modificações importantes.

nesse projeto, houve uma confusão grande sobre

snapshots, scd1 scd2

foi trabalho e difícil demais

no próximo projeto vamos fazer o mesmo projeto

mas com outra abordagem

quero ler a base do mesmo jeito

mas vamos construir uma feature responsável por "picotear" as fatos e construir pequenos dados incrementais 

ou seja, vendas dia a dia, ou outras possibilidades

isso vai remover toda associação com SCD1 ou SCD2

e criação de SNAPSHOT - não vamos fazer isso

vamos fazer, vendas incrementais que vão ser pequenos arquivos, gerados por nós, com parâmetros e uma certa inteligência (mas nada tão sofisticado)

basicamente quero ser capaz de criar samples de dados que tenham uma certa representação estatística da base toda - por exemplo produtos mais vendidos e a quantidade por dia

a ideia é ter um gerador de arquivos,


o gerador de arquivos funciona num job, um caderno e uma classe - mas controlamos por um job e temos parâmetros para decidir datas, mas seria legal gerar novas vendas com uma nova data, para que geramos dia a dia.

portanto adicione uma certa inteligência nisso

tbm posso providenciar estatísticas das vendas, para termos uma ideia.


--------

esses arquivos vão ser lidos com Autoloader

isso vai ser nossa camada bronze - com alguns metadados simples de adicionar

as tabelas dimensões podemos ler e fazer overwrite se um novo arquivo chegar dimensões devem chegar sempre em full 

as tabelas fatos vão chegar em pedaços que fazem sentido (podemos observar as infos da bronze disponível e planejar qual o próximo ID do gerador)

-------

na camada silver, vamos fazer uma etapa de qualidade

com data expectations (vamos explorar os dados e escrever expectations que fazem sentido)


------- na camada ouro vamos criar agregações por dia de venda


e o que mais for relevante

como vamos lidar com os updates que afetam as agregações? isso é um ponto didático importante


esse projeto é feito para ser didático

mas vamos usar o aprendizado de projetos anteriores


para deployment

Vamos pesquisar sobre as mais recentes releases sobre Automation Bundles da Databricks

E criar um projeto com isso já em mente - também podemos explorar nossa base de conhecimento existente



---------

#projeto-spark-declarative-pipelines
