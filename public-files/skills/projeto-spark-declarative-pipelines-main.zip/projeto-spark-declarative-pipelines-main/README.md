# Spark Declarative Pipelines — Projeto Didático

Este projeto demonstra uma arquitetura de dados em camadas usando Lakeflow Spark Declarative Pipelines no Databricks. O domínio é vendas de produtos esportivos, baseado no conjunto de dados AdventureWorks, com dados sintéticos gerados incrementalmente para simular um fluxo real de operação.

O projeto tem três módulos independentes:

- **`src/course_lakeflow`** — projeto declarative Python com camadas bronze, silver e gold
- **`sql_pipeline/`** — projeto declarative SQL puro, com um arquivo `.sql` por tabela
- **`src/incremental_sales_generator`** — gerador auxiliar de arquivos incrementais em Parquet

A integração entre os dois acontece por arquivos em Volumes do Unity Catalog e por jobs separados. A pipeline não conhece o gerador em tempo de execução.

## O que este projeto cobre

- Ingestão incremental de fatos com Auto Loader e schema explícito
- Ingestão de dimensões como full extracts com publicação de estado corrente na silver
- Qualidade declarativa com expectations configuradas em YAML
- Deduplicação de fatos e dimensões com funções de janela
- Camada gold com dimensões conformadas e métricas de negócio
- Configuração declarativa em YAML com herança por ambiente
- Validação de tipos com Pydantic
- Compatibilidade com workspaces free-tier do Databricks

## Arquitetura em camadas

```
Fonte (AdventureWorks Federated)
           ↓
   [Gerador auxiliar]
   → arquivos Parquet em Volumes do Unity Catalog
           ↓
   [Camada Bronze]
   → tabelas raw com schema tipado e metadados de ingestão
           ↓
   [Camada Silver]
   → dimensões current-state + fatos limpos com expectations declaradas
           ↓
   [Camada Gold]
   → dimensões conformadas + One Big Table + métricas agregadas
           ↓
   [Dashboard AI/BI]
   → visualização sobre a camada gold
```

## Estrutura de pastas

```
config/
  environments/     # configurações base, dev, acc e prd com herança
  resources/        # catálogos, schemas, volumes e caminhos lógicos
  tables/           # specs de tabelas por camada (bronze, silver, gold)
  generator/        # parâmetros e SQLs do gerador auxiliar

src/
  course_lakeflow/
    common/         # modelos Pydantic, carregamento de config, runtime context
    bronze/         # serviço de ingestão com Auto Loader
    silver/         # regras de qualidade, builders de dimensão e fatos
    gold/           # dimensões conformadas e métricas analíticas
    pipelines/      # definições DLT — entry points da pipeline Lakeflow
    bootstrap/      # provisionamento de schemas e volumes

  incremental_sales_generator/
                    # gerador de fatos incrementais e dimensões full, gestão de estado

sql_pipeline/
  bronze/           # uma tabela SQL por arquivo na camada bronze
  silver/           # uma tabela SQL por arquivo na camada silver
  gold/             # dimensões conformadas, OBT e agregações em SQL puro

notebooks/          # entry points operacionais e de setup
resources/          # jobs e pipeline para Databricks Asset Bundles
docs/               # documentação de arquitetura e modelo de dados
dashboards/         # definições versionadas de dashboard AI/BI
tests/              # testes unitários
curso/              # material didático isolado por tópico
```

## Como executar

### Checklist zero-to-run

Antes do primeiro run, confirme estes quatro pontos:

1. Databricks workspace com Unity Catalog e Federation prontos
2. Python local `>=3.11`
3. Databricks CLI autenticado no workspace
4. Projeto validado localmente com testes unitários

Se quiser preparar isso de forma guiada no seu computador local:

```bash
bash scripts/bootstrap_local_env.sh
```

### Escolha o caminho certo

Se o objetivo é só conseguir rodar o projeto pela primeira vez:

- aluno novo no Databricks -> siga **Para alunos: Modo Caderno**
- aluno confortável com terminal e CLI -> siga **Para alunos: Modo Asset Bundles**

Se a meta for ver o projeto completo com Python e SQL no mesmo ambiente, rode sempre em sequência:

1. geração de dimensões e fatos
2. pipeline Python
3. pipeline SQL

Neste workspace, não trate as duas pipelines como paralelas.

### Pré-requisitos

- Databricks workspace com Unity Catalog habilitado (inclusive free-tier)
- Lakehouse Federation configurada para acessar o catálogo `adventureworks_federated` (ver `docs/federation_setup.md`)
- Python local `>=3.11` para instalação do projeto e testes unitários
- Databricks CLI autenticado no workspace alvo
- Um dos dois modos de entrega abaixo:
  - **Com bundle**: bundle implantado com `databricks bundle deploy`
  - **Sem bundle**: projeto importado no workspace como **workspace files**, preservando `src/`, `config/`, `dashboards/` e `docs/`

Checagens rápidas:

```bash
python3.11 --version
./.tools/databricks-cli/databricks auth describe
```

Se a CLI ainda não estiver autenticada, use o fluxo oficial do Databricks:

```bash
./.tools/databricks-cli/databricks auth login --host <workspace-url>
```

### Importante sobre `.dbc`

Para este projeto, **um `.dbc` sozinho não basta**.

O projeto depende de notebooks, mas também depende de:

- módulos Python em `src/`
- configurações YAML em `config/`
- JSON de dashboard em `dashboards/`

Se o aluno importar apenas notebooks, os imports locais e a leitura de configuração vão falhar. Para o caso sem bundle, use o guia [workspace_direct_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/workspace_direct_setup.md:1).

### Para alunos: Modo Caderno

Esse é o caminho mais simples para aluno novo.

Use esse modo quando o aluno:

- ainda não conhece Databricks Asset Bundles
- quer entender o projeto por etapas
- vai subir o projeto diretamente no workspace

Passo a passo:

1. suba a **pasta completa** do projeto no workspace como workspace files
2. rode [notebooks/06_workspace_manual_runbook.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/06_workspace_manual_runbook.py:1)
3. rode [notebooks/00_setup_workspace.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/00_setup_workspace.py:1)
4. rode [notebooks/04_bootstrap_sales_profiles.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/04_bootstrap_sales_profiles.py:1) *(opcional, mas recomendado)*
5. rode [notebooks/01_generate_dimension_full.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/01_generate_dimension_full.py:1)
6. rode [notebooks/02_generate_sales_batch.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/02_generate_sales_batch.py:1)
7. crie ou atualize a pipeline **Python** manualmente na UI
8. execute o refresh da pipeline **Python** pela UI e espere terminar
9. se quiser validar também a versão SQL, crie ou atualize a pipeline **SQL** manualmente e execute o refresh **só depois** de a Python terminar
10. valide as queries do dashboard com [notebooks/05_validate_dashboard_queries.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/05_validate_dashboard_queries.py:1)
11. escolha uma destas opções para a dashboard:
   - importar o arquivo `dashboards/rendered/dev/sales_incremental_monitoring_v1.lvdash.json`
   - ou montar manualmente com as queries de [dashboard_student_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/dashboard_student_setup.md:1)

Observações:

- um `.dbc` sozinho não basta para este projeto
- o notebook [03_refresh_pipeline.py](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/notebooks/03_refresh_pipeline.py:1) **não** executa o refresh real da pipeline
- esse notebook serve só como scaffold/helper

Guia detalhado:

- [workspace_direct_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/workspace_direct_setup.md:1)
- [dashboard_student_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/dashboard_student_setup.md:1)

### Para alunos: Modo Asset Bundles

Esse é o caminho mais curto para aluno que já consegue usar CLI e quer rodar o projeto quase todo de uma vez.

Use esse modo quando o aluno:

- já trabalha com terminal local
- quer deploy e execução mais automatizados
- quer um job único para a demonstração completa

Passo a passo:

1. copie [.env.example](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/.env.example:1) para `.env`
2. preencha `BUNDLE_VAR_dashboard_warehouse_id`
3. prepare o ambiente local e valide os testes:

```bash
bash scripts/bootstrap_local_env.sh
```

4. carregue o arquivo no shell:

```bash
set -a && source .env && set +a
```

5. valide o bundle:

```bash
./.tools/databricks-cli/databricks bundle validate -t dev
```

6. faça o deploy:

```bash
./.tools/databricks-cli/databricks bundle deploy -t dev
```

7. rode o job principal:

```bash
./.tools/databricks-cli/databricks bundle run -t dev end_to_end_demo_job
```

Esse job executa, na ordem:

1. `setup_workspace`
2. `bootstrap_sales_profiles`
3. `export_dimensions`
4. `generate_sales_batch`
5. `refresh_pipeline`

Se quiser validar também o projeto SQL, rode depois:

```bash
./.tools/databricks-cli/databricks bundle run -t dev refresh_sql_pipeline_job
```

Projeto SQL no modo bundle:

- `refresh_sql_pipeline_job`
- `end_to_end_sql_demo_job`

Esse deve ser o caminho padrão para aula quando o aluno optar por bundle. Os jobs individuais ficam como apoio para depuração, repetição isolada de etapa ou exploração didática.

No modo bundle, a dashboard também é publicada automaticamente no deploy. O guia manual de dashboard continua útil para inspeção e para alunos que queiram reconstruí-la na UI:

- [dashboard_student_setup.md](/Users/gebruiker/Documents/projeto-spark-declarative-pipelines/docs/dashboard_student_setup.md:1)

### Configuração neutra do bundle

O repositório não deve carregar IDs pessoais de compute.

Hoje o único ID externo necessário para o bundle deste projeto é o `warehouse_id` do dashboard. Ele ficou como variável obrigatória de deploy, não como valor hardcoded no repositório.

O bundle usa o mecanismo suportado oficialmente pelo Databricks para variáveis de deploy:

- `--var`
- variáveis de ambiente `BUNDLE_VAR_*`
- `.databricks/bundle/<target>/variable-overrides.json`

Observação importante:

- variáveis de bundle são resolvidas no **deploy**, não no momento do run
- se mudar o `warehouse_id`, faça novo `bundle deploy`

### Jobs individuais no modo bundle

Use estes jobs com esta intenção:

- `end_to_end_demo_job`: job principal para o aluno rodar o projeto inteiro corretamente
- `setup_workspace_job`: uso isolado quando quiser reprovisionar schemas e volumes
- `bootstrap_sales_profiles_job`: uso isolado para recalibrar perfis estatísticos
- `export_dimensions_job`: uso isolado para republicar dimensões full
- `generate_sales_batch_job`: uso isolado para gerar um novo dia de vendas
- `refresh_pipeline_job`: uso isolado para reprocessar bronze/silver/gold sem regenerar arquivos
- `refresh_sql_pipeline_job`: uso isolado para reprocessar a pipeline SQL sem regenerar arquivos

Regra prática:

- para demonstração completa ou primeira execução: `end_to_end_demo_job`
- para manutenção ou aula focada em uma etapa: job individual correspondente

Restrições operacionais:

- `generate_sales_batch_job` foi configurado com `max_concurrent_runs: 1`
- `refresh_pipeline_job` foi configurado com `max_concurrent_runs: 1`
- `refresh_sql_pipeline_job` foi configurado com `max_concurrent_runs: 1`
- `end_to_end_demo_job` foi configurado com `max_concurrent_runs: 1`
- neste workspace, a cota prática observada é **1 pipeline ativa por vez**

Isso evita conflito de escrita no estado do gerador e conflito de updates simultâneos na pipeline. Na prática:

1. não dispare `refresh_pipeline_job` e `refresh_sql_pipeline_job` em paralelo
2. espere a pipeline Python terminar
3. só então rode a SQL

### Validação em massa

Para validar a sequência `geração -> pipeline Python -> pipeline SQL`, use:

```bash
bash scripts/run_bulk_validation.sh
```

Por padrão o script executa no target `dev`, com `environment=dev` e `target_rows=10000000`.

Exemplo com override explícito:

```bash
TARGET=dev ENVIRONMENT=dev TARGET_ROWS=10000000 bash scripts/run_bulk_validation.sh
```

O script executa, nesta ordem:

- `databricks bundle validate`
- `databricks bundle deploy`
- `generate_sales_batch_job`
- `refresh_pipeline_job`
- `refresh_sql_pipeline_job`

Para cargas grandes, a recomendação prática é validar em etapas (`10M -> 100M -> 1Bi`) e observar a quota do workspace antes de insistir em volumes maiores.

O bundle Databricks (`databricks.yml`) define jobs e a pipeline de forma declarativa para deploy e promoção entre ambientes.

## Princípios do projeto

**Fatos como eventos incrementais**
Cada registro de venda é um evento imutável com tipo (`SALE`, `ADJUSTMENT`, `CANCEL`) e duas datas: a data de negócio (`sales_date`) e a data de chegada dos dados (`arrival_date`). A separação entre as duas permite analisar latência e correções tardias.

**Dimensões como full extracts**
Cada carga de dimensão é um snapshot completo da fonte. A camada bronze acumula todos os batches como append-only. A camada silver publica apenas o batch mais recente como estado corrente. Deleções são representadas pela ausência de uma chave no último batch.

**Sem SCD2**
A decisão é intencional. O estado corrente das dimensões é suficiente para o domínio analítico deste projeto e mantém o foco didático nas camadas de ingestão, qualidade e agregação.

**Configuração declarativa**
Schemas, regras de qualidade, chaves de deduplicação e parâmetros de ambiente ficam em arquivos YAML. O código lê a configuração; não a embute.

**Notebooks finos**
A lógica de negócio vive nas classes Python do pacote `course_lakeflow`. Os notebooks são entry points que instanciam serviços e chamam métodos. Isso facilita teste, versionamento e separação de responsabilidades.
