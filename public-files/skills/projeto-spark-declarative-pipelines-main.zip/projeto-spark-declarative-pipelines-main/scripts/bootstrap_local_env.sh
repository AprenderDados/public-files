#!/usr/bin/env bash

set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3.11}"
VENV_DIR="${VENV_DIR:-.venv}"
RUN_TESTS="${RUN_TESTS:-1}"
DATABRICKS_BIN="${DATABRICKS_BIN:-./.tools/databricks-cli/databricks}"

if ! command -v "${PYTHON_BIN}" >/dev/null 2>&1; then
  echo "Python requerido nao encontrado: ${PYTHON_BIN}" >&2
  echo "Este projeto exige Python >= 3.11." >&2
  exit 1
fi

echo "==> Using ${PYTHON_BIN}: $(${PYTHON_BIN} --version)"

if [[ ! -d "${VENV_DIR}" ]]; then
  echo "==> Creating virtual environment in ${VENV_DIR}"
  "${PYTHON_BIN}" -m venv "${VENV_DIR}"
fi

# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

echo "==> Upgrading pip"
python -m pip install --upgrade pip >/dev/null

echo "==> Installing project in editable mode"
pip install -e '.[dev]'

if [[ "${RUN_TESTS}" == "1" ]]; then
  echo "==> Running unit tests"
  pytest tests/unit
fi

if [[ -x "${DATABRICKS_BIN}" ]]; then
  echo "==> Databricks CLI detected at ${DATABRICKS_BIN}"
  echo "Next auth check:"
  echo "   ${DATABRICKS_BIN} auth describe"
  echo "If needed:"
  echo "   ${DATABRICKS_BIN} auth login --host <workspace-url>"
else
  echo "==> Databricks CLI not found at ${DATABRICKS_BIN}"
  echo "Use either the bundled CLI or set DATABRICKS_BIN to your installed databricks binary."
fi

echo
echo "Local environment is ready."
