#!/usr/bin/env bash

set -euo pipefail

TARGET="${TARGET:-dev}"
TARGET_ROWS="${TARGET_ROWS:-10000000}"
ENVIRONMENT="${ENVIRONMENT:-dev}"
DATABRICKS_BIN="${DATABRICKS_BIN:-}"

if [[ -z "${DATABRICKS_BIN}" ]]; then
  if command -v databricks >/dev/null 2>&1; then
    DATABRICKS_BIN="databricks"
  else
    DATABRICKS_BIN="./.tools/databricks-cli/databricks"
  fi
fi

run_step() {
  local description="$1"
  shift

  echo
  echo "==> ${description}"
  "${DATABRICKS_BIN}" "$@"
}

run_step \
  "Validating bundle (${TARGET})" \
  bundle validate -t "${TARGET}"

run_step \
  "Deploying bundle (${TARGET})" \
  bundle deploy -t "${TARGET}"

run_step \
  "Generating ${TARGET_ROWS} rows in ${ENVIRONMENT}" \
  bundle run -t "${TARGET}" generate_sales_batch_job \
  --notebook-params "environment=${ENVIRONMENT},target_rows=${TARGET_ROWS}"

run_step \
  "Refreshing Python pipeline" \
  bundle run -t "${TARGET}" refresh_pipeline_job

run_step \
  "Refreshing SQL pipeline" \
  bundle run -t "${TARGET}" refresh_sql_pipeline_job

echo
echo "Bulk validation sequence completed."
